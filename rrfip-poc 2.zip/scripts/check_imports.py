"""Offline static checker: for every `from app.X import Y, Z` in the codebase, verify that
module app/X.py (or app/X/__init__.py) actually defines Y and Z, using AST only -- no
imports executed, so this works without any dependencies installed.

Catches: typos in imported names, functions/classes that got renamed in one file but not
callers, missing re-exports in __init__.py.
"""
import ast
import pathlib
import sys

ROOT = pathlib.Path(__file__).parent
APP = ROOT / "app"


def module_path_to_file(module: str) -> pathlib.Path | None:
    parts = module.split(".")
    if parts[0] != "app":
        return None
    candidate_file = ROOT / (pathlib.Path(*parts).with_suffix(".py"))
    candidate_pkg = ROOT / pathlib.Path(*parts) / "__init__.py"
    if candidate_file.exists():
        return candidate_file
    if candidate_pkg.exists():
        return candidate_pkg
    return None


def top_level_names(file_path: pathlib.Path) -> set[str]:
    tree = ast.parse(file_path.read_text())
    names = set()
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            names.add(node.name)
        elif isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name):
                    names.add(target.id)
        elif isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name):
            names.add(node.target.id)
        elif isinstance(node, ast.ImportFrom):
            # Re-exports, e.g. app/models/__init__.py importing individual models
            for alias in node.names:
                names.add(alias.asname or alias.name)
        elif isinstance(node, ast.Import):
            for alias in node.names:
                names.add(alias.asname or alias.name.split(".")[0])
    return names


def check_file(file_path: pathlib.Path) -> list[str]:
    errors = []
    tree = ast.parse(file_path.read_text())

    def visit(node, in_function_body=False):
        for child in ast.walk(node):
            if isinstance(child, ast.ImportFrom) and child.module and child.module.startswith("app"):
                # Only check module-level imports strictly; imports inside function bodies
                # (deferred imports, common in this codebase to avoid circularity / lazy-load
                # optional deps) are checked too, since AST doesn't care about placement.
                target_file = module_path_to_file(child.module)
                if target_file is None:
                    errors.append(f"{file_path.relative_to(ROOT)}: cannot resolve module '{child.module}'")
                    continue
                available = top_level_names(target_file)
                for alias in child.names:
                    if alias.name == "*":
                        continue
                    if alias.name not in available:
                        errors.append(
                            f"{file_path.relative_to(ROOT)}: '{alias.name}' not found in "
                            f"{target_file.relative_to(ROOT)} (imported via 'from {child.module} import {alias.name}')"
                        )

    visit(tree)
    return errors


def main() -> int:
    all_errors = []
    for py_file in APP.rglob("*.py"):
        if "tests" in py_file.parts:
            continue
        all_errors.extend(check_file(py_file))

    if all_errors:
        print(f"FOUND {len(all_errors)} CROSS-REFERENCE ERRORS:")
        for e in all_errors:
            print(" -", e)
        return 1

    print("All internal imports resolve to real names. No cross-reference errors found.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
