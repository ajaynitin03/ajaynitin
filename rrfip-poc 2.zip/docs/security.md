# Security

## Authentication

Production: Microsoft Entra ID via MSAL.js on the frontend
(`frontend/src/pages/Login.tsx`, `frontend/src/api/msalConfig.ts`) using interactive login to
get an Entra ID-issued ID token. That token is POSTed to `POST /auth/login`
(`app/api/routes/auth.py`), which validates its signature against Microsoft's public JWKS
(`app/services/auth_service.py::validate_entra_id_token` — never trusts an unverified token),
looks up or creates the corresponding `User` row (first login gets the default
`REQUIREMENT_TEAM` role), and issues our OWN short-lived app JWT. The frontend stores that
app JWT and sends it as `Authorization: Bearer <token>` on every API call — the Entra ID
token itself is never forwarded past `/auth/login`.

The backend's Graph confidential client secret (`app/integrations/graph/auth.py`) is entirely
separate from this user-login flow — it authenticates the *app* to Graph for
Outlook/Teams/Excel access, not individual users, and the frontend never sees it.

**Local development without an Entra ID tenant:** `POST /auth/dev-token` issues an app JWT
directly, gated to `ENVIRONMENT=development` (returns 404 otherwise — hidden, not just
unauthorized). The frontend's Login page shows a "Continue with dev login" shortcut that
calls this when `VITE_ENABLE_DEV_LOGIN=true`. Never enable this outside local dev.

## Authorization (RBAC)

Roles: `REQUIREMENT_TEAM`, `DELIVERY_MANAGER`, `DELIVERY_PARTNER`, `ADMIN`, `AUDITOR`
(`app/core/enums.py::UserRole`).

All authorization is enforced server-side — the API never trusts a role claimed by the
client beyond what's in the validated JWT. Two enforcement points exist today:

1. `CurrentUser.require_role(...)` — used explicitly where an endpoint needs elevated access
   (e.g. approving/rejecting a human review).
2. `ROLES_ALLOWED_TO_REOPEN_CLOSED` — checked inside `fulfillment_service.transition_status`
   before allowing a `CLOSED -> *` transition, so this rule can't be bypassed by calling the
   service directly instead of the API.

## Secrets

- No secrets in source control. `.env.example` documents every variable but contains no
  real values; `.env` is git-ignored.
- Graph and LLM tokens are never logged. `app/integrations/graph/auth.py` and
  `app/ai/requirement_intelligence.py` both explicitly avoid logging response bodies that
  could contain a token.
- `JWT_SECRET_KEY` in `.env.example` is a placeholder (`change-me-in-production`) — the app
  will run with it, but treat that as a loud reminder to replace it, not a real secret.

## Input validation

Every API request body is a Pydantic model (`app/schemas/`) — FastAPI rejects malformed
input before it reaches a service function. Query parameters used in filters
(`app/repositories/requirement_repository.py`) go through SQLAlchemy's parameterized query
building, never raw string interpolation.

## The chat query endpoint specifically

`POST /chat/query` (`app/ai/chat_query.py`) is the one place in the system where an LLM's
output influences a database query — and it is deliberately constrained. The LLM chooses
among three predefined, parameterized tools (`QUERY_TOOLS`) and supplies only their declared
parameters; there is no code path from LLM output to a raw SQL string. Authorization
(the `get_current_user` dependency) is applied before the query layer is even reached.

## CORS

`CORS_ALLOW_ORIGINS` in `.env` is a comma-separated allowlist, defaulting to
`http://localhost:3000` for local dev. Do not set this to `*` in any environment that isn't
purely local.

## Error responses

API error responses use FastAPI's standard `HTTPException` with a short `detail` message.
None of the current error paths leak stack traces, SQL, or internal file paths to the client
— exceptions are caught and translated to a `detail` string before reaching the response.
