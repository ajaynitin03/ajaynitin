# API Reference

Base path: `/api/v1`. Interactive docs at `/docs` (Swagger UI) once the server is running.
All routes except `/health` and `/ready` require `Authorization: Bearer <jwt>`.

## Health

| Method | Path | Auth | Description |
|---|---|---|---|
| GET | `/health` | none | Liveness check |
| GET | `/ready` | none | Readiness check (verifies DB connectivity) |

## Auth

| Method | Path | Auth | Description |
|---|---|---|---|
| POST | `/auth/login` | none | Exchange a validated Entra ID token for an app JWT |
| POST | `/auth/dev-token` | none (dev env only, 404 elsewhere) | Issue an app JWT directly for local testing |

## Requirements

| Method | Path | Description |
|---|---|---|
| GET | `/requirements` | List, filterable by `status`, `skill`, `location` |
| POST | `/requirements` | Create a requirement manually |
| GET | `/requirements/{rjs}` | Fetch one by RJS |
| PATCH | `/requirements/{rjs}` | Update fields (audited per-field) |
| POST | `/requirements/{rjs}/status` | Transition fulfillment status |
| GET | `/requirements/{rjs}/matches` | Ranked resource matches |

## Resources

| Method | Path | Description |
|---|---|---|
| GET | `/resources` | List, filterable by `location`, `portfolio`, `available_only` |
| GET | `/resources/{resource_id}` | Fetch one, including its skills |

## Fulfillment

| Method | Path | Description |
|---|---|---|
| GET | `/fulfillment` | List current fulfillment records, filterable by `status` |
| GET | `/fulfillment/{rjs}` | Current fulfillment state for one requirement |

## Audit

| Method | Path | Description |
|---|---|---|
| GET | `/audit/{rjs}` | Full audit trail for one requirement, chronological |

## Review Queue

| Method | Path | Description |
|---|---|---|
| GET | `/reviews?status=PENDING` | List review items by status |
| POST | `/reviews/{id}/approve` | Approve (requires DM/Admin/Requirement Team role) |
| POST | `/reviews/{id}/reject` | Reject (same role requirement) |

## Analytics

| Method | Path | Description |
|---|---|---|
| GET | `/analytics/summary` | Total/open/identified/hold/closed counts + closure % |
| GET | `/analytics/status` | Raw status → count breakdown |
| GET | `/analytics/skills` | Top 20 skills by open-requirement demand |
| GET | `/analytics/aging` | Non-closed requirements ordered by age |

## Sync

| Method | Path | Description |
|---|---|---|
| GET | `/sync/status` | Last sync time/status/modifier per tracked Excel workbook |

## Graph Webhooks

| Method | Path | Description |
|---|---|---|
| POST | `/graph/webhook/outlook` | Graph change-notification receiver for Outlook |
| POST | `/graph/webhook/teams` | Graph change-notification receiver for Teams |

Both handle the Graph subscription-validation handshake and otherwise only accept POSTs from
Graph itself — see `docs/graph-integration.md`.

## Chat

| Method | Path | Description |
|---|---|---|
| POST | `/chat/query` | Natural-language query, answered via a fixed set of predefined tools — see `docs/security.md` |

Request body: `{"question": "How many requirements are on hold?"}`
