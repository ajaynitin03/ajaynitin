# Microsoft Graph Integration

## Client

`app/integrations/graph/client.py::GraphClient` is the single reusable Graph HTTP client.
Do not write new per-service HTTP request code — extend this class if you need a new Graph
capability.

`app/integrations/graph/auth.py::get_graph_access_token()` is the single MSAL token
acquisition function. It uses `ConfidentialClientApplication` (app-only auth, client
credentials flow) since this platform reads mailboxes/channels/workbooks on behalf of the
organization, not an individual signed-in user.

## Finding your workbook's stable identifiers

Never identify a workbook by filename (spec requirement — filenames can be renamed or moved).
To find the `site_id`, `drive_id`, and `item_id` for the Requirement Tracker / Resource
Tracker:

```
GET https://graph.microsoft.com/v1.0/sites/{hostname}:/sites/{site-path}
  → returns site "id" (this is your site_id)

GET https://graph.microsoft.com/v1.0/sites/{site_id}/drives
  → returns each document library's "id" (drive_id)

GET https://graph.microsoft.com/v1.0/sites/{site_id}/drives/{drive_id}/root/children
  → find your workbook by name here ONCE, then record its "id" (item_id) in .env —
    after that, the filename is never referenced again
```

Put the results in `.env`:
```
REQUIREMENT_TRACKER_SITE_ID=...
REQUIREMENT_TRACKER_DRIVE_ID=...
REQUIREMENT_TRACKER_ITEM_ID=...
```

## Outlook

`GraphClient.list_messages` / `get_message` for polling/reconciliation,
`subscribe_outlook_changes` for a Graph change-notification subscription. Webhook deliveries
land on `POST /api/v1/graph/webhook/outlook` (`app/api/routes/graph_webhooks.py`), which:

1. handles the Graph subscription-validation handshake (echoes `validationToken`)
2. checks the notification's `clientState` matches what we registered
3. writes a `SourceEvent` row (idempotent on `source_type` + `source_identifier`)
4. enqueues a `NORMALIZE_SOURCE_EVENT` job
5. returns `202` immediately — **no LLM work happens inside the webhook request**

Graph subscriptions expire (max ~3 days for mail) and must be renewed. The
`RENEW_GRAPH_SUBSCRIPTION` job type (`app/workers/handlers.py::handle_renew_graph_subscription`)
handles this — enqueue one with `{"subscription_id": "..."}` shortly before expiration
(e.g. from the value returned by `subscribe_outlook_changes`/`subscribe_teams_channel_changes`).
Scheduling *when* to enqueue that renewal job isn't automated yet — track expiration
alongside the subscription ID and enqueue proactively (a simple approach: enqueue a renewal
job with the subscription's actual expiration time recorded, checked by a periodic sweep
similar to `excel_sync_cli.py`).

## Teams

Same shape as Outlook, via `list_channel_messages` and
`subscribe_teams_channel_changes`, landing on `POST /api/v1/graph/webhook/teams`.

## Excel

`app/services/excel_sync_service.py::sync_workbook` is the entry point. It:

1. Fetches the drive item's metadata (`eTag`, `lastModifiedBy`, `lastModifiedDateTime`) via
   `GraphClient.get_drive_item`.
2. If the `eTag` hasn't changed since the last sync, stops early — no data fetch needed.
3. Otherwise fetches the tracked Excel table's rows via `get_worksheet_table_rows`, or via
   `get_worksheet_used_range` for workbooks that use a plain range instead of a named table
   (pass `worksheet_name` instead of `table_name` to `sync_workbook`).
4. Diffs each row against the last `ExcelSnapshot` (keyed by an authoritative ID column when
   available, otherwise a content hash) to find new/changed/unchanged rows.
5. Persists the new snapshot, writes an `AuditLog` entry per changed row, and enqueues a
   `NORMALIZE_SOURCE_EVENT` job per new/changed row, tagged with which workbook it came from
   so the job handler routes it to requirement vs. resource ingestion
   (`app/workers/handlers.py::handle_normalize_source_event`).
6. Updates `ExcelSyncState` with the new `eTag`/`lastModifiedBy`/`lastModifiedAt`.

Trigger a sync via `python -m app.workers.excel_sync_cli` (see `docs/setup.md`); it syncs
both tracked workbooks in one run and is meant to be scheduled periodically (cron / Task
Scheduler), separate from the reactive job worker loop.

This is intentionally honest about what Graph can and can't tell you: it never claims
cell-level authorship beyond the workbook-level `lastModifiedBy` Graph actually reports.

**Not yet run against a live workbook** — needs real Graph credentials and site/drive/item
IDs, which weren't available during development. The row-header assumption
(`raw_rows[0]["values"][0]` as the header row) matches Graph's table-rows response shape but
should be verified against your actual tracker's table structure before relying on it.

## Rate limits and throttling

Graph applies per-app and per-mailbox throttling. `GraphClient._request` retries on `429`,
`503`, and `504` up to 3 times, honoring the `Retry-After` header when present and falling
back to exponential backoff otherwise.
