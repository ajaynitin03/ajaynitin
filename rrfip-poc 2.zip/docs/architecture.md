# Architecture

## Shape: modular monolith

One FastAPI process, one PostgreSQL database, one lightweight worker process. No
microservices, no Redis/Celery/Kafka/Kubernetes — a one-week POC does not need that
operational surface area, and PostgreSQL alone is sufficient for both the durable job queue
and the audit trail.

```
Microsoft 365
    ↓
Microsoft Graph  (app/integrations/graph/)
    ↓
FastAPI Integration Layer  (app/api/routes/graph_webhooks.py, sync.py)
    ↓
Normalization  (app/integrations/mapping.py)
    ↓
Idempotency  (unique constraints on source_type+source_identifier)
    ↓
PostgreSQL
    ↓
PostgreSQL-backed Durable Job Queue  (app/models/job.py, app/workers/)
    ↓
LangGraph AI Processing  (app/ai/)
    ↓
Deterministic Business Services  (app/services/)
    ↓
PostgreSQL
    ↓
FastAPI APIs  (app/api/routes/)
    ↓
React Dashboard  (frontend/)
```

## Dependency direction

Enforced by convention (not a build-time check in this POC, but consistently followed):

```
API        → Service → Repository/DB
Graph      → Ingestion → Service
AI         → Service/domain
```

No service calls back into a service that called it. `app/services/requirement_service.py`
is the one exception worth naming explicitly: it composes `rjs_service`, `audit_service`, and
`fulfillment_service` — all one-directional, never circular.

## Layers

| Layer | Location | Responsibility |
|---|---|---|
| Models | `app/models/` | SQLAlchemy ORM, one file per aggregate |
| Repositories | `app/repositories/` | Plain DB queries, no business logic |
| Services | `app/services/` | Business rules — RJS, fulfillment transitions, audit, ingestion, duplicate detection, matching |
| AI | `app/ai/` | All LLM-provider-specific code; nowhere else calls an LLM directly |
| Integrations | `app/integrations/` | Graph client + source-to-canonical mapping |
| API | `app/api/` | FastAPI routes, request/response schemas, auth dependency |
| Workers | `app/workers/` | Job queue runner + handler registry |

## RJS generation

`app/services/rjs_service.py`. Two rules that must never be violated:

1. If the source system already has an authoritative identifier (Requirement Tracker's
   `Requirement Id` / `Request Id`, or an existing RJS), it is preserved as-is — never
   rewritten by application code or an LLM.
2. Otherwise, a new RJS is generated from a dedicated PostgreSQL `SEQUENCE`
   (`rjs_number_seq`), never `MAX(id) + 1`. The sequence's atomicity is what makes concurrent
   creation safe — there's no read-then-write window to race in. A residual duplicate-key
   conflict on `requirements.rjs` (extremely unlikely, but possible if an authoritative ID
   arrives from two sources in the same instant) is caught and re-resolved rather than
   retried blindly.

## Idempotency

Every ingestion path — Excel row, Outlook message, Teams message, manual API create — funnels
through a table with a `UNIQUE(source_type, source_identifier)` constraint
(`requirement_sources`, `source_events`). Replaying the same event is guaranteed to be a
no-op rather than creating a duplicate RJS.

## Fulfillment state machine

`app/core/enums.py::ALLOWED_TRANSITIONS` is the single source of truth for which status
transitions are legal. `app/services/fulfillment_service.py` is the only code that changes
`FulfillmentRecord.status`; it always writes a `FulfillmentEvent` and an `AuditLog` entry in
the same transaction. `CLOSED` cannot be exited by a normal user — only roles in
`ROLES_ALLOWED_TO_REOPEN_CLOSED`.

## Excel sync and change history

`app/services/excel_sync_service.py`. Graph does not give reliable cell-level authorship, so
this deliberately only claims what Graph actually reports: the workbook's `eTag`,
`lastModifiedBy`, and `lastModifiedDateTime`. Row-level change detection is done by diffing
the current fetch against the last `ExcelSnapshot` per deterministic row key (an authoritative
ID column when present, otherwise a content hash).

## Job queue

`app/models/job.py` + `app/workers/runner.py`. Uses `SELECT ... FOR UPDATE SKIP LOCKED` so
multiple worker processes can run without double-claiming a job. Job types and their handlers
are registered in `app/workers/handlers.py` — adding a new job type means adding one entry
there, nothing else changes.

## AI agents

Kept to five, per spec: Requirement Intelligence (`app/ai/requirement_intelligence.py`),
RJS & Duplicate Detection (`app/services/duplicate_detection_service.py` — deterministic +
fuzzy, not AI-driven), Resource Intelligence / Matching
(`app/services/resource_matching_service.py` — deterministic filter + weighted ranking),
Fulfillment Intelligence (implicit in `fulfillment_service.py`'s transition rules). The
conversational query layer (`app/ai/chat_query.py`) is a constrained tool-calling setup, not
free-form SQL generation — see `docs/security.md`.
