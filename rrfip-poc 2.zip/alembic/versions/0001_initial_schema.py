"""initial schema

Revision ID: 0001
Revises:
Create Date: 2026-08-18
"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql as pg

revision = "0001"
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.execute("CREATE EXTENSION IF NOT EXISTS \"uuid-ossp\"")

    # Dedicated sequence for deterministic RJS generation (never MAX(id)+1).
    op.execute("CREATE SEQUENCE IF NOT EXISTS rjs_number_seq START 1 INCREMENT 1")

    op.create_table(
        "users",
        sa.Column("id", pg.UUID(as_uuid=True), primary_key=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("email", sa.String(255), nullable=False, unique=True),
        sa.Column("display_name", sa.String(255), nullable=False),
        sa.Column("entra_object_id", sa.String(255), unique=True),
        sa.Column("is_active", sa.Boolean, nullable=False, server_default=sa.true()),
    )

    op.create_table(
        "user_roles",
        sa.Column("id", pg.UUID(as_uuid=True), primary_key=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("user_id", pg.UUID(as_uuid=True), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("role", sa.String(50), nullable=False),
        sa.UniqueConstraint("user_id", "role", name="uq_user_role"),
    )

    op.create_table(
        "requirements",
        sa.Column("id", pg.UUID(as_uuid=True), primary_key=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("rjs", sa.String(64), nullable=False, unique=True),
        sa.Column("source_request_id", sa.String(64)),
        sa.Column("source_requirement_id", sa.String(64)),
        sa.Column("account_portfolio", sa.String(255)),
        sa.Column("country", sa.String(100)),
        sa.Column("location", sa.String(255)),
        sa.Column("skill_category", sa.String(100)),
        sa.Column("skill", sa.String(500)),
        sa.Column("role", sa.String(50)),
        sa.Column("billing_type", sa.String(20)),
        sa.Column("ce_mandatory", sa.Boolean),
        sa.Column("requirement_type", sa.String(20)),
        sa.Column("quantity", sa.Integer, nullable=False, server_default="1"),
        sa.Column("portfolio_team", sa.String(255)),
        sa.Column("requester", sa.String(255)),
        sa.Column("priority", sa.String(20)),
        sa.Column("requirement_open_date", sa.Date),
        sa.Column("billing_start_date", sa.Date),
        sa.Column("remarks", sa.String(2000)),
        sa.Column("extra", pg.JSONB, nullable=False, server_default="{}"),
    )
    op.create_index("ix_requirements_rjs", "requirements", ["rjs"])
    op.create_index("ix_requirements_location", "requirements", ["location"])
    op.create_index("ix_requirements_skill_category", "requirements", ["skill_category"])
    op.create_index("ix_requirements_account_portfolio", "requirements", ["account_portfolio"])

    op.create_table(
        "requirement_sources",
        sa.Column("id", pg.UUID(as_uuid=True), primary_key=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("requirement_id", pg.UUID(as_uuid=True), sa.ForeignKey("requirements.id"), nullable=False),
        sa.Column("source_type", sa.String(30), nullable=False),
        sa.Column("source_identifier", sa.String(500), nullable=False),
        sa.Column("raw_payload", pg.JSONB, nullable=False, server_default="{}"),
        sa.UniqueConstraint("source_type", "source_identifier", name="uq_requirement_source_identity"),
    )

    op.create_table(
        "requirement_versions",
        sa.Column("id", pg.UUID(as_uuid=True), primary_key=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("requirement_id", pg.UUID(as_uuid=True), sa.ForeignKey("requirements.id"), nullable=False),
        sa.Column("snapshot", pg.JSONB, nullable=False),
        sa.Column("changed_by", sa.String(255)),
        sa.Column("change_reason", sa.String(255)),
    )

    op.create_table(
        "resources",
        sa.Column("id", pg.UUID(as_uuid=True), primary_key=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("employee_id", sa.String(64), nullable=False, unique=True),
        sa.Column("name", sa.String(255)),
        sa.Column("grade", sa.String(20)),
        sa.Column("location", sa.String(255)),
        sa.Column("source_channel", sa.String(50)),
        sa.Column("phone", sa.String(50)),
        sa.Column("portfolio", sa.String(255)),
        sa.Column("category", sa.String(50)),
        sa.Column("detailed_status", sa.String(255)),
        sa.Column("rmg_status", sa.String(50)),
        sa.Column("is_available", sa.Boolean),
        sa.Column("entry_date", sa.Date),
        sa.Column("remarks", sa.String(2000)),
        sa.Column("extra", pg.JSONB, nullable=False, server_default="{}"),
    )
    op.create_index("ix_resources_location", "resources", ["location"])
    op.create_index("ix_resources_portfolio", "resources", ["portfolio"])

    op.create_table(
        "resource_skills",
        sa.Column("id", pg.UUID(as_uuid=True), primary_key=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("resource_id", pg.UUID(as_uuid=True), sa.ForeignKey("resources.id"), nullable=False),
        sa.Column("skill", sa.String(255), nullable=False),
        sa.UniqueConstraint("resource_id", "skill", name="uq_resource_skill"),
    )
    op.create_index("ix_resource_skills_skill", "resource_skills", ["skill"])

    op.create_table(
        "fulfillment_records",
        sa.Column("id", pg.UUID(as_uuid=True), primary_key=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("requirement_id", pg.UUID(as_uuid=True), sa.ForeignKey("requirements.id"), nullable=False, unique=True),
        sa.Column("status", sa.String(20), nullable=False, server_default="OPEN"),
        sa.Column("matched_resource_id", pg.UUID(as_uuid=True), sa.ForeignKey("resources.id")),
        sa.Column("delivery_manager", sa.String(255)),
        sa.Column("delivery_partner", sa.String(255)),
        sa.Column("updated_by", sa.String(255)),
    )
    op.create_index("ix_fulfillment_records_status", "fulfillment_records", ["status"])

    op.create_table(
        "fulfillment_events",
        sa.Column("id", pg.UUID(as_uuid=True), primary_key=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("fulfillment_record_id", pg.UUID(as_uuid=True), sa.ForeignKey("fulfillment_records.id"), nullable=False),
        sa.Column("from_status", sa.String(20)),
        sa.Column("to_status", sa.String(20), nullable=False),
        sa.Column("actor", sa.String(255)),
        sa.Column("reason", sa.String(1000)),
        sa.Column("correlation_id", sa.String(100)),
        sa.Column("meta", pg.JSONB, nullable=False, server_default="{}"),
    )

    op.create_table(
        "source_events",
        sa.Column("id", pg.UUID(as_uuid=True), primary_key=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("source_type", sa.String(30), nullable=False),
        sa.Column("source_identifier", sa.String(500), nullable=False),
        sa.Column("raw_payload", pg.JSONB, nullable=False, server_default="{}"),
        sa.Column("processed", sa.Boolean, nullable=False, server_default=sa.false()),
        sa.Column("processing_error", sa.String(2000)),
        sa.UniqueConstraint("source_type", "source_identifier", name="uq_source_event_identity"),
    )

    op.create_table(
        "excel_sync_state",
        sa.Column("id", pg.UUID(as_uuid=True), primary_key=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("workbook_name", sa.String(255), nullable=False),
        sa.Column("site_id", sa.String(255), nullable=False),
        sa.Column("drive_id", sa.String(255), nullable=False),
        sa.Column("item_id", sa.String(255), nullable=False),
        sa.Column("worksheet_or_table", sa.String(255)),
        sa.Column("last_etag", sa.String(255)),
        sa.Column("last_version", sa.String(100)),
        sa.Column("last_modified_by", sa.String(255)),
        sa.Column("last_modified_at", sa.DateTime(timezone=True)),
        sa.Column("last_synced_at", sa.DateTime(timezone=True)),
        sa.Column("sync_status", sa.String(50)),
        sa.UniqueConstraint("site_id", "drive_id", "item_id", name="uq_excel_workbook_identity"),
    )

    op.create_table(
        "excel_snapshots",
        sa.Column("id", pg.UUID(as_uuid=True), primary_key=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("excel_sync_state_id", pg.UUID(as_uuid=True), sa.ForeignKey("excel_sync_state.id"), nullable=False),
        sa.Column("row_key", sa.String(255), nullable=False),
        sa.Column("row_data", pg.JSONB, nullable=False),
    )

    op.create_table(
        "audit_logs",
        sa.Column("id", pg.UUID(as_uuid=True), primary_key=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("actor", sa.String(255)),
        sa.Column("action", sa.String(100), nullable=False),
        sa.Column("entity", sa.String(100), nullable=False),
        sa.Column("entity_id", sa.String(100)),
        sa.Column("rjs", sa.String(64)),
        sa.Column("field", sa.String(100)),
        sa.Column("old_value", sa.String(2000)),
        sa.Column("new_value", sa.String(2000)),
        sa.Column("source", sa.String(50)),
        sa.Column("correlation_id", sa.String(100)),
        sa.Column("meta", pg.JSONB, nullable=False, server_default="{}"),
    )
    op.create_index("ix_audit_logs_rjs", "audit_logs", ["rjs"])
    op.create_index("ix_audit_logs_entity", "audit_logs", ["entity"])
    op.create_index("ix_audit_logs_action", "audit_logs", ["action"])

    op.create_table(
        "ai_runs",
        sa.Column("id", pg.UUID(as_uuid=True), primary_key=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("agent_name", sa.String(100), nullable=False),
        sa.Column("requirement_id", pg.UUID(as_uuid=True), sa.ForeignKey("requirements.id")),
        sa.Column("model", sa.String(100), nullable=False),
        sa.Column("input_summary", pg.JSONB, nullable=False, server_default="{}"),
        sa.Column("output", pg.JSONB, nullable=False, server_default="{}"),
        sa.Column("confidence", sa.Numeric(4, 3)),
        sa.Column("success", sa.Boolean, nullable=False, server_default=sa.true()),
        sa.Column("error", sa.String(2000)),
    )

    op.create_table(
        "resource_matches",
        sa.Column("id", pg.UUID(as_uuid=True), primary_key=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("requirement_id", pg.UUID(as_uuid=True), sa.ForeignKey("requirements.id"), nullable=False),
        sa.Column("resource_id", pg.UUID(as_uuid=True), sa.ForeignKey("resources.id"), nullable=False),
        sa.Column("score", sa.Numeric(6, 3), nullable=False),
        sa.Column("rank", sa.Integer, nullable=False),
        sa.Column("reasons", pg.JSONB, nullable=False, server_default="{}"),
    )

    op.create_table(
        "human_reviews",
        sa.Column("id", pg.UUID(as_uuid=True), primary_key=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("requirement_id", pg.UUID(as_uuid=True), sa.ForeignKey("requirements.id")),
        sa.Column("reason", sa.String(255), nullable=False),
        sa.Column("status", sa.String(20), nullable=False, server_default="PENDING"),
        sa.Column("duplicate_verdict", sa.String(30)),
        sa.Column("context", pg.JSONB, nullable=False, server_default="{}"),
        sa.Column("decided_by", sa.String(255)),
        sa.Column("decision_notes", sa.String(1000)),
    )

    op.create_table(
        "jobs",
        sa.Column("id", pg.UUID(as_uuid=True), primary_key=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("type", sa.String(50), nullable=False),
        sa.Column("status", sa.String(20), nullable=False, server_default="PENDING"),
        sa.Column("payload", pg.JSONB, nullable=False, server_default="{}"),
        sa.Column("attempts", sa.Integer, nullable=False, server_default="0"),
        sa.Column("max_attempts", sa.Integer, nullable=False, server_default="5"),
        sa.Column("priority", sa.Integer, nullable=False, server_default="100"),
        sa.Column("correlation_id", sa.String(100)),
        sa.Column("started_at", sa.DateTime(timezone=True)),
        sa.Column("completed_at", sa.DateTime(timezone=True)),
        sa.Column("last_error", sa.String(2000)),
    )
    op.create_index("ix_jobs_type", "jobs", ["type"])
    op.create_index("ix_jobs_status", "jobs", ["status"])
    op.create_index("ix_jobs_correlation_id", "jobs", ["correlation_id"])


def downgrade() -> None:
    for table in [
        "jobs", "human_reviews", "resource_matches", "ai_runs", "audit_logs",
        "excel_snapshots", "excel_sync_state", "source_events", "fulfillment_events",
        "fulfillment_records", "resource_skills", "resources", "requirement_versions",
        "requirement_sources", "requirements", "user_roles", "users",
    ]:
        op.drop_table(table)
    op.execute("DROP SEQUENCE IF EXISTS rjs_number_seq")
