"""add graph_subscriptions table

Revision ID: 0002
Revises: 0001
Create Date: 2026-08-19
"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql as pg

revision = "0002"
down_revision = "0001"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "graph_subscriptions",
        sa.Column("id", pg.UUID(as_uuid=True), primary_key=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("subscription_id", sa.String(255), nullable=False, unique=True),
        sa.Column("resource_type", sa.String(30), nullable=False),
        sa.Column("resource", sa.String(500), nullable=False),
        sa.Column("notification_url", sa.String(500), nullable=False),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("last_renewed_at", sa.DateTime(timezone=True)),
        sa.Column("is_active", sa.Boolean, nullable=False, server_default=sa.true()),
    )
    op.create_index("ix_graph_subscriptions_subscription_id", "graph_subscriptions", ["subscription_id"])
    op.create_index("ix_graph_subscriptions_expires_at", "graph_subscriptions", ["expires_at"])


def downgrade() -> None:
    op.drop_table("graph_subscriptions")
