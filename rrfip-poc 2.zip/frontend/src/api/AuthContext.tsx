import { createContext, useContext, useEffect, useState, ReactNode } from "react";
import { clearAuthToken, getAuthToken, onAuthTokenChange } from "./client";

interface AuthContextValue {
  isAuthenticated: boolean;
  refresh: () => void;
  logout: () => void;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [isAuthenticated, setIsAuthenticated] = useState(Boolean(getAuthToken()));

  const refresh = () => setIsAuthenticated(Boolean(getAuthToken()));

  const logout = () => {
    clearAuthToken();
    setIsAuthenticated(false);
  };

  // Pick up token changes made in another tab (native storage event) AND same-tab changes
  // such as a 401 clearing the token mid-session (client.ts's onAuthTokenChange bridge).
  useEffect(() => {
    const handler = () => refresh();
    window.addEventListener("storage", handler);
    const unsubscribe = onAuthTokenChange(handler);
    return () => {
      window.removeEventListener("storage", handler);
      unsubscribe();
    };
  }, []);

  return (
    <AuthContext.Provider value={{ isAuthenticated, refresh, logout }}>{children}</AuthContext.Provider>
  );
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
