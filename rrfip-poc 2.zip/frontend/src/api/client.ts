/**
 * Single reusable API client. Components never call fetch() directly (spec section 37:
 * keep React API calls isolated from UI components).
 */
// In local dev (vite dev), relative /api/v1 is proxied to the backend by vite.config.ts's
// server.proxy. That proxy is a dev-server-only feature -- it does NOT apply to the
// production build served by frontend/Dockerfile's `serve -s dist`. For Docker/production,
// set VITE_API_BASE_URL to the backend's full URL at build time (see docker-compose.yml).
const API_BASE = (import.meta.env.VITE_API_BASE_URL as string | undefined) || "/api/v1";
const TOKEN_STORAGE_KEY = "rrfip_access_token";

// Minimal same-tab pub-sub so AuthContext can react to a 401 clearing the token. The
// browser's native "storage" event only fires in OTHER tabs, never the tab that made the
// change -- without this, a 401 in this module would silently desync from AuthContext's
// in-memory isAuthenticated state until the next full page reload.
type AuthChangeListener = () => void;
const authChangeListeners = new Set<AuthChangeListener>();

export function onAuthTokenChange(listener: AuthChangeListener): () => void {
  authChangeListeners.add(listener);
  return () => authChangeListeners.delete(listener);
}

function notifyAuthTokenChange(): void {
  authChangeListeners.forEach((listener) => listener());
}

export function getAuthToken(): string | null {
  return localStorage.getItem(TOKEN_STORAGE_KEY);
}

export function setAuthToken(token: string): void {
  localStorage.setItem(TOKEN_STORAGE_KEY, token);
  notifyAuthTokenChange();
}

export function clearAuthToken(): void {
  localStorage.removeItem(TOKEN_STORAGE_KEY);
  notifyAuthTokenChange();
}

async function request<T>(path: string, options: RequestInit = {}): Promise<T> {
  const token = getAuthToken();
  const response = await fetch(`${API_BASE}${path}`, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...options.headers,
    },
  });
  if (response.status === 401) {
    clearAuthToken();
  }
  if (!response.ok) {
    const body = await response.text();
    throw new Error(`API error ${response.status}: ${body}`);
  }
  if (response.status === 204) return undefined as T;
  return response.json();
}

export const api = {
  get: <T>(path: string) => request<T>(path, { method: "GET" }),
  post: <T>(path: string, body?: unknown) =>
    request<T>(path, { method: "POST", body: body ? JSON.stringify(body) : undefined }),
  patch: <T>(path: string, body?: unknown) =>
    request<T>(path, { method: "PATCH", body: body ? JSON.stringify(body) : undefined }),
};
