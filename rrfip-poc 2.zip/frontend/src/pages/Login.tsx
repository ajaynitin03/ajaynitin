import { useState } from "react";
import { api } from "../api/client";
import { setAuthToken } from "../api/client";
import { useAuth } from "../api/AuthContext";
import { isDevLoginEnabled, isEntraConfigured, loginRequest, msalInstance } from "../api/msalConfig";

export function Login() {
  const { refresh } = useAuth();
  const [error, setError] = useState<string | null>(null);
  const [devEmail, setDevEmail] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleEntraLogin() {
    setError(null);
    setLoading(true);
    try {
      await msalInstance.initialize();
      const result = await msalInstance.loginPopup(loginRequest);
      const entraIdToken = result.idToken;
      const { access_token } = await api.post<{ access_token: string }>("/auth/login", {
        entra_id_token: entraIdToken,
      });
      setAuthToken(access_token);
      refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setLoading(false);
    }
  }

  async function handleDevLogin() {
    if (!devEmail.trim()) {
      setError("Enter an email to use the dev login.");
      return;
    }
    setError(null);
    setLoading(true);
    try {
      const { access_token } = await api.post<{ access_token: string }>("/auth/dev-token", {
        email: devEmail.trim(),
        roles: ["REQUIREMENT_TEAM"],
      });
      setAuthToken(access_token);
      refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setLoading(false);
    }
  }

  return (
    <div style={{ display: "flex", alignItems: "center", justifyContent: "center", minHeight: "100vh" }}>
      <div className="card" style={{ width: 360, padding: 28 }}>
        <h2 style={{ marginTop: 0 }}>Sign in</h2>
        <p style={{ color: "var(--color-text-muted)", fontSize: 13 }}>
          Resource Requirement &amp; Fulfillment Intelligence Platform
        </p>

        {error && <div className="error-banner">{error}</div>}

        {isEntraConfigured ? (
          <button disabled={loading} onClick={handleEntraLogin} style={{ width: "100%", padding: 10 }}>
            Sign in with Microsoft
          </button>
        ) : (
          <div className="error-banner">
            Entra ID isn't configured (missing VITE_ENTRA_CLIENT_ID / VITE_ENTRA_TENANT_ID).
          </div>
        )}

        {isDevLoginEnabled && (
          <div style={{ marginTop: 20, paddingTop: 20, borderTop: "1px solid var(--color-border)" }}>
            <p style={{ fontSize: 12, color: "var(--color-text-muted)" }}>Local development only</p>
            <input
              placeholder="you@example.com"
              value={devEmail}
              onChange={(e) => setDevEmail(e.target.value)}
              style={{ width: "100%", marginBottom: 8, padding: 8 }}
            />
            <button disabled={loading} onClick={handleDevLogin} style={{ width: "100%", padding: 10 }}>
              Continue with dev login
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
