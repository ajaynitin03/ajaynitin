import { useParams } from "react-router-dom";
import { api } from "../api/client";
import { useApiData } from "../api/useApiData";
import { StatusBadge } from "../components/StatusBadge";
import { AuditLogEntry, FulfillmentRecord, Requirement } from "../types";

interface ResourceMatch {
  resource_id: string;
  score: number;
  rank: number;
  reasons: Record<string, number>;
}

export function RequirementDetail() {
  const { rjs } = useParams<{ rjs: string }>();

  const { data: requirement, error: reqError } = useApiData<Requirement>(
    () => api.get<Requirement>(`/requirements/${rjs}`),
    [rjs]
  );
  const { data: fulfillment } = useApiData<FulfillmentRecord>(
    () => api.get<FulfillmentRecord>(`/fulfillment/${rjs}`),
    [rjs]
  );
  const { data: matches } = useApiData<ResourceMatch[]>(
    () => api.get<ResourceMatch[]>(`/requirements/${rjs}/matches`),
    [rjs]
  );
  const { data: auditTrail } = useApiData<AuditLogEntry[]>(
    () => api.get<AuditLogEntry[]>(`/audit/${rjs}`),
    [rjs]
  );

  if (reqError) return <div className="error-banner">{reqError}</div>;
  if (!requirement) return <p>Loading...</p>;

  return (
    <div>
      <h2 className="page-title">
        {requirement.rjs} {fulfillment && <StatusBadge status={fulfillment.status} />}
      </h2>

      <div className="card" style={{ marginBottom: 20 }}>
        <table>
          <tbody>
            <Row label="Account/Portfolio" value={requirement.account_portfolio} />
            <Row label="Skill" value={requirement.skill} />
            <Row label="Skill Category" value={requirement.skill_category} />
            <Row label="Location" value={requirement.location} />
            <Row label="Role" value={requirement.role} />
            <Row label="Billing Type" value={requirement.billing_type} />
            <Row label="Requirement Type" value={requirement.requirement_type} />
            <Row label="Quantity" value={requirement.quantity} />
            <Row label="Remarks" value={requirement.remarks} />
          </tbody>
        </table>
      </div>

      <h3>Resource Matches</h3>
      <div className="card" style={{ marginBottom: 20 }}>
        {matches && matches.length > 0 ? (
          <table>
            <thead>
              <tr>
                <th>Rank</th>
                <th>Resource</th>
                <th>Score</th>
              </tr>
            </thead>
            <tbody>
              {matches.map((m) => (
                <tr key={m.resource_id}>
                  <td>{m.rank}</td>
                  <td>{m.resource_id}</td>
                  <td>{m.score.toFixed(2)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <div className="empty-state">No resource matches yet.</div>
        )}
      </div>

      <h3>Audit Timeline</h3>
      <div className="card">
        {auditTrail && auditTrail.length > 0 ? (
          <table>
            <thead>
              <tr>
                <th>When</th>
                <th>Actor</th>
                <th>Action</th>
                <th>Field</th>
                <th>Old → New</th>
              </tr>
            </thead>
            <tbody>
              {auditTrail.map((entry) => (
                <tr key={entry.id}>
                  <td>{new Date(entry.created_at).toLocaleString()}</td>
                  <td>{entry.actor ?? "system"}</td>
                  <td>{entry.action}</td>
                  <td>{entry.field ?? "—"}</td>
                  <td>
                    {entry.old_value ?? "—"} → {entry.new_value ?? "—"}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <div className="empty-state">No audit history yet.</div>
        )}
      </div>
    </div>
  );
}

function Row({ label, value }: { label: string; value: string | number | null | undefined }) {
  return (
    <tr>
      <th style={{ width: 180 }}>{label}</th>
      <td>{value ?? "—"}</td>
    </tr>
  );
}
