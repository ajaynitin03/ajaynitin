import { useState } from "react";
import { api } from "../api/client";
import { useApiData } from "../api/useApiData";
import { HumanReview } from "../types";

export function ReviewQueue() {
  const [refreshKey, setRefreshKey] = useState(0);
  const { data, loading, error } = useApiData<HumanReview[]>(
    () => api.get<HumanReview[]>("/reviews?status=PENDING"),
    [refreshKey]
  );

  async function decide(id: string, action: "approve" | "reject") {
    await api.post(`/reviews/${id}/${action}`);
    setRefreshKey((k) => k + 1);
  }

  return (
    <div>
      <h2 className="page-title">Review Queue</h2>
      {error && <div className="error-banner">{error}</div>}
      {loading && <p>Loading...</p>}

      {data && (
        <div className="card">
          {data.length === 0 ? (
            <div className="empty-state">No pending reviews.</div>
          ) : (
            <table>
              <thead>
                <tr>
                  <th>Reason</th>
                  <th>Verdict</th>
                  <th>Context</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {data.map((review) => (
                  <tr key={review.id}>
                    <td>{review.reason}</td>
                    <td>{review.duplicate_verdict ?? "—"}</td>
                    <td style={{ maxWidth: 300, whiteSpace: "normal" }}>
                      {JSON.stringify(review.context)}
                    </td>
                    <td>
                      <button onClick={() => decide(review.id, "approve")}>Approve</button>{" "}
                      <button onClick={() => decide(review.id, "reject")}>Reject</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      )}
    </div>
  );
}
