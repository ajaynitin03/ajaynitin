import { api } from "../api/client";
import { useApiData } from "../api/useApiData";
import { AnalyticsSummary } from "../types";

export function Dashboard() {
  const { data, loading, error } = useApiData<AnalyticsSummary>(() =>
    api.get<AnalyticsSummary>("/analytics/summary")
  );

  return (
    <div>
      <h2 className="page-title">Dashboard</h2>
      {error && <div className="error-banner">{error}</div>}
      {loading && <p>Loading...</p>}
      {data && (
        <div className="kpi-grid">
          <Kpi label="Total" value={data.total} />
          <Kpi label="Open" value={data.open} />
          <Kpi label="Identified" value={data.identified} />
          <Kpi label="Hold" value={data.hold} />
          <Kpi label="Closed" value={data.closed} />
          <Kpi label="Closure %" value={`${data.closure_pct}%`} />
        </div>
      )}
    </div>
  );
}

function Kpi({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="kpi-card">
      <div className="kpi-label">{label}</div>
      <div className="kpi-value">{value}</div>
    </div>
  );
}
