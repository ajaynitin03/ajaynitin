import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { api } from "../api/client";
import { useApiData } from "../api/useApiData";
import { StatusBadge } from "../components/StatusBadge";
import { Requirement } from "../types";

export function FulfillmentTracker() {
  const [statusFilter, setStatusFilter] = useState("");
  const [skillFilter, setSkillFilter] = useState("");
  const [locationFilter, setLocationFilter] = useState("");
  const navigate = useNavigate();

  const { data, loading, error } = useApiData<Requirement[]>(
    () =>
      api.get<Requirement[]>(
        `/requirements?${new URLSearchParams({
          ...(statusFilter ? { status: statusFilter } : {}),
          ...(skillFilter ? { skill: skillFilter } : {}),
          ...(locationFilter ? { location: locationFilter } : {}),
        })}`
      ),
    [statusFilter, skillFilter, locationFilter]
  );

  return (
    <div>
      <h2 className="page-title">Fulfillment Tracker</h2>

      <div className="filters-row">
        <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}>
          <option value="">All statuses</option>
          <option value="OPEN">Open</option>
          <option value="IDENTIFIED">Identified</option>
          <option value="HOLD">Hold</option>
          <option value="CLOSED">Closed</option>
        </select>
        <input placeholder="Filter by skill" value={skillFilter} onChange={(e) => setSkillFilter(e.target.value)} />
        <input
          placeholder="Filter by location"
          value={locationFilter}
          onChange={(e) => setLocationFilter(e.target.value)}
        />
      </div>

      {error && <div className="error-banner">{error}</div>}
      {loading && <p>Loading...</p>}

      {data && (
        <div className="card">
          <table>
            <thead>
              <tr>
                <th>RJS</th>
                <th>Skill</th>
                <th>Location</th>
                <th>Portfolio</th>
                <th>Qty</th>
                <th>Type</th>
                <th>Created</th>
              </tr>
            </thead>
            <tbody>
              {data.map((req) => (
                <tr key={req.id} onClick={() => navigate(`/requirements/${req.rjs}`)}>
                  <td className="rjs-link">{req.rjs}</td>
                  <td>{req.skill ?? "—"}</td>
                  <td>{req.location ?? "—"}</td>
                  <td>{req.account_portfolio ?? "—"}</td>
                  <td>{req.quantity}</td>
                  <td>{req.requirement_type ?? "—"}</td>
                  <td>{new Date(req.created_at).toLocaleDateString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
          {data.length === 0 && <div className="empty-state">No requirements match these filters.</div>}
        </div>
      )}
    </div>
  );
}
