import { api } from "../api/client";
import { useApiData } from "../api/useApiData";

interface SkillDemand {
  skill: string;
  demand: number;
}

export function Analytics() {
  const { data, loading, error } = useApiData<SkillDemand[]>(() =>
    api.get<SkillDemand[]>("/analytics/skills")
  );

  return (
    <div>
      <h2 className="page-title">Analytics</h2>
      {error && <div className="error-banner">{error}</div>}
      {loading && <p>Loading...</p>}

      <h3>Skill Demand</h3>
      {data && (
        <div className="card">
          <table>
            <thead>
              <tr>
                <th>Skill</th>
                <th>Open Requirements</th>
              </tr>
            </thead>
            <tbody>
              {data.map((row) => (
                <tr key={row.skill}>
                  <td>{row.skill}</td>
                  <td>{row.demand}</td>
                </tr>
              ))}
            </tbody>
          </table>
          {data.length === 0 && <div className="empty-state">No data yet.</div>}
        </div>
      )}
    </div>
  );
}
