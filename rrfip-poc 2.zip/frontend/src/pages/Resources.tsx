import { useState } from "react";
import { api } from "../api/client";
import { useApiData } from "../api/useApiData";

interface ResourceRow {
  id: string;
  employee_id: string;
  location: string | null;
  portfolio: string | null;
  grade: string | null;
  is_available: boolean | null;
  detailed_status: string | null;
}

export function Resources() {
  const [locationFilter, setLocationFilter] = useState("");
  const [availableOnly, setAvailableOnly] = useState(false);

  const { data, loading, error } = useApiData<ResourceRow[]>(
    () =>
      api.get<ResourceRow[]>(
        `/resources?${new URLSearchParams({
          ...(locationFilter ? { location: locationFilter } : {}),
          ...(availableOnly ? { available_only: "true" } : {}),
        })}`
      ),
    [locationFilter, availableOnly]
  );

  return (
    <div>
      <h2 className="page-title">Resources</h2>

      <div className="filters-row">
        <input
          placeholder="Filter by location"
          value={locationFilter}
          onChange={(e) => setLocationFilter(e.target.value)}
        />
        <label style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 13 }}>
          <input type="checkbox" checked={availableOnly} onChange={(e) => setAvailableOnly(e.target.checked)} />
          Available only
        </label>
      </div>

      {error && <div className="error-banner">{error}</div>}
      {loading && <p>Loading...</p>}

      {data && (
        <div className="card">
          <table>
            <thead>
              <tr>
                <th>Emp ID</th>
                <th>Location</th>
                <th>Portfolio</th>
                <th>Grade</th>
                <th>Status</th>
                <th>Available</th>
              </tr>
            </thead>
            <tbody>
              {data.map((r) => (
                <tr key={r.id}>
                  <td>{r.employee_id}</td>
                  <td>{r.location ?? "—"}</td>
                  <td>{r.portfolio ?? "—"}</td>
                  <td>{r.grade ?? "—"}</td>
                  <td>{r.detailed_status ?? "—"}</td>
                  <td>{r.is_available === null ? "—" : r.is_available ? "Yes" : "No"}</td>
                </tr>
              ))}
            </tbody>
          </table>
          {data.length === 0 && <div className="empty-state">No resources match these filters.</div>}
        </div>
      )}
    </div>
  );
}
