import { BrowserRouter, Routes, Route, NavLink, Navigate } from "react-router-dom";
import { AuthProvider, useAuth } from "./api/AuthContext";
import { RequireAuth } from "./components/RequireAuth";
import { Dashboard } from "./pages/Dashboard";
import { FulfillmentTracker } from "./pages/FulfillmentTracker";
import { Login } from "./pages/Login";
import { RequirementDetail } from "./pages/RequirementDetail";
import { Resources } from "./pages/Resources";
import { ReviewQueue } from "./pages/ReviewQueue";
import { Analytics } from "./pages/Analytics";

const NAV_ITEMS = [
  { to: "/", label: "Dashboard", end: true },
  { to: "/fulfillment", label: "Fulfillment Tracker" },
  { to: "/resources", label: "Resources" },
  { to: "/reviews", label: "Review Queue" },
  { to: "/analytics", label: "Analytics" },
];

function Shell({ children }: { children: React.ReactNode }) {
  const { logout } = useAuth();
  return (
    <div className="app-shell">
      <aside className="sidebar">
        <h1>Resource Requirement &amp; Fulfillment Intelligence</h1>
        <nav>
          {NAV_ITEMS.map((item) => (
            <NavLink key={item.to} to={item.to} end={item.end}>
              {item.label}
            </NavLink>
          ))}
        </nav>
        <button onClick={logout} style={{ marginTop: 24, width: "100%", padding: 8 }}>
          Sign out
        </button>
      </aside>
      <main className="main-content">{children}</main>
    </div>
  );
}

function AuthedRoutes() {
  return (
    <RequireAuth>
      <Shell>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/fulfillment" element={<FulfillmentTracker />} />
          <Route path="/requirements/:rjs" element={<RequirementDetail />} />
          <Route path="/resources" element={<Resources />} />
          <Route path="/reviews" element={<ReviewQueue />} />
          <Route path="/analytics" element={<Analytics />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </Shell>
    </RequireAuth>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/*" element={<AuthedRoutes />} />
        </Routes>
      </AuthProvider>
    </BrowserRouter>
  );
}
