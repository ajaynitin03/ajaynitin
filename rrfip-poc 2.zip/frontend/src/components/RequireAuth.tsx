import { Navigate } from "react-router-dom";
import { ReactElement } from "react";
import { useAuth } from "../api/AuthContext";

export function RequireAuth({ children }: { children: ReactElement }) {
  const { isAuthenticated } = useAuth();
  if (!isAuthenticated) return <Navigate to="/login" replace />;
  return children;
}
