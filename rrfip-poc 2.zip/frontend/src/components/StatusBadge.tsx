import { FulfillmentStatus } from "../types";

export function StatusBadge({ status }: { status: FulfillmentStatus }) {
  return <span className={`status-badge status-${status.toLowerCase()}`}>{status}</span>;
}
