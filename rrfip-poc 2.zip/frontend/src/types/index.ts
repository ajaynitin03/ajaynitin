export type FulfillmentStatus = "OPEN" | "IDENTIFIED" | "HOLD" | "CLOSED";

export interface Requirement {
  id: string;
  rjs: string;
  account_portfolio: string | null;
  country: string | null;
  location: string | null;
  skill_category: string | null;
  skill: string | null;
  role: string | null;
  billing_type: string | null;
  requirement_type: string | null;
  quantity: number;
  remarks: string | null;
  requirement_open_date: string | null;
  billing_start_date: string | null;
  created_at: string;
  updated_at: string;
}

export interface FulfillmentRecord {
  id: string;
  requirement_id: string;
  status: FulfillmentStatus;
  matched_resource_id: string | null;
  delivery_manager: string | null;
  delivery_partner: string | null;
  updated_by: string | null;
  updated_at: string;
}

export interface AuditLogEntry {
  id: string;
  actor: string | null;
  action: string;
  entity: string;
  entity_id: string | null;
  rjs: string | null;
  field: string | null;
  old_value: string | null;
  new_value: string | null;
  source: string | null;
  created_at: string;
}

export interface AnalyticsSummary {
  total: number;
  open: number;
  identified: number;
  hold: number;
  closed: number;
  closure_pct: number;
}

export interface HumanReview {
  id: string;
  reason: string;
  status: string;
  duplicate_verdict: string | null;
  context: Record<string, unknown>;
  requirement_id: string | null;
}
