# Resource Requirement & Fulfillment Intelligence Platform

Internal enterprise POC that centralizes resource requirements from the Requirement Tracker
Excel, Resource Tracker Excel, Outlook, and Teams; identifies each uniquely via **RJS**;
detects duplicates; matches resources; and exposes a **Fulfillment Tracker** through a React
dashboard.

## Architecture

```
Microsoft 365 → Microsoft Graph → FastAPI Integration Layer → Normalization → Idempotency
    → PostgreSQL → PostgreSQL-backed Job Queue → LangGraph/AI Processing
    → Deterministic Business Services → PostgreSQL → FastAPI APIs → React Dashboard
```

Modular monolith. No Redis, Celery, Kafka, or Kubernetes — see `docs/architecture.md`.

## Requirements

- **Python 3.12.10** (see note below on 3.14)
- PostgreSQL 18.1
- Node.js 24 LTS
- A Microsoft Entra ID app registration with Graph permissions (for Outlook/Teams/Excel)

> **Python version note:** if you have Python 3.14.3 installed, use a 3.12.10 virtualenv for
> this project instead. As of this writing, several core dependencies (SQLAlchemy, psycopg,
> pydantic-core) do not reliably publish prebuilt wheels for 3.14 yet, and building them from
> source is a time sink not worth taking on for a one-week POC. If you hit a specific
> incompatibility on 3.14 you've already verified, note it in an issue/PR rather than
> reworking the dependency pins blind.

## Setup

```bash
# 1. Backend
python -m venv venv
venv\Scripts\activate          # Windows
pip install -r requirements.txt
copy .env.example .env         # then fill in DB/Graph/LLM credentials

# 2. Database
createdb rrfip
alembic upgrade head

# 3. Run the API
uvicorn app.main:app --reload

# 4. Run the job worker (separate terminal)
python -m app.workers.runner

# 5. Frontend
cd frontend
npm install
npm run dev
```

API docs (Swagger UI) are available at `http://localhost:8000/docs` once the backend is running.

See `docs/setup.md` for full local setup, `docs/architecture.md` for design details,
`docs/security.md` for RBAC/auth, `docs/graph-integration.md` for Microsoft Graph
configuration, and `docs/api.md` for the endpoint reference.

## Current implementation status

**Complete and testable:**
- Core schema, RJS generation/idempotency, fulfillment status transitions, audit trail
- Full REST API (requirements, fulfillment, resources, matches, reviews, analytics, chat query)
- PostgreSQL-backed job queue + worker
- Source-to-canonical mapping layer for the actual Requirement/Resource Tracker columns
- Duplicate detection (hybrid deterministic + fuzzy) and resource matching (deterministic
  filter + weighted ranking)
- Microsoft Graph client (Outlook, Teams, Excel) and webhook ingestion endpoints
- React dashboard: Dashboard, Fulfillment Tracker, Requirement Detail, Resources, Review
  Queue, Analytics
- Unit test suite (`app/tests/`) covering RJS/idempotency, transitions, mapping, duplicate
  detection, and resource matching

**Wired but unverified against live services** (no Graph/LLM credentials or network access
during development — needs a real run against your tenant):
- Graph webhook subscriptions (Outlook/Teams change notifications)
- Excel live sync (`excel_sync_service.py`, triggered via `app/workers/excel_sync_cli.py` —
  schedule it with cron/Task Scheduler) against a real workbook
- LLM-based requirement extraction (`ai/requirement_intelligence.py`) and chat query
  (`ai/chat_query.py`) — both call the Anthropic API directly and need `LLM_API_KEY` set
- Entra ID login (`app/services/auth_service.py`, `POST /auth/login`, frontend's
  `src/pages/Login.tsx`) — needs a real Entra ID app registration; use `POST /auth/dev-token`
  (dev-environment only) or the frontend's "Continue with dev login" button to exercise
  everything else without one

**Not yet built:**
- Docker Compose has not been run end-to-end (no Docker in the dev sandbox)
- Admin role assignment UI — the first login gets `REQUIREMENT_TEAM` by default; granting
  `ADMIN`/`DELIVERY_MANAGER` currently means inserting a `user_roles` row directly
