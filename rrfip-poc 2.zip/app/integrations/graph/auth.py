"""MSAL confidential-client token acquisition for Microsoft Graph.

Single reusable function -- nothing else in the codebase calls MSAL directly (spec:
no repeated authentication logic). Tokens are cached in-memory by MSAL itself and never logged.
"""
import msal

from app.core.config import get_settings

settings = get_settings()

_msal_app: msal.ConfidentialClientApplication | None = None


def _get_msal_app() -> msal.ConfidentialClientApplication:
    global _msal_app
    if _msal_app is None:
        _msal_app = msal.ConfidentialClientApplication(
            client_id=settings.graph_client_id,
            client_credential=settings.graph_client_secret,
            authority=f"https://login.microsoftonline.com/{settings.graph_tenant_id}",
        )
    return _msal_app


def get_graph_access_token() -> str:
    """Acquire (or reuse from MSAL's cache) an app-only access token for Graph.

    Never log the returned token or the client secret.
    """
    app = _get_msal_app()
    scopes = [settings.graph_scopes]

    result = app.acquire_token_silent(scopes, account=None)
    if not result:
        result = app.acquire_token_for_client(scopes=scopes)

    if "access_token" not in result:
        error = result.get("error_description", "unknown error")
        raise RuntimeError(f"Failed to acquire Graph access token: {error}")

    return result["access_token"]
