"""One reusable Graph client (spec section 17): GraphClient.Outlook / .Teams / .Excel methods
all share the same authenticated HTTPX client and request/error handling. Do NOT write
per-service HTTP request logic elsewhere -- extend this class instead.
"""
import time

import httpx

from app.integrations.graph.auth import get_graph_access_token

GRAPH_BASE_URL = "https://graph.microsoft.com/v1.0"
RETRYABLE_STATUS_CODES = {429, 503, 504}
MAX_RETRIES = 3


class GraphAPIError(Exception):
    def __init__(self, status_code: int, message: str):
        self.status_code = status_code
        super().__init__(f"Graph API error {status_code}: {message}")


class GraphClient:
    """Thin, reusable wrapper around Microsoft Graph REST API v1.0 over HTTPX."""

    def __init__(self, timeout: float = 30.0):
        self._timeout = timeout

    def _headers(self) -> dict:
        token = get_graph_access_token()
        return {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}

    def _request(self, method: str, path: str, **kwargs) -> dict:
        url = path if path.startswith("http") else f"{GRAPH_BASE_URL}{path}"

        last_response: httpx.Response | None = None
        for attempt in range(MAX_RETRIES + 1):
            with httpx.Client(timeout=self._timeout) as client:
                response = client.request(method, url, headers=self._headers(), **kwargs)
            last_response = response

            if response.status_code not in RETRYABLE_STATUS_CODES:
                break
            if attempt == MAX_RETRIES:
                break
            retry_after = float(response.headers.get("Retry-After", 2 ** attempt))
            time.sleep(retry_after)

        if last_response.status_code >= 400:
            raise GraphAPIError(last_response.status_code, last_response.text[:500])
        if last_response.status_code == 204:
            return {}
        return last_response.json()

    # ---- Outlook -----------------------------------------------------------------

    def list_messages(self, user_or_mailbox_id: str, *, top: int = 25, filter_query: str | None = None) -> list[dict]:
        params = {"$top": top}
        if filter_query:
            params["$filter"] = filter_query
        data = self._request("GET", f"/users/{user_or_mailbox_id}/messages", params=params)
        return data.get("value", [])

    def get_message(self, user_or_mailbox_id: str, message_id: str) -> dict:
        return self._request("GET", f"/users/{user_or_mailbox_id}/messages/{message_id}")

    def subscribe_outlook_changes(self, user_or_mailbox_id: str, notification_url: str, expiration_iso: str) -> dict:
        """Create a Graph change-notification subscription for new Outlook messages."""
        from app.core.config import get_settings

        body = {
            "changeType": "created",
            "notificationUrl": notification_url,
            "resource": f"/users/{user_or_mailbox_id}/mailFolders('Inbox')/messages",
            "expirationDateTime": expiration_iso,
            "clientState": get_settings().graph_webhook_client_state,
        }
        return self._request("POST", "/subscriptions", json=body)

    # ---- Teams --------------------------------------------------------------------

    def list_channel_messages(self, team_id: str, channel_id: str, *, top: int = 25) -> list[dict]:
        data = self._request(
            "GET", f"/teams/{team_id}/channels/{channel_id}/messages", params={"$top": top}
        )
        return data.get("value", [])

    def subscribe_teams_channel_changes(
        self, team_id: str, channel_id: str, notification_url: str, expiration_iso: str
    ) -> dict:
        from app.core.config import get_settings

        body = {
            "changeType": "created,updated",
            "notificationUrl": notification_url,
            "resource": f"/teams/{team_id}/channels/{channel_id}/messages",
            "expirationDateTime": expiration_iso,
            "clientState": get_settings().graph_webhook_client_state,
        }
        return self._request("POST", "/subscriptions", json=body)

    # ---- Subscription lifecycle -----------------------------------------------------

    def renew_subscription(self, subscription_id: str, new_expiration_iso: str) -> dict:
        """Extend a Graph change-notification subscription's expiration (spec section 15:
        the system must track and act on subscription expiry, not just create-and-forget).
        """
        return self._request(
            "PATCH", f"/subscriptions/{subscription_id}", json={"expirationDateTime": new_expiration_iso}
        )

    def delete_subscription(self, subscription_id: str) -> None:
        self._request("DELETE", f"/subscriptions/{subscription_id}")

    # ---- Excel (workbook / table / range) ------------------------------------------

    def get_drive_item(self, site_id: str, drive_id: str, item_id: str) -> dict:
        """Fetch workbook item metadata (ETag, lastModifiedBy, lastModifiedDateTime)."""
        return self._request("GET", f"/sites/{site_id}/drives/{drive_id}/items/{item_id}")

    def get_worksheet_table_rows(
        self, drive_id: str, item_id: str, table_name: str
    ) -> list[dict]:
        """Fetch all rows of a named Excel table via Graph workbook API."""
        data = self._request(
            "GET",
            f"/drives/{drive_id}/items/{item_id}/workbook/tables/{table_name}/rows",
        )
        return data.get("value", [])

    def get_worksheet_used_range(self, drive_id: str, item_id: str, worksheet_name: str) -> dict:
        """Fallback when the workbook uses a plain range instead of a named table."""
        return self._request(
            "GET",
            f"/drives/{drive_id}/items/{item_id}/workbook/worksheets/{worksheet_name}/usedRange",
        )
