"""Source-to-canonical mapping layer.

Column names below match the ACTUAL Requirement Tracker / Resource Tracker workbooks
(S.No., Account/Portfolio, Country, Location, Skill Category, Skill, Role (Lead/Non Lead),
Billing Type (T&M/FP), CE Mandatory? (Yes/No), Request Id, Requirement Id, Requirement Type,
Requirement Open date, Billing start date, Status, Remarks, Billing WeekNum, Portfolio/Team
for requirements; Date, Source, Location, Emp ID, Name, Grade, Skill, Phone, Portfolio,
Detailed Status, RMG status, Employment Type for resources).

Do NOT rename or invent fields here -- preserve source column names/values (spec section 3).
Anything not explicitly mapped below is preserved verbatim in the `extra` JSONB bucket.
"""
from app.core.enums import SourceType
from app.services.requirement_service import NormalizedRequirementInput

# Requirement Tracker's authoritative identifier columns, in priority order.
REQUIREMENT_TRACKER_ID_COLUMNS = ("Requirement Id", "Request Id")

REQUIREMENT_TRACKER_MAPPED_COLUMNS = {
    "Account/Portfolio": "account_portfolio",
    "Country": "country",
    "Location": "location",
    "Skill Category": "skill_category",
    "Skill": "skill",
    "Role (Lead/Non Lead)": "role",
    "Billing Type (T&M/FP)": "billing_type",
    "Requirement Type": "requirement_type",
    "Portfolio/Team": "portfolio_team",
    "Remarks": "remarks",
}


def map_requirement_tracker_row(row: dict, *, row_key: str) -> NormalizedRequirementInput:
    """Convert one raw Requirement Tracker Excel row (as retrieved via Graph) into the
    canonical NormalizedRequirementInput used by requirement_service.ingest_requirement.
    """
    authoritative_id = None
    for column in REQUIREMENT_TRACKER_ID_COLUMNS:
        value = row.get(column)
        if value not in (None, ""):
            authoritative_id = str(value).strip()
            break

    mapped = {
        target_field: row[source_column]
        for source_column, target_field in REQUIREMENT_TRACKER_MAPPED_COLUMNS.items()
        if source_column in row
    }

    ce_mandatory_raw = row.get("CE Mandatory? (Yes/No)")
    ce_mandatory = None
    if isinstance(ce_mandatory_raw, str):
        ce_mandatory = ce_mandatory_raw.strip().lower() == "yes"

    unmapped = {
        k: v for k, v in row.items()
        if k not in REQUIREMENT_TRACKER_MAPPED_COLUMNS and k not in REQUIREMENT_TRACKER_ID_COLUMNS
    }

    return NormalizedRequirementInput(
        source_type=SourceType.REQUIREMENT_EXCEL,
        source_identifier=row_key,
        authoritative_id=authoritative_id,
        ce_mandatory=ce_mandatory,
        raw_payload=row,
        extra=unmapped,
        **mapped,
    )


RESOURCE_TRACKER_MAPPED_COLUMNS = {
    "Location": "location",
    "Emp ID": "employee_id",
    "Name": "name",
    "Grade": "grade",
    "Skill": "skill_raw",
    "Phone": "phone",
    "Portfolio": "portfolio",
    "Source": "source_channel",
    "Detailed Status": "detailed_status",
}

# Detailed Status values observed in the tracker that indicate the resource is NOT available.
# Availability is never inferred from skill presence -- only from this explicit status text
# and RMG status (spec section 13).
UNAVAILABLE_STATUS_MARKERS = ("not available", "allocated", "ce pending")


def map_resource_tracker_row(row: dict) -> dict:
    """Convert one raw Resource Tracker Excel row into canonical Resource fields.

    Returns a plain dict (not an ORM object) so the caller decides create-vs-update.
    Skills are split from the tracker's comma-separated free text into a list for
    normalization into ResourceSkill rows.
    """
    mapped = {
        target: row[source]
        for source, target in RESOURCE_TRACKER_MAPPED_COLUMNS.items()
        if source in row
    }

    skill_raw = mapped.pop("skill_raw", "") or ""
    skills = [s.strip() for s in skill_raw.replace("/", ",").split(",") if s.strip()]

    detailed_status = (mapped.get("detailed_status") or "").strip().lower()
    rmg_status = row.get("RMG Status") or row.get("RMG status")
    is_available = None
    if detailed_status:
        is_available = not any(marker in detailed_status for marker in UNAVAILABLE_STATUS_MARKERS)

    mapped["rmg_status"] = rmg_status
    mapped["category"] = row.get("Employment Type") or row.get("Category")
    mapped["is_available"] = is_available
    mapped["skills"] = skills

    unmapped = {
        k: v for k, v in row.items()
        if k not in RESOURCE_TRACKER_MAPPED_COLUMNS and k not in ("RMG Status", "RMG status", "Employment Type", "Category")
    }
    mapped["extra"] = unmapped
    return mapped
