"""FastAPI application entrypoint. Run with: uvicorn app.main:app --reload"""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api.routes import (
    auth, chat, fulfillment, graph_subscriptions, graph_webhooks, health, requirements,
    resources_reviews_analytics, sync,
)
from app.core.config import get_settings

settings = get_settings()

app = FastAPI(title=settings.app_name)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_allow_origins.split(","),
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(health.router, prefix=settings.api_prefix)
app.include_router(auth.router, prefix=settings.api_prefix)
app.include_router(requirements.router, prefix=settings.api_prefix)
app.include_router(fulfillment.router, prefix=settings.api_prefix)
app.include_router(resources_reviews_analytics.router, prefix=settings.api_prefix)
app.include_router(graph_webhooks.router, prefix=settings.api_prefix)
app.include_router(graph_subscriptions.router, prefix=settings.api_prefix)
app.include_router(sync.router, prefix=settings.api_prefix)
app.include_router(chat.router, prefix=settings.api_prefix)
