"""Periodic Excel sync trigger. Run via cron / Windows Task Scheduler, e.g. every 15 minutes:

    python -m app.workers.excel_sync_cli

This enqueues REQUIREMENT_EXCEL_SYNC and RESOURCE_EXCEL_SYNC jobs onto the durable
PostgreSQL job queue rather than calling the sync service directly -- that way a sync that
fails partway (a Graph 503, a transient DB issue) gets the same retry/backoff treatment as
every other job, and shows up in the `jobs` table for visibility instead of silently failing
in a cron log. The actual sync work happens in app/workers/handlers.py when the worker
(app/workers/runner.py) picks the job up; this CLI's only job is to enqueue it.
"""
import sys

from app.core.config import get_settings
from app.core.enums import JobType
from app.db.session import SessionLocal
from app.models.job import Job

settings = get_settings()


def enqueue_requirement_sync() -> str:
    if not settings.requirement_tracker_item_id:
        return "skipped (REQUIREMENT_TRACKER_ITEM_ID not configured)"
    db = SessionLocal()
    try:
        job = Job(type=JobType.REQUIREMENT_EXCEL_SYNC, payload={}, correlation_id="scheduled-requirement-sync")
        db.add(job)
        db.commit()
        return f"enqueued job {job.id}"
    finally:
        db.close()


def enqueue_resource_sync() -> str:
    if not settings.resource_tracker_item_id:
        return "skipped (RESOURCE_TRACKER_ITEM_ID not configured)"
    db = SessionLocal()
    try:
        job = Job(type=JobType.RESOURCE_EXCEL_SYNC, payload={}, correlation_id="scheduled-resource-sync")
        db.add(job)
        db.commit()
        return f"enqueued job {job.id}"
    finally:
        db.close()


if __name__ == "__main__":
    print(f"Requirement Tracker sync: {enqueue_requirement_sync()}")
    print(f"Resource Tracker sync: {enqueue_resource_sync()}")
    print("Jobs enqueued. Run 'python -m app.workers.runner' (or ensure it's already running) to process them.")
    sys.exit(0)
