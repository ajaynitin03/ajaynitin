"""Periodic subscription-renewal sweep. Run via cron / Task Scheduler, e.g. every hour:

    python -m app.workers.subscription_renewal_cli

Finds GraphSubscription records expiring within the lookahead window and enqueues a
RENEW_GRAPH_SUBSCRIPTION job for each. This is the "simple durable renewal workflow" spec
section 15 asks for -- a periodic sweep plus the existing PostgreSQL job queue, not a
separate scheduler.
"""
import sys

from app.core.enums import JobType
from app.db.session import SessionLocal
from app.models.job import Job
from app.services.graph_subscription_service import find_subscriptions_needing_renewal


def sweep() -> int:
    db = SessionLocal()
    try:
        due = find_subscriptions_needing_renewal(db)
        for subscription in due:
            db.add(
                Job(
                    type=JobType.RENEW_GRAPH_SUBSCRIPTION,
                    payload={"subscription_id": subscription.subscription_id},
                    correlation_id=f"renew-{subscription.subscription_id}",
                )
            )
        db.commit()
        return len(due)
    finally:
        db.close()


if __name__ == "__main__":
    count = sweep()
    print(f"Enqueued {count} subscription renewal job(s).")
    sys.exit(0)
