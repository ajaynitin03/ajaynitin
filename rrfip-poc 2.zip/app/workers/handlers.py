"""Job type -> handler function registry. Add a new job type by adding one entry here;
nothing else in the worker needs to change (spec: developer can change things without
rewriting unrelated parts).
"""
from collections.abc import Callable

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.enums import JobType, SourceType
from app.integrations.mapping import map_requirement_tracker_row
from app.models.ingestion import SourceEvent
from app.services.requirement_service import NormalizedRequirementInput, ingest_requirement


def handle_normalize_source_event(db: Session, payload: dict) -> None:
    """Normalize a raw source event into a canonical requirement or resource and ingest it.

    Excel rows are routed by `payload["workbook"]` (set by excel_sync_service/excel_sync_cli):
    "Requirement Tracker" -> requirement mapping + ingestion, "Resource Tracker" -> resource
    mapping + ingestion. Outlook/Teams payloads are handed off to AI extraction since they
    need structured-data extraction from free text before they resemble either shape.
    """
    if "row" in payload:
        workbook = payload.get("workbook", "")
        if workbook == "Resource Tracker":
            from app.integrations.mapping import map_resource_tracker_row
            from app.services.resource_ingestion_service import ingest_resource

            mapped = map_resource_tracker_row(payload["row"])
            ingest_resource(db, mapped, actor="excel_sync")
            return

        # Default / "Requirement Tracker": deterministic mapping only, no AI involved.
        normalized = map_requirement_tracker_row(payload["row"], row_key=payload["row_key"])
        ingest_requirement(db, normalized, actor="excel_sync")
        return

    source_type = SourceType(payload["source_type"])
    source_identifier = payload["source_identifier"]
    event = db.execute(
        select(SourceEvent).where(
            SourceEvent.source_type == source_type, SourceEvent.source_identifier == source_identifier
        )
    ).scalar_one_or_none()
    if event is None:
        raise ValueError(f"SourceEvent not found for {source_type}:{source_identifier}")

    if source_type in (SourceType.OUTLOOK, SourceType.TEAMS):
        # Outlook/Teams free text requires AI extraction before we have structured requirement
        # fields -- hand off to the AI extraction job rather than guessing here.
        from app.models.job import Job

        db.add(
            Job(
                type=JobType.RUN_AI_EXTRACTION,
                payload={"source_event_id": str(event.id), "source_type": source_type.value,
                          "source_identifier": source_identifier, "raw_payload": event.raw_payload},
                correlation_id=source_identifier,
            )
        )
        event.processed = True
        db.commit()
        return

    raise NotImplementedError(f"No normalization path for source type {source_type}")


def handle_run_ai_extraction(db: Session, payload: dict) -> None:
    """Run the full AI requirement-processing pipeline (extraction -> validation ->
    duplicate detection -> RJS resolution -> resource matching -> fulfillment recommendation)
    via the real LangGraph StateGraph in app/ai/graph.py. This handler's only job is to pull
    the raw text out of the Graph payload and hand it to the graph -- all decision logic lives
    in the graph's nodes and the deterministic services they call.
    """
    from app.ai.graph import run_requirement_processing_pipeline

    raw_payload = payload.get("raw_payload", {})
    raw_text = raw_payload.get("body", {}).get("content", "") if "body" in raw_payload else str(raw_payload)

    run_requirement_processing_pipeline(
        db,
        source_type=payload["source_type"],
        source_identifier=payload["source_identifier"],
        raw_text=raw_text,
        raw_payload=raw_payload,
    )


def handle_run_duplicate_detection(db: Session, payload: dict) -> None:
    from app.core.enums import DuplicateVerdict
    from app.models.ai import HumanReview
    from app.models.requirement import Requirement
    from app.services.duplicate_detection_service import detect_duplicate

    requirement = db.get(Requirement, payload["requirement_id"])
    if requirement is None:
        raise ValueError(f"Requirement {payload['requirement_id']} not found")

    verdict, match, score = detect_duplicate(db, requirement)
    if verdict in (DuplicateVerdict.NEEDS_REVIEW, DuplicateVerdict.PROBABLE_DUPLICATE):
        db.add(
            HumanReview(
                requirement_id=requirement.id,
                reason="ambiguous_duplicate",
                duplicate_verdict=verdict,
                context={"candidate_rjs": match.rjs if match else None, "score": score},
            )
        )
    db.commit()


def handle_run_resource_matching(db: Session, payload: dict) -> None:
    from app.models.ai import ResourceMatch
    from app.models.requirement import Requirement
    from app.services.resource_matching_service import rank_resource_matches

    requirement = db.get(Requirement, payload["requirement_id"])
    if requirement is None:
        raise ValueError(f"Requirement {payload['requirement_id']} not found")

    ranked = rank_resource_matches(db, requirement)
    for rank, item in enumerate(ranked, start=1):
        db.add(
            ResourceMatch(
                requirement_id=requirement.id,
                resource_id=item["resource"].id,
                score=item["score"],
                rank=rank,
                reasons=item["reasons"],
            )
        )
    db.commit()


def handle_requirement_excel_sync(db: Session, payload: dict) -> None:
    """Sync the Requirement Tracker workbook: Graph -> ExcelSyncService -> snapshot diff ->
    changed rows -> NORMALIZE_SOURCE_EVENT jobs tagged workbook="Requirement Tracker".
    Reuses the single generic excel_sync_service -- no separate sync implementation.
    """
    from app.core.config import get_settings
    from app.integrations.graph.client import GraphClient
    from app.services.excel_sync_service import sync_workbook

    settings = get_settings()
    if not settings.requirement_tracker_item_id:
        raise ValueError(
            "REQUIREMENT_TRACKER_ITEM_ID is not configured -- cannot sync without a stable "
            "Graph item_id (see docs/graph-integration.md for how to obtain it)"
        )

    graph = GraphClient()
    sync_workbook(
        db, graph,
        workbook_name="Requirement Tracker",
        site_id=settings.requirement_tracker_site_id,
        drive_id=settings.requirement_tracker_drive_id,
        item_id=settings.requirement_tracker_item_id,
        table_name=settings.requirement_tracker_table_name,
        worksheet_name=None,
        id_columns=("Requirement Id", "Request Id"),
        normalize_job_type=JobType.NORMALIZE_SOURCE_EVENT,
    )


def handle_resource_excel_sync(db: Session, payload: dict) -> None:
    """Sync the Resource Tracker workbook. Same generic excel_sync_service as requirements;
    only the workbook identifiers, table name, and id_columns differ (spec section 10: do
    not create two independent implementations of Excel synchronization).
    """
    from app.core.config import get_settings
    from app.integrations.graph.client import GraphClient
    from app.services.excel_sync_service import sync_workbook

    settings = get_settings()
    if not settings.resource_tracker_item_id:
        raise ValueError(
            "RESOURCE_TRACKER_ITEM_ID is not configured -- cannot sync without a stable "
            "Graph item_id (see docs/graph-integration.md for how to obtain it)"
        )

    graph = GraphClient()
    sync_workbook(
        db, graph,
        workbook_name="Resource Tracker",
        site_id=settings.resource_tracker_site_id,
        drive_id=settings.resource_tracker_drive_id,
        item_id=settings.resource_tracker_item_id,
        table_name=settings.resource_tracker_table_name,
        worksheet_name=None,
        id_columns=("Emp ID",),
        normalize_job_type=JobType.NORMALIZE_SOURCE_EVENT,
    )


def handle_renew_graph_subscription(db: Session, payload: dict) -> None:
    """Renew a Graph change-notification subscription before it expires (Outlook mail
    subscriptions max out around 3 days; Teams channel subscriptions similarly limited),
    and update our own tracked GraphSubscription record so the next sweep sees the new
    expiration instead of immediately re-queuing a renewal.
    """
    from datetime import datetime, timedelta, UTC

    from app.integrations.graph.client import GraphClient
    from app.models.graph_subscription import GraphSubscription
    from app.services.graph_subscription_service import mark_renewed

    subscription_id = payload["subscription_id"]
    record = db.execute(
        select(GraphSubscription).where(GraphSubscription.subscription_id == subscription_id)
    ).scalar_one_or_none()
    if record is None:
        raise ValueError(f"No tracked GraphSubscription for id {subscription_id}")

    graph = GraphClient()
    new_expiration_dt = datetime.now(UTC) + timedelta(hours=70)
    new_expiration_iso = new_expiration_dt.isoformat().replace("+00:00", "Z")
    graph.renew_subscription(subscription_id, new_expiration_iso)
    mark_renewed(db, record, new_expiration_dt)


JOB_HANDLERS: dict[JobType, Callable[[Session, dict], None]] = {
    JobType.NORMALIZE_SOURCE_EVENT: handle_normalize_source_event,
    JobType.RUN_AI_EXTRACTION: handle_run_ai_extraction,
    JobType.RUN_DUPLICATE_DETECTION: handle_run_duplicate_detection,
    JobType.RUN_RESOURCE_MATCHING: handle_run_resource_matching,
    JobType.REQUIREMENT_EXCEL_SYNC: handle_requirement_excel_sync,
    JobType.RESOURCE_EXCEL_SYNC: handle_resource_excel_sync,
    JobType.RENEW_GRAPH_SUBSCRIPTION: handle_renew_graph_subscription,
}
