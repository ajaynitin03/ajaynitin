"""Minimal durable job worker. Run with: python -m app.workers.runner

No Celery/Redis (spec section 34). Uses SELECT ... FOR UPDATE SKIP LOCKED so multiple worker
processes can run safely without double-claiming a job. This is the same dialect-gating
pattern as app/services/rjs_service.py: PostgreSQL is the only dialect production ever uses,
and `_claim_next_job_postgresql` is the only branch it ever takes. SQLite has no equivalent
row-locking construct (`FOR UPDATE SKIP LOCKED` is a syntax error under SQLite), so a
SQLite-only fallback exists purely so this function's claiming/status-transition logic can be
exercised by the test suite (app/tests/test_worker.py) instead of being entirely untested.
The SQLite fallback is NOT safe under true multi-process concurrency (SQLite's own
locking model is coarser-grained than row locks) -- it exists for correctness testing of the
claim/process/retry state machine, not as a concurrency-safety substitute for PostgreSQL.
"""
import time
from datetime import datetime, UTC

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.core.enums import JobStatus
from app.db.session import SessionLocal
from app.models.job import Job
from app.workers.handlers import JOB_HANDLERS

settings = get_settings()


def _claim_next_job_postgresql(db: Session) -> Job | None:
    """The only code path production ever takes. FOR UPDATE SKIP LOCKED means concurrent
    worker processes each get a DIFFERENT pending job (or None if none are free) with no
    possibility of two workers claiming the same row -- the database enforces this, not
    application-level coordination.
    """
    stmt = (
        select(Job)
        .where(Job.status.in_([JobStatus.PENDING, JobStatus.RETRY]))
        .order_by(Job.priority, Job.created_at)
        .limit(1)
        .with_for_update(skip_locked=True)
    )
    return db.execute(stmt).scalar_one_or_none()


def _claim_next_job_sqlite_fallback(db: Session) -> Job | None:
    """TEST-ONLY. Never executed against PostgreSQL -- see module docstring. Plain SELECT,
    no row locking -- correct for single-threaded test execution, not a concurrency
    guarantee.
    """
    stmt = (
        select(Job)
        .where(Job.status.in_([JobStatus.PENDING, JobStatus.RETRY]))
        .order_by(Job.priority, Job.created_at)
        .limit(1)
    )
    return db.execute(stmt).scalar_one_or_none()


def claim_next_job(db: Session) -> Job | None:
    dialect_name = db.bind.dialect.name if db.bind is not None else "postgresql"
    job = _claim_next_job_sqlite_fallback(db) if dialect_name == "sqlite" else _claim_next_job_postgresql(db)
    if job is None:
        return None
    job.status = JobStatus.RUNNING
    job.started_at = datetime.now(UTC)
    job.attempts += 1
    db.commit()
    return job


def process_job(db, job: Job) -> None:
    handler = JOB_HANDLERS.get(job.type)
    if handler is None:
        job.status = JobStatus.FAILED
        job.last_error = f"No handler registered for job type '{job.type}'"
        db.commit()
        return
    try:
        handler(db, job.payload)
        job.status = JobStatus.COMPLETED
        job.completed_at = datetime.now(UTC)
    except Exception as exc:  # noqa: BLE001 - worker must never crash on a bad job
        db.rollback()
        job.last_error = str(exc)[:2000]
        job.status = JobStatus.RETRY if job.attempts < job.max_attempts else JobStatus.FAILED
    db.commit()


def run_forever() -> None:
    print("Job worker started. Polling for PENDING/RETRY jobs...")
    while True:
        db = SessionLocal()
        try:
            job = claim_next_job(db)
            if job is not None:
                process_job(db, job)
            else:
                time.sleep(settings.job_poll_interval_seconds)
        finally:
            db.close()


if __name__ == "__main__":
    run_forever()
