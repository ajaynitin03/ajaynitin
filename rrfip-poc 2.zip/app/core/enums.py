"""Domain enums. These are the ONLY business statuses/types allowed anywhere in the system.
Changing business rules (e.g. adding a fulfillment status) starts here.
"""
import enum


class FulfillmentStatus(str, enum.Enum):
    """The ONLY four business fulfillment statuses (per spec section 1 & 14)."""
    OPEN = "OPEN"
    IDENTIFIED = "IDENTIFIED"
    HOLD = "HOLD"
    CLOSED = "CLOSED"


# Deterministic allowed transitions. Enforced in fulfillment_service.
ALLOWED_TRANSITIONS: dict[FulfillmentStatus, set[FulfillmentStatus]] = {
    FulfillmentStatus.OPEN: {FulfillmentStatus.IDENTIFIED, FulfillmentStatus.HOLD, FulfillmentStatus.CLOSED},
    FulfillmentStatus.IDENTIFIED: {FulfillmentStatus.OPEN, FulfillmentStatus.HOLD, FulfillmentStatus.CLOSED},
    FulfillmentStatus.HOLD: {FulfillmentStatus.OPEN, FulfillmentStatus.IDENTIFIED, FulfillmentStatus.CLOSED},
    # CLOSED is terminal for normal users; reopening requires elevated role (see fulfillment_service).
    FulfillmentStatus.CLOSED: set(),
}


class SourceType(str, enum.Enum):
    REQUIREMENT_EXCEL = "REQUIREMENT_EXCEL"
    RESOURCE_EXCEL = "RESOURCE_EXCEL"
    OUTLOOK = "OUTLOOK"
    TEAMS = "TEAMS"
    MANUAL = "MANUAL"


class RequirementType(str, enum.Enum):
    NEW = "New"
    REPLACEMENT = "Replacement"


class JobStatus(str, enum.Enum):
    PENDING = "PENDING"
    RUNNING = "RUNNING"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"
    RETRY = "RETRY"


class JobType(str, enum.Enum):
    NORMALIZE_SOURCE_EVENT = "NORMALIZE_SOURCE_EVENT"
    RUN_AI_EXTRACTION = "RUN_AI_EXTRACTION"
    RUN_DUPLICATE_DETECTION = "RUN_DUPLICATE_DETECTION"
    RUN_RESOURCE_MATCHING = "RUN_RESOURCE_MATCHING"
    REQUIREMENT_EXCEL_SYNC = "REQUIREMENT_EXCEL_SYNC"
    RESOURCE_EXCEL_SYNC = "RESOURCE_EXCEL_SYNC"
    RENEW_GRAPH_SUBSCRIPTION = "RENEW_GRAPH_SUBSCRIPTION"


class DuplicateVerdict(str, enum.Enum):
    NOT_DUPLICATE = "NOT_DUPLICATE"
    DUPLICATE = "DUPLICATE"
    PROBABLE_DUPLICATE = "PROBABLE_DUPLICATE"
    NEEDS_REVIEW = "NEEDS_REVIEW"


class ReviewStatus(str, enum.Enum):
    PENDING = "PENDING"
    APPROVED = "APPROVED"
    REJECTED = "REJECTED"


class UserRole(str, enum.Enum):
    REQUIREMENT_TEAM = "REQUIREMENT_TEAM"
    DELIVERY_MANAGER = "DELIVERY_MANAGER"
    DELIVERY_PARTNER = "DELIVERY_PARTNER"
    ADMIN = "ADMIN"
    AUDITOR = "AUDITOR"


# Roles allowed to reopen a CLOSED fulfillment record.
ROLES_ALLOWED_TO_REOPEN_CLOSED = {UserRole.ADMIN, UserRole.DELIVERY_MANAGER}
