"""Centralized application configuration. All environment-driven settings live here."""
from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    # App
    app_name: str = "Resource Requirement & Fulfillment Intelligence Platform"
    environment: str = "development"
    api_prefix: str = "/api/v1"

    # Database
    database_url: str = "postgresql+psycopg://postgres:postgres@localhost:5432/rrfip"
    db_echo: bool = False

    # RJS generation
    rjs_prefix: str = "RJS"

    # Microsoft Graph / MSAL
    graph_tenant_id: str = ""
    graph_client_id: str = ""
    graph_client_secret: str = ""
    graph_scopes: str = "https://graph.microsoft.com/.default"

    # Excel source identifiers (never hardcode per-workbook, load from config/DB)
    requirement_tracker_site_id: str = ""
    requirement_tracker_drive_id: str = ""
    requirement_tracker_item_id: str = ""
    resource_tracker_site_id: str = ""
    resource_tracker_drive_id: str = ""
    resource_tracker_item_id: str = ""
    # Excel table/worksheet names (not IDs, but still configurable -- never hardcoded)
    requirement_tracker_table_name: str = "RequirementTrackerTable"
    resource_tracker_table_name: str = "ResourceTrackerTable"

    # Security-relevant, not just an identifier: Graph echoes clientState back on every
    # notification so we can verify it (spec section 13/14: verify clientState when
    # configured). Centralized here as the single source of truth -- subscription creation
    # (app/integrations/graph/client.py) and webhook validation (app/api/routes/graph_webhooks.py)
    # both read this instead of each hardcoding their own literal.
    graph_webhook_client_state: str = "rrfip-graph-webhook-default-change-me"

    # AI / LLM
    llm_provider: str = "anthropic"
    llm_endpoint: str = "https://api.anthropic.com/v1/messages"
    llm_model: str = "claude-sonnet-4-6"
    llm_api_key: str = ""

    # Job worker
    job_poll_interval_seconds: float = 2.0
    job_max_attempts: int = 5

    # Security
    jwt_secret_key: str = "change-me-in-production"
    jwt_algorithm: str = "HS256"
    access_token_expire_minutes: int = 60
    cors_allow_origins: str = "http://localhost:3000"


@lru_cache
def get_settings() -> Settings:
    return Settings()
