"""Raw ingestion tracking: source_events (Outlook/Teams/Excel arrivals) and Excel sync state.

source_events is the FIRST landing place for anything from Graph, before normalization.
Idempotency is enforced here too (unique source_type + source_identifier), same pattern
as RequirementSource -- this is the generic version used before we even know if the event
maps to a new or existing requirement.
"""
from datetime import datetime

import uuid

from sqlalchemy import String, UniqueConstraint, DateTime, ForeignKey
from sqlalchemy.dialects.postgresql import UUID as PG_UUID, JSONB
from sqlalchemy.orm import Mapped, mapped_column

from app.db.session import Base
from app.db.mixins import UUIDPrimaryKeyMixin, TimestampMixin
from app.core.enums import SourceType


class SourceEvent(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    __tablename__ = "source_events"
    __table_args__ = (UniqueConstraint("source_type", "source_identifier", name="uq_source_event_identity"),)

    source_type: Mapped[SourceType] = mapped_column(String(30), nullable=False, index=True)
    source_identifier: Mapped[str] = mapped_column(String(500), nullable=False)
    raw_payload: Mapped[dict] = mapped_column(JSONB, default=dict, nullable=False)
    processed: Mapped[bool] = mapped_column(default=False, nullable=False)
    processing_error: Mapped[str | None] = mapped_column(String(2000), nullable=True)


class ExcelSyncState(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    """One row per tracked workbook. Tracks Graph identifiers + last known version/ETag,
    so 'who/when last modified' (spec section 5) can be answered without re-fetching.
    """
    __tablename__ = "excel_sync_state"
    __table_args__ = (UniqueConstraint("site_id", "drive_id", "item_id", name="uq_excel_workbook_identity"),)

    workbook_name: Mapped[str] = mapped_column(String(255), nullable=False)
    site_id: Mapped[str] = mapped_column(String(255), nullable=False)
    drive_id: Mapped[str] = mapped_column(String(255), nullable=False)
    item_id: Mapped[str] = mapped_column(String(255), nullable=False)
    worksheet_or_table: Mapped[str | None] = mapped_column(String(255), nullable=True)

    last_etag: Mapped[str | None] = mapped_column(String(255), nullable=True)
    last_version: Mapped[str | None] = mapped_column(String(100), nullable=True)
    last_modified_by: Mapped[str | None] = mapped_column(String(255), nullable=True)
    last_modified_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    last_synced_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    sync_status: Mapped[str | None] = mapped_column(String(50), nullable=True)


class ExcelSnapshot(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    """Point-in-time snapshot of a workbook's normalized rows, used to diff against the next
    fetch and detect which records/fields changed (spec section 21).
    """
    __tablename__ = "excel_snapshots"

    excel_sync_state_id: Mapped[uuid.UUID] = mapped_column(
        PG_UUID(as_uuid=True), ForeignKey("excel_sync_state.id"), nullable=False, index=True
    )
    row_key: Mapped[str] = mapped_column(String(255), nullable=False)  # deterministic key per source row
    row_data: Mapped[dict] = mapped_column(JSONB, nullable=False)
