"""Fulfillment: the operational output of the whole platform. One record per requirement,
current-state (fulfillment_records) separate from history (fulfillment_events).
"""
import uuid

from sqlalchemy import String, ForeignKey
from sqlalchemy.dialects.postgresql import UUID as PG_UUID, JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.session import Base
from app.db.mixins import UUIDPrimaryKeyMixin, TimestampMixin
from app.core.enums import FulfillmentStatus


class FulfillmentRecord(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    """Current fulfillment state for a requirement. One row per requirement (1:1)."""
    __tablename__ = "fulfillment_records"

    requirement_id: Mapped[uuid.UUID] = mapped_column(
        PG_UUID(as_uuid=True), ForeignKey("requirements.id"), unique=True, nullable=False, index=True
    )
    status: Mapped[FulfillmentStatus] = mapped_column(String(20), nullable=False, default=FulfillmentStatus.OPEN)
    matched_resource_id: Mapped[uuid.UUID | None] = mapped_column(
        PG_UUID(as_uuid=True), ForeignKey("resources.id"), nullable=True
    )
    delivery_manager: Mapped[str | None] = mapped_column(String(255), nullable=True)
    delivery_partner: Mapped[str | None] = mapped_column(String(255), nullable=True)
    updated_by: Mapped[str | None] = mapped_column(String(255), nullable=True)

    events: Mapped[list["FulfillmentEvent"]] = relationship(
        back_populates="fulfillment_record", cascade="all, delete-orphan", order_by="FulfillmentEvent.created_at"
    )


class FulfillmentEvent(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    """Immutable history of every fulfillment status transition."""
    __tablename__ = "fulfillment_events"

    fulfillment_record_id: Mapped[uuid.UUID] = mapped_column(
        PG_UUID(as_uuid=True), ForeignKey("fulfillment_records.id"), nullable=False, index=True
    )
    from_status: Mapped[FulfillmentStatus | None] = mapped_column(String(20), nullable=True)
    to_status: Mapped[FulfillmentStatus] = mapped_column(String(20), nullable=False)
    actor: Mapped[str | None] = mapped_column(String(255), nullable=True)
    reason: Mapped[str | None] = mapped_column(String(1000), nullable=True)
    correlation_id: Mapped[str | None] = mapped_column(String(100), nullable=True, index=True)
    meta: Mapped[dict] = mapped_column(JSONB, default=dict, nullable=False)

    fulfillment_record: Mapped["FulfillmentRecord"] = relationship(back_populates="events")
