"""Tracks Microsoft Graph change-notification subscriptions so a periodic sweep can find
ones nearing expiration and enqueue a renewal job (spec section 15). Without this table,
"subscription renewal" would have nothing to check against -- creating a subscription and
never persisting its ID/expiration makes renewal impossible, not just unscheduled.
"""
from datetime import datetime

from sqlalchemy import DateTime, String
from sqlalchemy.orm import Mapped, mapped_column

from app.db.mixins import TimestampMixin, UUIDPrimaryKeyMixin
from app.db.session import Base


class GraphSubscription(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    __tablename__ = "graph_subscriptions"

    subscription_id: Mapped[str] = mapped_column(String(255), unique=True, nullable=False, index=True)
    resource_type: Mapped[str] = mapped_column(String(30), nullable=False)  # "OUTLOOK" or "TEAMS"
    resource: Mapped[str] = mapped_column(String(500), nullable=False)  # the Graph resource path
    notification_url: Mapped[str] = mapped_column(String(500), nullable=False)
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, index=True)
    last_renewed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    is_active: Mapped[bool] = mapped_column(default=True, nullable=False)
