"""AI execution metadata, human review queue, and resource match results."""
import uuid

from sqlalchemy import String, ForeignKey, Numeric
from sqlalchemy.dialects.postgresql import UUID as PG_UUID, JSONB
from sqlalchemy.orm import Mapped, mapped_column

from app.db.session import Base
from app.db.mixins import UUIDPrimaryKeyMixin, TimestampMixin
from app.core.enums import DuplicateVerdict, ReviewStatus


class AIRun(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    """Every LLM invocation is recorded for auditability -- prompt/model/output/confidence."""
    __tablename__ = "ai_runs"

    agent_name: Mapped[str] = mapped_column(String(100), nullable=False, index=True)
    requirement_id: Mapped[uuid.UUID | None] = mapped_column(
        PG_UUID(as_uuid=True), ForeignKey("requirements.id"), nullable=True, index=True
    )
    model: Mapped[str] = mapped_column(String(100), nullable=False)
    input_summary: Mapped[dict] = mapped_column(JSONB, default=dict, nullable=False)
    output: Mapped[dict] = mapped_column(JSONB, default=dict, nullable=False)
    confidence: Mapped[float | None] = mapped_column(Numeric(4, 3), nullable=True)
    success: Mapped[bool] = mapped_column(default=True, nullable=False)
    error: Mapped[str | None] = mapped_column(String(2000), nullable=True)


class ResourceMatch(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    """Ranked candidate match between a requirement and a resource. Never auto-allocates."""
    __tablename__ = "resource_matches"

    requirement_id: Mapped[uuid.UUID] = mapped_column(
        PG_UUID(as_uuid=True), ForeignKey("requirements.id"), nullable=False, index=True
    )
    resource_id: Mapped[uuid.UUID] = mapped_column(
        PG_UUID(as_uuid=True), ForeignKey("resources.id"), nullable=False, index=True
    )
    score: Mapped[float] = mapped_column(Numeric(6, 3), nullable=False)
    rank: Mapped[int] = mapped_column(nullable=False)
    reasons: Mapped[dict] = mapped_column(JSONB, default=dict, nullable=False)


class HumanReview(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    """Review queue item for anything needing a human decision (spec section 27)."""
    __tablename__ = "human_reviews"

    requirement_id: Mapped[uuid.UUID | None] = mapped_column(
        PG_UUID(as_uuid=True), ForeignKey("requirements.id"), nullable=True, index=True
    )
    reason: Mapped[str] = mapped_column(String(255), nullable=False)
    status: Mapped[ReviewStatus] = mapped_column(String(20), default=ReviewStatus.PENDING, nullable=False)
    duplicate_verdict: Mapped[DuplicateVerdict | None] = mapped_column(String(30), nullable=True)
    context: Mapped[dict] = mapped_column(JSONB, default=dict, nullable=False)
    decided_by: Mapped[str | None] = mapped_column(String(255), nullable=True)
    decision_notes: Mapped[str | None] = mapped_column(String(1000), nullable=True)
