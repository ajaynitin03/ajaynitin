"""Import every model module here so Alembic's autogenerate and Base.metadata.create_all
see the full schema. This is the single place that must be updated when a new model file
is added -- nowhere else needs to know about it.
"""
from app.models.user import User, UserRoleAssignment  # noqa: F401
from app.models.requirement import Requirement, RequirementSource, RequirementVersion  # noqa: F401
from app.models.resource import Resource, ResourceSkill  # noqa: F401
from app.models.fulfillment import FulfillmentRecord, FulfillmentEvent  # noqa: F401
from app.models.ingestion import SourceEvent, ExcelSyncState, ExcelSnapshot  # noqa: F401
from app.models.audit import AuditLog  # noqa: F401
from app.models.ai import AIRun, ResourceMatch, HumanReview  # noqa: F401
from app.models.job import Job  # noqa: F401
from app.models.graph_subscription import GraphSubscription  # noqa: F401

__all__ = [
    "User", "UserRoleAssignment",
    "Requirement", "RequirementSource", "RequirementVersion",
    "Resource", "ResourceSkill",
    "FulfillmentRecord", "FulfillmentEvent",
    "SourceEvent", "ExcelSyncState", "ExcelSnapshot",
    "AuditLog",
    "AIRun", "ResourceMatch", "HumanReview",
    "Job",
    "GraphSubscription",
]
