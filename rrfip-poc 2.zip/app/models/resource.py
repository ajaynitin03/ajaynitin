"""Canonical Resource model, mapped from Resource Tracker schema (Date, Source, Location,
Emp ID, Name, Grade, Skill, Phone, Portfolio, Detailed Status, RMG status, Employment Type).

Availability is an explicit column, never inferred from skill presence alone (spec section 13).
"""
import uuid
from datetime import date

from sqlalchemy import String, Date, ForeignKey, UniqueConstraint
from sqlalchemy.dialects.postgresql import UUID as PG_UUID, JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.session import Base
from app.db.mixins import UUIDPrimaryKeyMixin, TimestampMixin


class Resource(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    __tablename__ = "resources"

    # Source system's own employee identifier (Emp ID). Not the internal UUID PK.
    employee_id: Mapped[str] = mapped_column(String(64), unique=True, nullable=False, index=True)

    name: Mapped[str | None] = mapped_column(String(255), nullable=True)
    grade: Mapped[str | None] = mapped_column(String(20), nullable=True)
    location: Mapped[str | None] = mapped_column(String(255), nullable=True, index=True)
    source_channel: Mapped[str | None] = mapped_column(String(50), nullable=True)  # ADM / CBO / Cloud etc.
    phone: Mapped[str | None] = mapped_column(String(50), nullable=True)
    portfolio: Mapped[str | None] = mapped_column(String(255), nullable=True, index=True)
    category: Mapped[str | None] = mapped_column(String(50), nullable=True)  # Employee/Probationer/Trainee/BA

    # Explicit availability state -- never derived from skills alone.
    detailed_status: Mapped[str | None] = mapped_column(String(255), nullable=True)  # e.g. "Allocated", "CE pending"
    rmg_status: Mapped[str | None] = mapped_column(String(50), nullable=True)  # RMG Approved/Pending/Reject
    is_available: Mapped[bool | None] = mapped_column(nullable=True)

    entry_date: Mapped[date | None] = mapped_column(Date, nullable=True)
    remarks: Mapped[str | None] = mapped_column(String(2000), nullable=True)

    extra: Mapped[dict] = mapped_column(JSONB, default=dict, nullable=False)

    skills: Mapped[list["ResourceSkill"]] = relationship(back_populates="resource", cascade="all, delete-orphan")


class ResourceSkill(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    """Resource Tracker stores skills as free-text comma-separated strings; normalized here
    into individual rows so skill-based matching/search doesn't need string parsing at query time.
    """
    __tablename__ = "resource_skills"
    __table_args__ = (UniqueConstraint("resource_id", "skill", name="uq_resource_skill"),)

    resource_id: Mapped[uuid.UUID] = mapped_column(
        PG_UUID(as_uuid=True), ForeignKey("resources.id"), nullable=False, index=True
    )
    skill: Mapped[str] = mapped_column(String(255), nullable=False, index=True)

    resource: Mapped["Resource"] = relationship(back_populates="skills")
