"""Canonical Requirement model, mapped from Requirement Tracker / Outlook / Teams sources.

Column choices follow the actual Requirement Tracker schema (S.No., Account/Portfolio,
Country, Location, Skill Category, Skill, Role, Billing Type, CE Mandatory, Request Id,
Requirement Id, Requirement Type, dates, Status, Remarks, Billing WeekNum, Portfolio/Team).
Important, queryable/indexed fields are relational columns; everything else (loosely
structured or source-specific) lives in `extra` JSONB so we never force every source
column into a rigid schema (spec section 12).
"""
import uuid
from datetime import date
from decimal import Decimal

from sqlalchemy import String, Date, ForeignKey, UniqueConstraint, Integer
from sqlalchemy.dialects.postgresql import UUID as PG_UUID, JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.session import Base
from app.db.mixins import UUIDPrimaryKeyMixin, TimestampMixin
from app.core.enums import RequirementType, SourceType


class Requirement(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    """One canonical requirement. RJS is the unique business identifier (never LLM-generated)."""
    __tablename__ = "requirements"

    rjs: Mapped[str] = mapped_column(String(64), unique=True, nullable=False, index=True)

    # Authoritative source identifiers, preserved as-is when present (Requirement Tracker's
    # own "Request Id" and "Requirement Id" columns). Not the internal UUID PK, not the RJS
    # necessarily -- these are what the source system called the record.
    source_request_id: Mapped[str | None] = mapped_column(String(64), nullable=True, index=True)
    source_requirement_id: Mapped[str | None] = mapped_column(String(64), nullable=True, index=True)

    account_portfolio: Mapped[str | None] = mapped_column(String(255), nullable=True, index=True)
    country: Mapped[str | None] = mapped_column(String(100), nullable=True)
    location: Mapped[str | None] = mapped_column(String(255), nullable=True, index=True)
    skill_category: Mapped[str | None] = mapped_column(String(100), nullable=True, index=True)
    skill: Mapped[str | None] = mapped_column(String(500), nullable=True)
    role: Mapped[str | None] = mapped_column(String(50), nullable=True)  # Lead / Non Lead
    billing_type: Mapped[str | None] = mapped_column(String(20), nullable=True)  # T&M / FP / SLM / PTK
    ce_mandatory: Mapped[bool | None] = mapped_column(nullable=True)
    requirement_type: Mapped[RequirementType | None] = mapped_column(String(20), nullable=True)
    quantity: Mapped[int] = mapped_column(Integer, default=1, nullable=False)
    portfolio_team: Mapped[str | None] = mapped_column(String(255), nullable=True)
    requester: Mapped[str | None] = mapped_column(String(255), nullable=True)
    priority: Mapped[str | None] = mapped_column(String(20), nullable=True)

    requirement_open_date: Mapped[date | None] = mapped_column(Date, nullable=True)
    billing_start_date: Mapped[date | None] = mapped_column(Date, nullable=True)

    remarks: Mapped[str | None] = mapped_column(String(2000), nullable=True)

    # Loosely structured / not-yet-modeled source fields (e.g. Billing WeekNum, Detailed Status).
    extra: Mapped[dict] = mapped_column(JSONB, default=dict, nullable=False)

    sources: Mapped[list["RequirementSource"]] = relationship(
        back_populates="requirement", cascade="all, delete-orphan"
    )
    versions: Mapped[list["RequirementVersion"]] = relationship(
        back_populates="requirement", cascade="all, delete-orphan", order_by="RequirementVersion.created_at"
    )


class RequirementSource(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    """Links a requirement to every raw source record that fed it (Excel row, email, chat msg).

    A single RJS can have multiple sources (spec section 2 example: Excel + Outlook + Teams).
    Uniqueness on (source_type, source_identifier) implements idempotency (spec section 22):
    reprocessing the same email/row/message can never create a duplicate requirement.
    """
    __tablename__ = "requirement_sources"
    __table_args__ = (
        UniqueConstraint("source_type", "source_identifier", name="uq_requirement_source_identity"),
    )

    requirement_id: Mapped[uuid.UUID] = mapped_column(
        PG_UUID(as_uuid=True), ForeignKey("requirements.id"), nullable=False, index=True
    )
    source_type: Mapped[SourceType] = mapped_column(String(30), nullable=False)
    # Stable identifier from the source system: Excel item_id+row key, Outlook message ID,
    # Teams message ID, etc. Combined with source_type this is the idempotency key.
    source_identifier: Mapped[str] = mapped_column(String(500), nullable=False)
    raw_payload: Mapped[dict] = mapped_column(JSONB, default=dict, nullable=False)

    requirement: Mapped["Requirement"] = relationship(back_populates="sources")


class RequirementVersion(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    """Immutable snapshot of a requirement's field values at a point in time (history, not current-state)."""
    __tablename__ = "requirement_versions"

    requirement_id: Mapped[uuid.UUID] = mapped_column(
        PG_UUID(as_uuid=True), ForeignKey("requirements.id"), nullable=False, index=True
    )
    snapshot: Mapped[dict] = mapped_column(JSONB, nullable=False)
    changed_by: Mapped[str | None] = mapped_column(String(255), nullable=True)
    change_reason: Mapped[str | None] = mapped_column(String(255), nullable=True)

    requirement: Mapped["Requirement"] = relationship(back_populates="versions")
