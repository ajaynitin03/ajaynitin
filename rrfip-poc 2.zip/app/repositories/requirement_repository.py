"""Requirement DB access, isolated from business logic (spec: Service -> Repository/DB)."""
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.enums import SourceType
from app.models.requirement import Requirement, RequirementSource


def get_by_rjs(db: Session, rjs: str) -> Requirement | None:
    return db.execute(select(Requirement).where(Requirement.rjs == rjs)).scalar_one_or_none()


def get_source_event(db: Session, source_type: SourceType, source_identifier: str) -> RequirementSource | None:
    return db.execute(
        select(RequirementSource).where(
            RequirementSource.source_type == source_type,
            RequirementSource.source_identifier == source_identifier,
        )
    ).scalar_one_or_none()


def list_requirements(
    db: Session,
    *,
    status: str | None = None,
    skill: str | None = None,
    location: str | None = None,
    limit: int = 50,
    offset: int = 0,
) -> list[Requirement]:
    from app.models.fulfillment import FulfillmentRecord

    stmt = select(Requirement)
    if status:
        stmt = stmt.join(FulfillmentRecord).where(FulfillmentRecord.status == status)
    if skill:
        stmt = stmt.where(Requirement.skill.ilike(f"%{skill}%"))
    if location:
        stmt = stmt.where(Requirement.location.ilike(f"%{location}%"))
    stmt = stmt.order_by(Requirement.created_at.desc()).limit(limit).offset(offset)
    return list(db.execute(stmt).scalars().all())
