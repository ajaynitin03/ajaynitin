from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, ConfigDict


class FulfillmentOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    requirement_id: UUID
    status: str
    matched_resource_id: UUID | None
    delivery_manager: str | None
    delivery_partner: str | None
    updated_by: str | None
    updated_at: datetime


class FulfillmentEventOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    from_status: str | None
    to_status: str
    actor: str | None
    reason: str | None
    created_at: datetime


class AuditLogOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    actor: str | None
    action: str
    entity: str
    entity_id: str | None
    rjs: str | None
    field: str | None
    old_value: str | None
    new_value: str | None
    source: str | None
    created_at: datetime
