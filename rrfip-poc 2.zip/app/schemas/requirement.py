from datetime import date, datetime
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field


class RequirementCreateRequest(BaseModel):
    account_portfolio: str | None = None
    country: str | None = None
    location: str | None = None
    skill_category: str | None = None
    skill: str | None = None
    role: str | None = None
    billing_type: str | None = None
    ce_mandatory: bool | None = None
    requirement_type: str | None = None
    quantity: int = Field(default=1, ge=1)
    portfolio_team: str | None = None
    remarks: str | None = None
    authoritative_id: str | None = None


class RequirementUpdateRequest(BaseModel):
    location: str | None = None
    skill: str | None = None
    remarks: str | None = None
    quantity: int | None = Field(default=None, ge=1)


class RequirementOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    # UUID, not str: the ORM attribute is a real uuid.UUID (see app/db/mixins.py). Typing
    # this as UUID lets Pydantic's native UUID support handle validation/serialization
    # explicitly and correctly, rather than relying on str-coercion-from-UUID behavior that
    # was previously unverified. Pydantic serializes UUID to its standard string form in
    # the JSON response either way -- the frontend's `id: string` TS type is unaffected.
    id: UUID
    rjs: str
    account_portfolio: str | None
    country: str | None
    location: str | None
    skill_category: str | None
    skill: str | None
    role: str | None
    billing_type: str | None
    requirement_type: str | None
    quantity: int
    remarks: str | None
    requirement_open_date: date | None
    billing_start_date: date | None
    created_at: datetime
    updated_at: datetime


class StatusChangeRequest(BaseModel):
    status: str
    reason: str | None = None
