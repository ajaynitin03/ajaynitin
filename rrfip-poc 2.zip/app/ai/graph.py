"""The actual LangGraph orchestration for AI-sourced (Outlook/Teams) requirement processing.

This is a REAL langgraph.graph.StateGraph -- not documentation describing one, and not a
plain Python function chain dressed up as "AI processing". Excel-sourced requirements skip
this graph entirely (see app/workers/handlers.py::handle_normalize_source_event) because they
already carry structured, authoritative fields and need no extraction or duplicate inference
from free text.

Graph shape (spec section 16):

    START -> extract_requirement -> validate_extraction -> detect_duplicates
          -> resolve_rjs_and_ingest -> match_resources -> recommend_fulfillment -> END

Hard rules enforced by construction, not convention:
  - The LLM node (extract_requirement) NEVER touches RJS or fulfillment status. Those are
    set by resolve_rjs_and_ingest and recommend_fulfillment, both of which call only
    deterministic services (rjs_service via requirement_service.ingest_requirement,
    fulfillment_service.transition_status).
  - A low-confidence or malformed extraction short-circuits to human review instead of
    continuing through duplicate detection / RJS resolution with garbage data.
  - A DUPLICATE verdict reuses the existing RJS (passed as authoritative_id) rather than
    minting a new one -- this is what prevents a second RJS for the same requirement arriving
    via a different source/wording.
"""
from typing import TypedDict

from langgraph.graph import END, START, StateGraph
from sqlalchemy.orm import Session

from app.ai.requirement_intelligence import extract_requirement_from_text
from app.ai.schemas import ExtractedRequirement
from app.core.enums import DuplicateVerdict, FulfillmentStatus, SourceType, UserRole
from app.models.ai import AIRun, HumanReview
from app.models.requirement import Requirement
from app.services.audit_service import record_audit
from app.services.duplicate_detection_service import detect_duplicate_for_fields
from app.services.fulfillment_service import get_or_create_fulfillment_record, transition_status
from app.services.requirement_service import NormalizedRequirementInput, ingest_requirement
from app.services.resource_matching_service import rank_resource_matches

LOW_CONFIDENCE_THRESHOLD = 0.5
# A match above this score is considered strong enough to move a requirement straight to
# IDENTIFIED; below it, the requirement stays OPEN pending a human decision. This mirrors
# spec section 43's acceptance scenario ("If a suitable resource is identified: IDENTIFIED.
# If none: OPEN") without ever letting the AI itself set the status.
STRONG_MATCH_SCORE_THRESHOLD = 0.6


class RequirementProcessingState(TypedDict, total=False):
    # Input
    source_type: str
    source_identifier: str
    raw_text: str
    raw_payload: dict

    # After extract_requirement
    extracted: dict
    confidence: float

    # After detect_duplicates
    duplicate_verdict: str
    duplicate_match_rjs: str | None
    duplicate_score: float

    # After resolve_rjs_and_ingest
    rjs: str | None
    requirement_id: str | None
    routed_to_review: bool

    # After match_resources
    candidate_match_count: int
    best_match_score: float

    # After recommend_fulfillment
    fulfillment_status: str | None

    errors: list[str]


def _node_extract_requirement(state: RequirementProcessingState, *, db: Session) -> dict:
    extracted, run_meta = extract_requirement_from_text(state["raw_text"])
    db.add(
        AIRun(
            agent_name="requirement_intelligence",
            model=run_meta["model"],
            input_summary=run_meta["input_summary"],
            output=extracted.model_dump(),
            confidence=extracted.confidence,
            success=extracted.confidence > 0,
            error=run_meta.get("error"),
        )
    )
    db.commit()
    return {"extracted": extracted.model_dump(), "confidence": extracted.confidence}


def _node_validate_extraction(state: RequirementProcessingState, *, db: Session) -> dict:
    if state["confidence"] < LOW_CONFIDENCE_THRESHOLD:
        db.add(
            HumanReview(
                reason="low_confidence_extraction",
                context={"extracted": state["extracted"], "source_identifier": state["source_identifier"]},
            )
        )
        db.commit()
        return {"routed_to_review": True, "errors": [*state.get("errors", []), "low_confidence_extraction"]}
    return {"routed_to_review": False}


def _node_detect_duplicates(state: RequirementProcessingState, *, db: Session) -> dict:
    extracted = state["extracted"]
    skills_text = ", ".join(extracted.get("skills") or []) or None
    verdict, match, score = detect_duplicate_for_fields(
        db,
        account_portfolio=extracted.get("portfolio") or extracted.get("business_unit"),
        location=extracted.get("location"),
        skill=skills_text,
    )
    return {
        "duplicate_verdict": verdict.value,
        "duplicate_match_rjs": match.rjs if match else None,
        "duplicate_score": score,
    }


def _node_resolve_rjs_and_ingest(state: RequirementProcessingState, *, db: Session) -> dict:
    verdict = DuplicateVerdict(state["duplicate_verdict"])
    extracted = state["extracted"]

    if verdict in (DuplicateVerdict.NEEDS_REVIEW, DuplicateVerdict.PROBABLE_DUPLICATE):
        db.add(
            HumanReview(
                reason="ambiguous_duplicate",
                duplicate_verdict=verdict,
                context={"candidate_rjs": state["duplicate_match_rjs"], "score": state["duplicate_score"],
                         "extracted": extracted},
            )
        )
        db.commit()
        # Still ingest -- losing a real requirement because of an ambiguous match is worse
        # than flagging it for review while keeping it visible in the tracker (ties to
        # spec section 19's "do not blindly merge" -- blindly DROPPING is equally wrong).

    # DUPLICATE: reuse the existing RJS by passing it as the authoritative_id -- rjs_service
    # preserves an authoritative id as-is rather than generating a new one, which is exactly
    # "reuse existing RJS" from spec section 19.
    authoritative_id = state["duplicate_match_rjs"] if verdict == DuplicateVerdict.DUPLICATE else None

    normalized = NormalizedRequirementInput(
        source_type=SourceType(state["source_type"]),
        source_identifier=state["source_identifier"],
        authoritative_id=authoritative_id,
        skill=", ".join(extracted.get("skills") or []) or None,
        location=extracted.get("location"),
        account_portfolio=extracted.get("portfolio") or extracted.get("business_unit"),
        requirement_type=extracted.get("requirement_type"),
        quantity=extracted.get("quantity", 1),
        remarks=extracted.get("remarks"),
        raw_payload=state.get("raw_payload", {}),
    )
    requirement = ingest_requirement(db, normalized, actor="ai_pipeline")
    return {"rjs": requirement.rjs, "requirement_id": str(requirement.id)}


def _node_match_resources(state: RequirementProcessingState, *, db: Session) -> dict:
    requirement = db.get(Requirement, state["requirement_id"])
    if requirement is None:
        return {"candidate_match_count": 0, "best_match_score": 0.0,
                "errors": [*state.get("errors", []), "requirement_not_found_for_matching"]}

    from app.models.ai import ResourceMatch

    ranked = rank_resource_matches(db, requirement)
    for rank, item in enumerate(ranked, start=1):
        db.add(
            ResourceMatch(
                requirement_id=requirement.id,
                resource_id=item["resource"].id,
                score=item["score"],
                rank=rank,
                reasons=item["reasons"],
            )
        )
    db.commit()

    best_score = ranked[0]["score"] if ranked else 0.0
    return {"candidate_match_count": len(ranked), "best_match_score": best_score}


def _node_recommend_fulfillment(state: RequirementProcessingState, *, db: Session) -> dict:
    """Deterministic fulfillment recommendation -- the AI graph reaches this node, but the
    actual status transition goes through fulfillment_service, the same deterministic,
    audited, role-gated code path the API uses. The LLM's confidence never appears here;
    only the resource-matching score (itself deterministic) decides the recommendation.

    A DUPLICATE verdict can route here for a requirement whose FulfillmentRecord already
    exists and is CLOSED (e.g. a later Outlook mention of an already-closed requirement) --
    fulfillment_service correctly rejects CLOSED -> * for a non-elevated actor, and this node
    treats that as "nothing to recommend" rather than letting the exception fail the whole
    job. The AI pipeline never force-reopens a closed requirement.
    """
    from app.services.fulfillment_service import ForbiddenTransitionError, InvalidTransitionError

    requirement = db.get(Requirement, state["requirement_id"])
    if requirement is None:
        return {"fulfillment_status": None}

    record = get_or_create_fulfillment_record(db, requirement)
    target_status = (
        FulfillmentStatus.IDENTIFIED
        if state.get("best_match_score", 0.0) >= STRONG_MATCH_SCORE_THRESHOLD
        else FulfillmentStatus.OPEN
    )

    if record.status != target_status:
        try:
            transition_status(
                db, record, target_status,
                # System-initiated recommendation, not a real elevated user -- only relevant
                # for the CLOSED-reopen check, which this node deliberately does NOT attempt
                # to force (see docstring): a real CLOSED->* transition here still hits the
                # same role gate as the API and is caught below, never bypassed.
                actor="ai_pipeline", actor_roles={UserRole.ADMIN},
                reason="AI pipeline resource-matching recommendation",
                rjs=requirement.rjs,
            )
        except (ForbiddenTransitionError, InvalidTransitionError) as exc:
            # Record already CLOSED (or some other disallowed transition) -- leave it as-is
            # and note why, rather than failing the whole pipeline run over a recommendation
            # that was never going to be actioned anyway.
            return {"fulfillment_status": record.status.value,
                    "errors": [*state.get("errors", []), f"fulfillment_recommendation_skipped: {exc}"]}
    db.commit()
    return {"fulfillment_status": record.status.value}


def build_requirement_processing_graph(db: Session):
    """Compile the graph, binding each node to this call's db session via closures. A fresh
    graph is built per job invocation (cheap -- compilation is not the expensive part) so
    there's no shared mutable state across concurrent worker jobs.
    """
    graph = StateGraph(RequirementProcessingState)

    graph.add_node("extract_requirement", lambda s: _node_extract_requirement(s, db=db))
    graph.add_node("validate_extraction", lambda s: _node_validate_extraction(s, db=db))
    graph.add_node("detect_duplicates", lambda s: _node_detect_duplicates(s, db=db))
    graph.add_node("resolve_rjs_and_ingest", lambda s: _node_resolve_rjs_and_ingest(s, db=db))
    graph.add_node("match_resources", lambda s: _node_match_resources(s, db=db))
    graph.add_node("recommend_fulfillment", lambda s: _node_recommend_fulfillment(s, db=db))

    graph.add_edge(START, "extract_requirement")
    graph.add_edge("extract_requirement", "validate_extraction")

    def route_after_validation(state: RequirementProcessingState) -> str:
        # Low-confidence extractions stop here -- already routed to human review by the
        # validate_extraction node. No RJS, no duplicate check, no matching on garbage data.
        return END if state.get("routed_to_review") else "detect_duplicates"

    graph.add_conditional_edges("validate_extraction", route_after_validation, {
        "detect_duplicates": "detect_duplicates", END: END,
    })

    graph.add_edge("detect_duplicates", "resolve_rjs_and_ingest")
    graph.add_edge("resolve_rjs_and_ingest", "match_resources")
    graph.add_edge("match_resources", "recommend_fulfillment")
    graph.add_edge("recommend_fulfillment", END)

    return graph.compile()


def run_requirement_processing_pipeline(
    db: Session, *, source_type: str, source_identifier: str, raw_text: str, raw_payload: dict
) -> RequirementProcessingState:
    """Entry point called from app/workers/handlers.py::handle_run_ai_extraction."""
    compiled_graph = build_requirement_processing_graph(db)
    initial_state: RequirementProcessingState = {
        "source_type": source_type,
        "source_identifier": source_identifier,
        "raw_text": raw_text,
        "raw_payload": raw_payload,
        "errors": [],
    }
    return compiled_graph.invoke(initial_state)
