"""Requirement Intelligence agent: turns free-text Outlook/Teams content into structured
requirement data. Depends on the LLMProvider abstraction (app/ai/llm_provider.py), never on
a specific provider SDK -- swapping providers means changing LLM_PROVIDER in .env, not this
file.
"""
import json

from pydantic import ValidationError

from app.ai.llm_provider import LLMProviderError, get_llm_provider
from app.ai.schemas import ExtractedRequirement

EXTRACTION_SYSTEM_PROMPT = """You extract structured IT resource requirement data from raw \
email or chat text. Respond with ONLY a JSON object matching this schema, nothing else:

{
  "requirement_type": "New" | "Replacement" | null,
  "skills": ["string", ...],
  "experience_years": number | null,
  "location": "string" | null,
  "quantity": integer (>=1, default 1),
  "project": "string" | null,
  "portfolio": "string" | null,
  "business_unit": "string" | null,
  "requester": "string" | null,
  "priority": "string" | null,
  "start_date": "string" | null,
  "target_date": "string" | null,
  "remarks": "string" | null,
  "confidence": number between 0.0 and 1.0
}

Set confidence low (below 0.5) if the text is ambiguous or doesn't clearly describe a \
resource requirement. Never invent an identifier, ticket number, or requisition ID -- \
that is handled outside of you."""

PROMPT_VERSION = "requirement-intelligence-v1"
MAX_EXTRACTION_ATTEMPTS = 2


def _parse_llm_output(raw_output: str) -> ExtractedRequirement:
    cleaned = raw_output.removeprefix("```json").removeprefix("```").removesuffix("```").strip()
    parsed_json = json.loads(cleaned)
    return ExtractedRequirement.model_validate(parsed_json)


def extract_requirement_from_text(raw_text: str) -> tuple[ExtractedRequirement, dict]:
    """Call the configured LLM provider, validate its output against ExtractedRequirement,
    and return both the parsed result and AI-run metadata (for storage in ai_runs).

    Retries once (bounded, per spec section 18) on a validation/parse failure before falling
    back to a zero-confidence result that routes to human review -- never retries unboundedly.
    """
    provider = get_llm_provider()
    last_raw_output = ""
    last_error: str | None = None

    for attempt in range(MAX_EXTRACTION_ATTEMPTS):
        try:
            response = provider.complete(system=EXTRACTION_SYSTEM_PROMPT, user_message=raw_text, max_tokens=1000)
        except LLMProviderError as exc:
            last_error = str(exc)
            break  # provider-level failure (network, auth) -- retrying won't help, stop immediately

        last_raw_output = response.text or ""
        try:
            extracted = _parse_llm_output(last_raw_output)
            run_metadata = {
                "model": response.model,
                "raw_output": last_raw_output,
                "input_summary": {"text_length": len(raw_text)},
                "prompt_version": PROMPT_VERSION,
                "attempts": attempt + 1,
            }
            return extracted, run_metadata
        except (json.JSONDecodeError, ValidationError) as exc:
            last_error = str(exc)
            continue  # bounded retry -- loop condition caps this at MAX_EXTRACTION_ATTEMPTS

    # Every attempt failed (or the provider itself errored) -- zero-confidence result routes
    # to human review rather than silently ingesting garbage or crashing the pipeline.
    extracted = ExtractedRequirement(confidence=0.0, remarks=f"AI extraction failed: {last_error}")
    run_metadata = {
        "model": get_settings_model_fallback(),
        "raw_output": last_raw_output,
        "input_summary": {"text_length": len(raw_text)},
        "prompt_version": PROMPT_VERSION,
        "attempts": MAX_EXTRACTION_ATTEMPTS,
        "error": last_error,
    }
    return extracted, run_metadata


def get_settings_model_fallback() -> str:
    from app.core.config import get_settings

    return get_settings().llm_model
