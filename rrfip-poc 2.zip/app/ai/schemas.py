"""Structured output contract for the Requirement Intelligence agent. The LLM must return
data matching this schema exactly -- it NEVER outputs or influences the RJS (spec section 2).
"""
from pydantic import BaseModel, Field


class ExtractedRequirement(BaseModel):
    requirement_type: str | None = Field(default=None, description="New or Replacement")
    skills: list[str] = Field(default_factory=list)
    experience_years: float | None = None
    location: str | None = None
    quantity: int = Field(default=1, ge=1)
    project: str | None = None
    portfolio: str | None = None
    business_unit: str | None = None
    requester: str | None = None
    priority: str | None = None
    start_date: str | None = None
    target_date: str | None = None
    remarks: str | None = None
    confidence: float = Field(ge=0.0, le=1.0)
