"""Anthropic Messages API adapter. This is the ONLY file in the codebase that knows the
shape of Anthropic's API request/response format -- app/ai/requirement_intelligence.py and
app/ai/chat_query.py talk to LLMProvider, never to this module or to httpx directly.
"""
import httpx

from app.ai.llm_provider import LLMProvider, LLMProviderError, LLMResponse, ToolDefinition, ToolUse


class AnthropicProvider(LLMProvider):
    def __init__(self, *, api_key: str, endpoint: str, model: str, timeout: float = 30.0):
        self._api_key = api_key
        self._endpoint = endpoint
        self._model = model
        self._timeout = timeout

    def complete(
        self,
        *,
        system: str,
        user_message: str,
        max_tokens: int = 1000,
        tools: list[ToolDefinition] | None = None,
    ) -> LLMResponse:
        if not self._api_key:
            raise LLMProviderError("LLM_API_KEY is not configured")

        body = {
            "model": self._model,
            "max_tokens": max_tokens,
            "system": system,
            "messages": [{"role": "user", "content": user_message}],
        }
        if tools:
            body["tools"] = [
                {"name": t.name, "description": t.description, "input_schema": t.input_schema} for t in tools
            ]

        try:
            response = httpx.post(
                self._endpoint,
                headers={
                    "x-api-key": self._api_key,
                    "anthropic-version": "2023-06-01",
                    "content-type": "application/json",
                },
                json=body,
                timeout=self._timeout,
            )
            response.raise_for_status()
        except httpx.HTTPStatusError as exc:
            raise LLMProviderError(f"Anthropic API error {exc.response.status_code}: {exc.response.text[:300]}") from exc
        except httpx.RequestError as exc:
            raise LLMProviderError(f"Anthropic API request failed: {exc}") from exc

        payload = response.json()
        content_blocks = payload.get("content", [])

        text_blocks = [b["text"] for b in content_blocks if b.get("type") == "text"]
        text = "\n".join(text_blocks).strip() or None

        tool_use = None
        tool_block = next((b for b in content_blocks if b.get("type") == "tool_use"), None)
        if tool_block:
            tool_use = ToolUse(name=tool_block["name"], input=tool_block.get("input", {}))

        return LLMResponse(text=text, tool_use=tool_use, model=self._model, raw=payload)
