"""LLM provider abstraction.

Business agents (app/ai/requirement_intelligence.py, app/ai/chat_query.py, app/ai/graph.py)
depend on this interface, never on a provider SDK or raw HTTP call directly. Swapping the
enterprise LLM endpoint/provider means writing one new class here and pointing LLM_PROVIDER
at it in .env -- nothing in the business logic changes.
"""
from abc import ABC, abstractmethod
from dataclasses import dataclass, field


@dataclass
class ToolDefinition:
    name: str
    description: str
    input_schema: dict


@dataclass
class ToolUse:
    name: str
    input: dict


@dataclass
class LLMResponse:
    text: str | None
    tool_use: ToolUse | None
    model: str
    raw: dict = field(default_factory=dict)


class LLMProvider(ABC):
    """Minimal interface every provider adapter must implement. Kept intentionally small --
    text completion plus optional single tool-call support, which is all the current agents
    (structured extraction, controlled chat query) need.
    """

    @abstractmethod
    def complete(
        self,
        *,
        system: str,
        user_message: str,
        max_tokens: int = 1000,
        tools: list[ToolDefinition] | None = None,
    ) -> LLMResponse:
        """Send one request, return the model's text and/or a single tool call it chose."""
        raise NotImplementedError


class LLMProviderError(Exception):
    """Raised on any failure to reach or get a valid response from the configured provider."""


def get_llm_provider() -> LLMProvider:
    """Factory: returns the configured provider based on settings.llm_provider. This is the
    ONLY place that decides which concrete provider class to instantiate.
    """
    from app.core.config import get_settings

    settings = get_settings()

    if settings.llm_provider == "anthropic":
        from app.ai.providers.anthropic_provider import AnthropicProvider

        return AnthropicProvider(
            api_key=settings.llm_api_key, endpoint=settings.llm_endpoint, model=settings.llm_model
        )

    raise LLMProviderError(
        f"Unknown LLM_PROVIDER '{settings.llm_provider}'. Add a new provider class under "
        f"app/ai/providers/ and register it in get_llm_provider() to support it."
    )
