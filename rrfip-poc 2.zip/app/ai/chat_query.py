"""Controlled conversational query layer (spec section 27/31). The LLM NEVER writes or
executes arbitrary SQL -- it only selects among a small set of predefined, parameterized
query tools and fills in their parameters. Authorization is applied server-side (the
get_current_user dependency on the /chat/query route) BEFORE this module is even reached.
Depends on the LLMProvider abstraction, not a specific provider SDK.
"""
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.ai.llm_provider import LLMProviderError, ToolDefinition, get_llm_provider
from app.core.enums import FulfillmentStatus
from app.models.fulfillment import FulfillmentRecord
from app.models.requirement import Requirement

QUERY_TOOLS = [
    ToolDefinition(
        name="count_requirements_by_status",
        description="Count requirements matching an optional status filter",
        input_schema={
            "type": "object",
            "properties": {"status": {"type": "string", "enum": [s.value for s in FulfillmentStatus]}},
        },
    ),
    ToolDefinition(
        name="list_requirements_by_skill_and_location",
        description="List open/identified requirements filtered by skill and/or location",
        input_schema={
            "type": "object",
            "properties": {
                "skill": {"type": "string"},
                "location": {"type": "string"},
                "status": {"type": "string", "enum": [s.value for s in FulfillmentStatus]},
            },
        },
    ),
    ToolDefinition(
        name="top_skills_by_demand",
        description="Return the skills with the highest requirement demand",
        input_schema={"type": "object", "properties": {"limit": {"type": "integer"}}},
    ),
]


def _execute_tool(db: Session, name: str, tool_input: dict) -> dict | list:
    """The ONLY place query execution happens. Every branch here is a fixed, parameterized
    query -- there is no code path from LLM output to a raw SQL string.
    """
    if name == "count_requirements_by_status":
        stmt = select(func.count()).select_from(FulfillmentRecord)
        if tool_input.get("status"):
            stmt = stmt.where(FulfillmentRecord.status == tool_input["status"])
        return {"count": db.execute(stmt).scalar_one()}

    if name == "list_requirements_by_skill_and_location":
        stmt = select(Requirement.rjs, Requirement.skill, Requirement.location).join(FulfillmentRecord)
        if tool_input.get("skill"):
            stmt = stmt.where(Requirement.skill.ilike(f"%{tool_input['skill']}%"))
        if tool_input.get("location"):
            stmt = stmt.where(Requirement.location.ilike(f"%{tool_input['location']}%"))
        if tool_input.get("status"):
            stmt = stmt.where(FulfillmentRecord.status == tool_input["status"])
        rows = db.execute(stmt.limit(50)).all()
        return [{"rjs": r, "skill": s, "location": loc} for r, s, loc in rows]

    if name == "top_skills_by_demand":
        limit = tool_input.get("limit", 10)
        stmt = select(Requirement.skill, func.count()).group_by(Requirement.skill).order_by(func.count().desc()).limit(limit)
        rows = db.execute(stmt).all()
        return [{"skill": s, "count": c} for s, c in rows if s]

    raise ValueError(f"Unknown query tool: {name}")


def answer_chat_query(db: Session, question: str) -> dict:
    """Ask the LLM to pick a query tool + params, execute it deterministically. If the LLM
    doesn't choose a tool (question outside the supported set) or the provider fails, return
    a safe, informative response rather than propagating an unhandled exception.
    """
    try:
        provider = get_llm_provider()
        response = provider.complete(
            system="You are a query router. Choose the best matching tool for the user's question.",
            user_message=question,
            max_tokens=500,
            tools=QUERY_TOOLS,
        )
    except LLMProviderError as exc:
        return {"answer": f"Query service is temporarily unavailable: {exc}", "data": None}

    if response.tool_use is None:
        return {
            "answer": "I can only answer questions about requirement counts, filters, or skill demand.",
            "data": None,
        }

    result = _execute_tool(db, response.tool_use.name, response.tool_use.input)
    return {"answer": None, "tool_used": response.tool_use.name, "data": result}
