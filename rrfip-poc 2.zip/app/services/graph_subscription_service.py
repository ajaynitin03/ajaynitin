"""Graph subscription lifecycle management. Creating a subscription via GraphClient and
persisting its expiration here are always done together -- a subscription this app doesn't
know the expiration of can never be renewed in time.
"""
from datetime import datetime, timedelta, UTC

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.integrations.graph.client import GraphClient
from app.models.graph_subscription import GraphSubscription

SUBSCRIPTION_LIFETIME = timedelta(hours=70)  # just under Graph's ~3-day mail subscription max
RENEWAL_LOOKAHEAD = timedelta(hours=6)  # renew subscriptions expiring within this window


def create_and_track_outlook_subscription(
    db: Session, graph: GraphClient, *, mailbox_id: str, notification_url: str
) -> GraphSubscription:
    expiration_iso = (datetime.now(UTC) + SUBSCRIPTION_LIFETIME).isoformat().replace("+00:00", "Z")
    result = graph.subscribe_outlook_changes(mailbox_id, notification_url, expiration_iso)
    return _persist_subscription(db, result, resource_type="OUTLOOK", notification_url=notification_url)


def create_and_track_teams_subscription(
    db: Session, graph: GraphClient, *, team_id: str, channel_id: str, notification_url: str
) -> GraphSubscription:
    expiration_iso = (datetime.now(UTC) + SUBSCRIPTION_LIFETIME).isoformat().replace("+00:00", "Z")
    result = graph.subscribe_teams_channel_changes(team_id, channel_id, notification_url, expiration_iso)
    return _persist_subscription(db, result, resource_type="TEAMS", notification_url=notification_url)


def _persist_subscription(db: Session, graph_result: dict, *, resource_type: str, notification_url: str) -> GraphSubscription:
    record = GraphSubscription(
        subscription_id=graph_result["id"],
        resource_type=resource_type,
        resource=graph_result.get("resource", ""),
        notification_url=notification_url,
        expires_at=_parse_graph_datetime(graph_result["expirationDateTime"]),
    )
    db.add(record)
    db.commit()
    db.refresh(record)
    return record


def find_subscriptions_needing_renewal(db: Session) -> list[GraphSubscription]:
    """Subscriptions active and expiring within RENEWAL_LOOKAHEAD -- what a periodic sweep
    (app/workers/subscription_renewal_cli.py) should enqueue RENEW_GRAPH_SUBSCRIPTION jobs for.
    """
    cutoff = datetime.now(UTC) + RENEWAL_LOOKAHEAD
    stmt = select(GraphSubscription).where(
        GraphSubscription.is_active.is_(True), GraphSubscription.expires_at <= cutoff
    )
    return list(db.execute(stmt).scalars().all())


def mark_renewed(db: Session, record: GraphSubscription, new_expires_at: datetime) -> None:
    record.expires_at = new_expires_at
    record.last_renewed_at = datetime.now(UTC)
    db.commit()


def _parse_graph_datetime(value: str) -> datetime:
    return datetime.fromisoformat(value.replace("Z", "+00:00"))
