"""Requirement creation/ingestion orchestration.

Enforces idempotency (spec section 22): the same (source_type, source_identifier) can never
create a second requirement or a second RJS. If a source event repeats, we attach it to the
existing requirement (or no-op if already attached) instead of creating a duplicate.
"""
from dataclasses import dataclass

from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.core.enums import FulfillmentStatus, SourceType
from app.models.requirement import Requirement, RequirementSource
from app.repositories.requirement_repository import get_source_event
from app.services.audit_service import record_audit
from app.services.fulfillment_service import get_or_create_fulfillment_record
from app.services.rjs_service import find_requirement_by_rjs, resolve_rjs


@dataclass
class NormalizedRequirementInput:
    """Output of the source-to-canonical mapping layer (Excel row / email / chat message
    already normalized into requirement fields). authoritative_id, when present, comes from
    the source system's own Request Id / Requirement Id -- never invented.
    """
    source_type: SourceType
    source_identifier: str
    authoritative_id: str | None
    account_portfolio: str | None = None
    country: str | None = None
    location: str | None = None
    skill_category: str | None = None
    skill: str | None = None
    role: str | None = None
    billing_type: str | None = None
    ce_mandatory: bool | None = None
    requirement_type: str | None = None
    quantity: int = 1
    portfolio_team: str | None = None
    remarks: str | None = None
    raw_payload: dict | None = None
    extra: dict | None = None


def ingest_requirement(db: Session, data: NormalizedRequirementInput, *, actor: str = "system") -> Requirement:
    """Create a new requirement, or attach this source to an existing one, idempotently."""
    existing_source = get_source_event(db, data.source_type, data.source_identifier)
    if existing_source is not None:
        return existing_source.requirement  # already processed -- no-op, satisfies idempotency

    requirement: Requirement | None = None
    if data.authoritative_id:
        requirement = find_requirement_by_rjs(db, data.authoritative_id.strip())

    is_new = requirement is None
    if is_new:
        rjs = resolve_rjs(db, data.authoritative_id)
        requirement = Requirement(
            rjs=rjs,
            account_portfolio=data.account_portfolio,
            country=data.country,
            location=data.location,
            skill_category=data.skill_category,
            skill=data.skill,
            role=data.role,
            billing_type=data.billing_type,
            ce_mandatory=data.ce_mandatory,
            requirement_type=data.requirement_type,
            quantity=data.quantity,
            portfolio_team=data.portfolio_team,
            remarks=data.remarks,
            extra=data.extra or {},
        )
        db.add(requirement)
        try:
            db.flush()
        except IntegrityError as exc:
            # Another process won the race on this RJS -- re-resolve against the now-existing row.
            db.rollback()
            requirement = find_requirement_by_rjs(db, rjs)
            if requirement is None:
                raise RuntimeError("RJS conflict could not be resolved") from exc
            is_new = False

    db.add(
        RequirementSource(
            requirement_id=requirement.id,
            source_type=data.source_type,
            source_identifier=data.source_identifier,
            raw_payload=data.raw_payload or {},
        )
    )

    if is_new:
        get_or_create_fulfillment_record(db, requirement)
        record_audit(
            db,
            action="requirement_created",
            entity="requirement",
            entity_id=str(requirement.id),
            rjs=requirement.rjs,
            actor=actor,
            source=data.source_type.value,
        )
    else:
        record_audit(
            db,
            action="source_attached",
            entity="requirement",
            entity_id=str(requirement.id),
            rjs=requirement.rjs,
            actor=actor,
            source=data.source_type.value,
            meta={"source_identifier": data.source_identifier},
        )

    db.commit()
    db.refresh(requirement)
    return requirement
