"""Single reusable audit-writing function. Every service that needs to audit something calls
this instead of constructing AuditLog rows inline (spec section 38: no duplicated DB logic).
"""
from sqlalchemy.orm import Session

from app.models.audit import AuditLog


def record_audit(
    db: Session,
    *,
    action: str,
    entity: str,
    entity_id: str | None = None,
    rjs: str | None = None,
    actor: str | None = None,
    field: str | None = None,
    old_value: str | None = None,
    new_value: str | None = None,
    source: str | None = None,
    correlation_id: str | None = None,
    meta: dict | None = None,
) -> AuditLog:
    entry = AuditLog(
        action=action,
        entity=entity,
        entity_id=entity_id,
        rjs=rjs,
        actor=actor,
        field=field,
        old_value=old_value,
        new_value=new_value,
        source=source,
        correlation_id=correlation_id,
        meta=meta or {},
    )
    db.add(entry)
    return entry
