"""Deterministic fulfillment status transitions (spec section 14).

Every status change is transactional and creates BOTH a FulfillmentEvent and an AuditLog.
Normal users cannot reopen CLOSED; only roles in ROLES_ALLOWED_TO_REOPEN_CLOSED can.
"""
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.enums import ALLOWED_TRANSITIONS, FulfillmentStatus, ROLES_ALLOWED_TO_REOPEN_CLOSED, UserRole
from app.models.fulfillment import FulfillmentEvent, FulfillmentRecord
from app.models.requirement import Requirement
from app.services.audit_service import record_audit


class InvalidTransitionError(Exception):
    pass


class ForbiddenTransitionError(Exception):
    pass


def get_or_create_fulfillment_record(db: Session, requirement: Requirement) -> FulfillmentRecord:
    record = db.execute(
        select(FulfillmentRecord).where(FulfillmentRecord.requirement_id == requirement.id)
    ).scalar_one_or_none()
    if record is None:
        record = FulfillmentRecord(requirement_id=requirement.id, status=FulfillmentStatus.OPEN)
        db.add(record)
        db.flush()
    return record


def transition_status(
    db: Session,
    record: FulfillmentRecord,
    to_status: FulfillmentStatus,
    *,
    actor: str,
    actor_roles: set[UserRole],
    reason: str | None = None,
    correlation_id: str | None = None,
    rjs: str | None = None,
) -> FulfillmentRecord:
    """Apply a validated, audited, transactional status transition."""
    from_status = record.status

    if from_status == to_status:
        return record  # no-op, nothing to transition

    if from_status == FulfillmentStatus.CLOSED and not actor_roles & ROLES_ALLOWED_TO_REOPEN_CLOSED:
        raise ForbiddenTransitionError("Only Admin or Delivery Manager may reopen a CLOSED requirement.")

    allowed = ALLOWED_TRANSITIONS.get(from_status, set())
    if to_status not in allowed:
        raise InvalidTransitionError(f"Cannot transition from {from_status.value} to {to_status.value}.")

    record.status = to_status
    record.updated_by = actor

    db.add(
        FulfillmentEvent(
            fulfillment_record_id=record.id,
            from_status=from_status,
            to_status=to_status,
            actor=actor,
            reason=reason,
            correlation_id=correlation_id,
        )
    )
    record_audit(
        db,
        action="fulfillment_status_change",
        entity="fulfillment_record",
        entity_id=str(record.id),
        rjs=rjs,
        actor=actor,
        field="status",
        old_value=from_status.value,
        new_value=to_status.value,
        source="api",
        correlation_id=correlation_id,
    )
    return record
