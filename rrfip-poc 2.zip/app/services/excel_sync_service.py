"""Excel workbook synchronization (spec sections 20-21).

Flow: Graph -> retrieve table rows -> normalize to row dicts -> diff against last
ExcelSnapshot -> persist changed rows -> update ExcelSyncState -> audit -> enqueue
normalization jobs for changed/new rows. Never claims cell-level authorship beyond
what Graph actually reports (workbook-level lastModifiedBy/lastModifiedDateTime).
"""
import hashlib
import json
from datetime import datetime, UTC

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.enums import JobStatus, JobType
from app.integrations.graph.client import GraphClient
from app.models.ingestion import ExcelSnapshot, ExcelSyncState
from app.models.job import Job
from app.services.audit_service import record_audit


def table_rows_to_dicts(header_row: list[str], value_rows: list[list]) -> list[dict]:
    """Convert a Graph table's header + value rows into a list of column-name-keyed dicts."""
    return [dict(zip(header_row, row)) for row in value_rows]


def row_key_for(row: dict, *, id_columns: tuple[str, ...]) -> str:
    """Deterministic per-row key: prefer an authoritative id column; fall back to a content hash
    (stable across syncs as long as row content doesn't change, which is the only case where
    the fallback key matters -- a changed row would already be caught by the id-based key).
    """
    for column in id_columns:
        value = row.get(column)
        if value not in (None, ""):
            return f"id:{value}"
    content = json.dumps(row, sort_keys=True, default=str)
    return f"hash:{hashlib.sha256(content.encode()).hexdigest()[:16]}"


def get_or_create_sync_state(
    db: Session, *, workbook_name: str, site_id: str, drive_id: str, item_id: str, worksheet_or_table: str
) -> ExcelSyncState:
    state = db.execute(
        select(ExcelSyncState).where(
            ExcelSyncState.site_id == site_id,
            ExcelSyncState.drive_id == drive_id,
            ExcelSyncState.item_id == item_id,
        )
    ).scalar_one_or_none()
    if state is None:
        state = ExcelSyncState(
            workbook_name=workbook_name,
            site_id=site_id,
            drive_id=drive_id,
            item_id=item_id,
            worksheet_or_table=worksheet_or_table,
        )
        db.add(state)
        db.flush()
    return state


def sync_workbook(
    db: Session,
    graph: GraphClient,
    *,
    workbook_name: str,
    site_id: str,
    drive_id: str,
    item_id: str,
    table_name: str | None,
    worksheet_name: str | None,
    id_columns: tuple[str, ...],
    normalize_job_type: JobType,
) -> dict:
    """Fetch current workbook state, diff against the last snapshot, persist + audit + enqueue.

    Pass `table_name` for workbooks that use a named Excel table, or `worksheet_name` as a
    fallback for workbooks that use a plain used-range instead. Exactly one should be set.

    Returns a summary dict: {"new": n, "changed": n, "unchanged": n}.
    """
    if not table_name and not worksheet_name:
        raise ValueError("sync_workbook requires either table_name or worksheet_name")

    state = get_or_create_sync_state(
        db, workbook_name=workbook_name, site_id=site_id, drive_id=drive_id, item_id=item_id,
        worksheet_or_table=table_name or worksheet_name,
    )

    item_metadata = graph.get_drive_item(site_id, drive_id, item_id)
    etag = item_metadata.get("eTag")
    last_modified_by = (item_metadata.get("lastModifiedBy", {}).get("user", {}) or {}).get("displayName")
    last_modified_at_raw = item_metadata.get("lastModifiedDateTime")

    if state.last_etag == etag:
        state.last_synced_at = datetime.now(UTC)
        state.sync_status = "unchanged"
        db.commit()
        return {"new": 0, "changed": 0, "unchanged": 0, "status": "no_change_since_last_sync"}

    if table_name:
        raw_rows = graph.get_worksheet_table_rows(drive_id, item_id, table_name)
        header_row = raw_rows[0]["values"][0] if raw_rows and raw_rows[0].get("values") else []
        value_rows = [r["values"][0] for r in raw_rows if r.get("values")]
    else:
        used_range = graph.get_worksheet_used_range(drive_id, item_id, worksheet_name)
        all_values = used_range.get("values", [])
        header_row = all_values[0] if all_values else []
        value_rows = all_values[1:] if len(all_values) > 1 else []

    current_rows = table_rows_to_dicts(header_row, value_rows) if header_row else []

    previous_snapshots = {
        s.row_key: s.row_data
        for s in db.execute(select(ExcelSnapshot).where(ExcelSnapshot.excel_sync_state_id == state.id)).scalars()
    }

    new_count = changed_count = unchanged_count = 0
    seen_keys = set()

    for row in current_rows:
        key = row_key_for(row, id_columns=id_columns)
        seen_keys.add(key)
        previous = previous_snapshots.get(key)

        if previous is None:
            new_count += 1
            db.add(ExcelSnapshot(excel_sync_state_id=state.id, row_key=key, row_data=row))
            db.add(Job(type=normalize_job_type, payload={"row": row, "row_key": key, "workbook": workbook_name}))
            record_audit(
                db, action="excel_row_added", entity="excel_snapshot", entity_id=key,
                source="excel_sync", meta={"workbook": workbook_name},
            )
        elif previous != row:
            changed_count += 1
            snap = db.execute(
                select(ExcelSnapshot).where(
                    ExcelSnapshot.excel_sync_state_id == state.id, ExcelSnapshot.row_key == key
                )
            ).scalar_one()
            snap.row_data = row
            db.add(Job(type=normalize_job_type, payload={"row": row, "row_key": key, "workbook": workbook_name}))
            record_audit(
                db, action="excel_row_changed", entity="excel_snapshot", entity_id=key,
                source="excel_sync", meta={"workbook": workbook_name},
            )
        else:
            unchanged_count += 1

    state.last_etag = etag
    state.last_modified_by = last_modified_by
    state.last_modified_at = _parse_graph_datetime(last_modified_at_raw)
    state.last_synced_at = datetime.now(UTC)
    state.sync_status = "synced"

    db.commit()
    return {"new": new_count, "changed": changed_count, "unchanged": unchanged_count}


def _parse_graph_datetime(value: str | None):
    if not value:
        return None
    return datetime.fromisoformat(value.replace("Z", "+00:00"))
