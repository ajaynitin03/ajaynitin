"""Login flow support.

Production path: the frontend runs MSAL.js interactive login against Entra ID, gets back an
Entra ID-issued ID token, and POSTs it to /auth/login. This module validates that token's
signature against Microsoft's public JWKS (never trusts an unverified token), looks up or
creates the corresponding User row, and issues our OWN short-lived app JWT that the rest of
the API expects (app/api/deps.py). We never forward the Entra ID token itself to other
endpoints -- our app JWT is the only credential the backend API accepts.

Dev path: issue_dev_token() skips Entra ID entirely so the app can be exercised locally
without a tenant. Gated to settings.environment == "development" at the route level.
"""
from datetime import datetime, timedelta, UTC

import jwt
from jwt import PyJWKClient
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.core.enums import UserRole
from app.models.user import User, UserRoleAssignment

settings = get_settings()

ENTRA_JWKS_URL_TEMPLATE = "https://login.microsoftonline.com/{tenant_id}/discovery/v2.0/keys"

# Default role granted to a user on their first successful login. Admin role must be
# assigned manually (e.g. directly in the DB or via an admin-only endpoint) -- never
# self-assigned through login.
DEFAULT_ROLE_ON_FIRST_LOGIN = UserRole.REQUIREMENT_TEAM

_jwks_client: PyJWKClient | None = None


def _get_jwks_client() -> PyJWKClient:
    global _jwks_client
    if _jwks_client is None:
        url = ENTRA_JWKS_URL_TEMPLATE.format(tenant_id=settings.graph_tenant_id)
        _jwks_client = PyJWKClient(url)
    return _jwks_client


def validate_entra_id_token(entra_token: str) -> dict:
    """Verify an Entra ID-issued token's signature and return its claims.

    Raises jwt.InvalidTokenError (or a subclass) if the token is invalid, expired, or its
    audience doesn't match our app registration.
    """
    signing_key = _get_jwks_client().get_signing_key_from_jwt(entra_token)
    claims = jwt.decode(
        entra_token,
        signing_key.key,
        algorithms=["RS256"],
        audience=settings.graph_client_id,
        issuer=f"https://login.microsoftonline.com/{settings.graph_tenant_id}/v2.0",
    )
    return claims


def get_or_create_user(db: Session, *, email: str, display_name: str, entra_object_id: str) -> User:
    user = db.execute(select(User).where(User.entra_object_id == entra_object_id)).scalar_one_or_none()
    if user is not None:
        return user

    user = db.execute(select(User).where(User.email == email)).scalar_one_or_none()
    if user is not None:
        user.entra_object_id = entra_object_id
        db.commit()
        return user

    user = User(email=email, display_name=display_name, entra_object_id=entra_object_id)
    db.add(user)
    db.flush()
    db.add(UserRoleAssignment(user_id=user.id, role=DEFAULT_ROLE_ON_FIRST_LOGIN))
    db.commit()
    db.refresh(user)
    return user


def issue_app_jwt(user: User) -> str:
    """Issue our own short-lived JWT. This is what app/api/deps.py validates on every request."""
    roles = [r.role for r in user.roles]
    payload = {
        "sub": str(user.id),
        "email": user.email,
        "roles": roles,
        "exp": datetime.now(UTC) + timedelta(minutes=settings.access_token_expire_minutes),
        "iat": datetime.now(UTC),
    }
    return jwt.encode(payload, settings.jwt_secret_key, algorithm=settings.jwt_algorithm)


def issue_dev_token(db: Session, *, email: str, roles: list[UserRole]) -> str:
    """Local-dev-only token issuance, bypassing Entra ID entirely. Gated at the route level
    to settings.environment == 'development' -- never expose this in a deployed environment.
    """
    user = db.execute(select(User).where(User.email == email)).scalar_one_or_none()
    if user is None:
        user = User(email=email, display_name=email.split("@")[0])
        db.add(user)
        db.flush()
    existing_roles = {r.role for r in user.roles}
    for role in roles:
        if role not in existing_roles:
            db.add(UserRoleAssignment(user_id=user.id, role=role))
    db.commit()
    db.refresh(user)
    return issue_app_jwt(user)
