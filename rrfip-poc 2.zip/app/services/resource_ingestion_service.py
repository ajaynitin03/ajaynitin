"""Resource ingestion: upserts a Resource (keyed by employee_id) and its ResourceSkill rows
from a mapped Resource Tracker row. Unlike requirements, resources have no RJS/idempotency
concern beyond employee_id uniqueness -- the same employee reappearing in a later sync is
expected and should update the existing row, not create a duplicate.
"""
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models.resource import Resource, ResourceSkill
from app.services.audit_service import record_audit


def ingest_resource(db: Session, mapped: dict, *, actor: str = "excel_sync") -> Resource:
    employee_id = mapped.get("employee_id")
    if not employee_id:
        raise ValueError("Resource row missing Emp ID -- cannot ingest without an employee identifier")

    resource = db.execute(select(Resource).where(Resource.employee_id == employee_id)).scalar_one_or_none()
    is_new = resource is None

    skills = mapped.pop("skills", [])
    extra = mapped.pop("extra", {})

    if is_new:
        resource = Resource(employee_id=employee_id, extra=extra, **{k: v for k, v in mapped.items() if k != "employee_id"})
        db.add(resource)
        db.flush()
    else:
        for field, value in mapped.items():
            if field == "employee_id":
                continue
            old_value = getattr(resource, field, None)
            if old_value != value:
                setattr(resource, field, value)
        resource.extra = extra

    existing_skills = {s.skill for s in resource.skills}
    for skill in skills:
        if skill not in existing_skills:
            db.add(ResourceSkill(resource_id=resource.id, skill=skill))

    record_audit(
        db,
        action="resource_created" if is_new else "resource_updated",
        entity="resource",
        entity_id=str(resource.id),
        actor=actor,
        source="resource_excel",
    )
    db.commit()
    db.refresh(resource)
    return resource
