"""Outlook/Teams webhook ingestion. Webhooks must return quickly (spec section 18) -- this
module only writes a SourceEvent + enqueues a job; it never does LLM/extraction work inline.
"""
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.core.enums import JobType, SourceType
from app.models.ingestion import SourceEvent
from app.models.job import Job


def ingest_webhook_notification(
    db: Session, *, source_type: SourceType, source_identifier: str, raw_payload: dict
) -> bool:
    """Record a raw webhook notification idempotently and enqueue normalization.

    Returns True if this created a new event, False if it was already seen (duplicate
    notification -- Graph is allowed to redeliver, so this must be a safe no-op).
    """
    event = SourceEvent(
        source_type=source_type,
        source_identifier=source_identifier,
        raw_payload=raw_payload,
    )
    db.add(event)
    try:
        db.flush()
    except IntegrityError:
        db.rollback()
        return False  # already recorded -- idempotent no-op

    db.add(
        Job(
            type=JobType.NORMALIZE_SOURCE_EVENT,
            payload={"source_type": source_type.value, "source_identifier": source_identifier},
            correlation_id=source_identifier,
        )
    )
    db.commit()
    return True
