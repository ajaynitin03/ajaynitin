"""Resource matching (spec section 26): deterministic filtering first, then ranking.
Never allocates automatically -- only produces ranked ResourceMatch candidates for
human/DM decision.
"""
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models.requirement import Requirement
from app.models.resource import Resource, ResourceSkill

SKILL_WEIGHT = 0.5
LOCATION_WEIGHT = 0.2
PORTFOLIO_WEIGHT = 0.2
AVAILABILITY_WEIGHT = 0.1


def _normalize(value: str | None) -> str:
    return (value or "").strip().lower()


def filter_candidate_resources(db: Session, requirement: Requirement) -> list[Resource]:
    """Deterministic hard filter: available resources only. Availability is never
    inferred from skills -- it comes straight from Resource.is_available (spec section 13).
    """
    stmt = select(Resource).where(Resource.is_available.is_(True))
    return list(db.execute(stmt).scalars().all())


def _skill_overlap_score(requirement_skill_text: str | None, resource_skills: list[ResourceSkill]) -> float:
    if not requirement_skill_text or not resource_skills:
        return 0.0
    required_tokens = {t.strip() for t in _normalize(requirement_skill_text).replace("/", ",").split(",") if t.strip()}
    resource_tokens = {_normalize(s.skill) for s in resource_skills}
    if not required_tokens:
        return 0.0
    overlap = required_tokens & resource_tokens
    return len(overlap) / len(required_tokens)


def score_resource(requirement: Requirement, resource: Resource) -> tuple[float, dict]:
    skill_score = _skill_overlap_score(requirement.skill, resource.skills)
    location_score = 1.0 if _normalize(requirement.location) == _normalize(resource.location) else 0.0
    portfolio_score = 1.0 if _normalize(requirement.account_portfolio) == _normalize(resource.portfolio) else 0.0
    availability_score = 1.0 if resource.is_available else 0.0

    total = (
        skill_score * SKILL_WEIGHT
        + location_score * LOCATION_WEIGHT
        + portfolio_score * PORTFOLIO_WEIGHT
        + availability_score * AVAILABILITY_WEIGHT
    )
    reasons = {
        "skill_score": round(skill_score, 3),
        "location_score": location_score,
        "portfolio_score": portfolio_score,
        "availability_score": availability_score,
    }
    return total, reasons


def rank_resource_matches(db: Session, requirement: Requirement, *, top_n: int = 10) -> list[dict]:
    """Filter then rank. Returns a list of {resource, score, reasons} sorted best-first.
    Caller is responsible for persisting as ResourceMatch rows -- this function is pure logic.
    """
    candidates = filter_candidate_resources(db, requirement)
    scored = [
        {"resource": resource, "score": score, "reasons": reasons}
        for resource in candidates
        for score, reasons in [score_resource(requirement, resource)]
        if score > 0
    ]
    scored.sort(key=lambda item: item["score"], reverse=True)
    return scored[:top_n]
