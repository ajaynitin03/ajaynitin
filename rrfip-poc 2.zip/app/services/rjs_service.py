"""RJS (Requisition Job Identifier) generation and resolution.

Hard rules enforced here (spec section 2):
  - RJS is the canonical business identifier; UNIQUE in PostgreSQL.
  - The LLM never generates, modifies, or chooses the RJS.
  - If source data already carries an authoritative id, we validate/preserve/map it as the RJS.
  - Otherwise we generate one deterministically -- via a PostgreSQL SEQUENCE, never MAX(id)+1,
    so concurrent creation is safe (the sequence itself is atomic; no read-then-write window
    to race in).
  - Uniqueness is additionally enforced by the DB constraint on requirements.rjs; a duplicate-key
    error here means someone else won the race, and the caller should re-resolve, not retry blindly.

PostgreSQL is the only supported production dialect (see docs/setup.md), and
`_generate_rjs_postgresql` is the only code path production ever takes -- it compiles to a
plain `SELECT nextval('rjs_number_seq')`, which is atomic at the database level regardless of
how many worker processes call it concurrently.

SQLite cannot execute `CREATE SEQUENCE` / `nextval` at all, so unit tests that use a SQLite
fixture (app/tests/conftest.py) need a substitute sequence to exercise this exact function
end-to-end rather than mocking it away. `_generate_rjs_sqlite_fallback` exists ONLY for that:
it is dialect-gated in `generate_rjs` below and is unreachable when db.bind.dialect.name is
"postgresql". It intentionally does NOT use MAX(id)+1 either -- it uses SQLite's own
AUTOINCREMENT-backed counter table, which is atomic under SQLite's single-writer transaction
model, so the "never MAX(id)+1" rule holds in both branches, not just production.
"""
from sqlalchemy import Sequence, select, text
from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.models.requirement import Requirement

settings = get_settings()

# Dedicated PostgreSQL sequence for RJS generation. Created via Alembic migration (see
# alembic/versions/0001_initial_schema.py), not application code, so it participates
# properly in schema management and survives independently of any table.
rjs_sequence = Sequence("rjs_number_seq", start=1, increment=1)

_SQLITE_COUNTER_TABLE_DDL = """
CREATE TABLE IF NOT EXISTS rjs_number_seq_sqlite (
    id INTEGER PRIMARY KEY AUTOINCREMENT
)
"""


def _generate_rjs_postgresql(db: Session) -> str:
    """The only code path production ever takes. `nextval()` is atomic in PostgreSQL --
    concurrent callers each get a distinct, strictly increasing number with no read-modify-
    write race, which is what makes this safe under concurrent requirement creation.
    """
    next_number = db.execute(rjs_sequence.next_value().select()).scalar_one()
    return f"{settings.rjs_prefix}-{next_number:06d}"


def _generate_rjs_sqlite_fallback(db: Session) -> str:
    """TEST-ONLY. Never executed against PostgreSQL -- see module docstring. Uses SQLite's
    own AUTOINCREMENT counter (a real atomic counter under SQLite's transaction model) as a
    substitute sequence, so this is still not MAX(id)+1 even in the test-only branch.
    """
    db.execute(text(_SQLITE_COUNTER_TABLE_DDL))
    db.execute(text("INSERT INTO rjs_number_seq_sqlite DEFAULT VALUES"))
    next_number = db.execute(text("SELECT last_insert_rowid()")).scalar_one()
    return f"{settings.rjs_prefix}-{next_number:06d}"


def generate_rjs(db: Session) -> str:
    """Generate a new, deterministic, collision-free RJS.

    NEVER derive this from MAX(id)+1 or from any LLM output, in either the PostgreSQL or
    SQLite-fallback branch.
    """
    dialect_name = db.bind.dialect.name if db.bind is not None else "postgresql"
    if dialect_name == "sqlite":
        return _generate_rjs_sqlite_fallback(db)
    return _generate_rjs_postgresql(db)


def resolve_rjs(db: Session, authoritative_id: str | None) -> str:
    """Decide the RJS for a new requirement.

    If the source system already provided an authoritative requirement/request id, that value
    is validated and preserved as the RJS (never rewritten). Otherwise a new one is generated.
    """
    if authoritative_id:
        candidate = authoritative_id.strip()
        if candidate:
            return candidate
    return generate_rjs(db)


def find_requirement_by_rjs(db: Session, rjs: str) -> Requirement | None:
    return db.execute(select(Requirement).where(Requirement.rjs == rjs)).scalar_one_or_none()
