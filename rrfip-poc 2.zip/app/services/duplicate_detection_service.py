"""Duplicate detection (spec section 25): hybrid deterministic checks first, fuzzy matching
second. Never relies on AI alone, and never auto-merges ambiguous results -- those go to
human review via the caller.

Two entry points share one implementation (spec: consolidate duplicated logic):
  - detect_duplicate(db, requirement) -- checks an already-persisted Requirement row against
    the rest of the table. Used for Excel-sourced requirements and ad hoc rechecks.
  - detect_duplicate_for_fields(db, ...) -- checks a set of extracted fields BEFORE any row
    exists. Used by the LangGraph pipeline (app/ai/graph.py) so duplicate detection can run
    before RJS resolution, per spec section 16's node ordering.
"""
from dataclasses import dataclass
from difflib import SequenceMatcher

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.enums import DuplicateVerdict
from app.models.requirement import Requirement

EXACT_MATCH_FIELDS = ("account_portfolio", "location", "skill", "role")
FUZZY_SIMILARITY_THRESHOLD_DUPLICATE = 0.92
FUZZY_SIMILARITY_THRESHOLD_PROBABLE = 0.75


@dataclass
class ComparableFields:
    """The subset of a requirement's fields duplicate detection compares. Lets the same
    scoring logic run against either a persisted Requirement or fields extracted by the AI
    agent before a row exists.
    """
    account_portfolio: str | None = None
    location: str | None = None
    skill: str | None = None
    role: str | None = None

    @classmethod
    def from_requirement(cls, requirement: Requirement) -> "ComparableFields":
        return cls(
            account_portfolio=requirement.account_portfolio,
            location=requirement.location,
            skill=requirement.skill,
            role=requirement.role,
        )


def _normalize(value: str | None) -> str:
    return (value or "").strip().lower()


def _fields_similarity(a: ComparableFields, b: ComparableFields) -> float:
    scores = []
    for field in EXACT_MATCH_FIELDS:
        va, vb = _normalize(getattr(a, field)), _normalize(getattr(b, field))
        if not va and not vb:
            continue
        scores.append(SequenceMatcher(None, va, vb).ratio())
    return sum(scores) / len(scores) if scores else 0.0


def _find_candidates(
    db: Session, fields: ComparableFields, *, exclude_id=None, limit: int = 20
) -> list[Requirement]:
    """Narrow the search space deterministically (same portfolio + location) before fuzzy scoring."""
    stmt = select(Requirement)
    if exclude_id is not None:
        stmt = stmt.where(Requirement.id != exclude_id)
    if fields.account_portfolio:
        stmt = stmt.where(Requirement.account_portfolio == fields.account_portfolio)
    if fields.location:
        stmt = stmt.where(Requirement.location == fields.location)
    return list(db.execute(stmt.limit(limit)).scalars().all())


def _score_against_candidates(
    fields: ComparableFields, candidates: list[Requirement]
) -> tuple[DuplicateVerdict, Requirement | None, float]:
    if not candidates:
        return DuplicateVerdict.NOT_DUPLICATE, None, 0.0

    best_match, best_score = None, 0.0
    for candidate in candidates:
        score = _fields_similarity(fields, ComparableFields.from_requirement(candidate))
        if score > best_score:
            best_match, best_score = candidate, score

    if best_score >= FUZZY_SIMILARITY_THRESHOLD_DUPLICATE:
        return DuplicateVerdict.DUPLICATE, best_match, best_score
    if best_score >= FUZZY_SIMILARITY_THRESHOLD_PROBABLE:
        return DuplicateVerdict.NEEDS_REVIEW, best_match, best_score
    if best_score > 0.4:
        return DuplicateVerdict.PROBABLE_DUPLICATE, best_match, best_score
    return DuplicateVerdict.NOT_DUPLICATE, None, best_score


def find_candidate_duplicates(db: Session, requirement: Requirement, *, limit: int = 20) -> list[Requirement]:
    """Kept for backward compatibility with existing callers/tests."""
    return _find_candidates(db, ComparableFields.from_requirement(requirement), exclude_id=requirement.id, limit=limit)


def detect_duplicate(db: Session, requirement: Requirement) -> tuple[DuplicateVerdict, Requirement | None, float]:
    """Check an already-persisted requirement against the rest of the table."""
    fields = ComparableFields.from_requirement(requirement)
    candidates = _find_candidates(db, fields, exclude_id=requirement.id)
    return _score_against_candidates(fields, candidates)


def detect_duplicate_for_fields(
    db: Session,
    *,
    account_portfolio: str | None,
    location: str | None,
    skill: str | None,
    role: str | None = None,
) -> tuple[DuplicateVerdict, Requirement | None, float]:
    """Check extracted fields against existing requirements BEFORE a row is created. This is
    what app/ai/graph.py calls, since RJS resolution (which needs the duplicate verdict to
    decide whether to reuse an existing RJS) happens after duplicate detection in the
    pipeline, not before.
    """
    fields = ComparableFields(account_portfolio=account_portfolio, location=location, skill=skill, role=role)
    candidates = _find_candidates(db, fields, exclude_id=None)
    return _score_against_candidates(fields, candidates)
