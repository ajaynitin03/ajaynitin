"""Login endpoints.

POST /auth/login   -- production path, exchanges a validated Entra ID token for our app JWT.
POST /auth/dev-token -- local-dev-only shortcut, hard-gated to ENVIRONMENT=development.
"""
import jwt
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.core.enums import UserRole
from app.db.session import get_db
from app.services.auth_service import get_or_create_user, issue_app_jwt, issue_dev_token, validate_entra_id_token

router = APIRouter(prefix="/auth", tags=["auth"])
settings = get_settings()


class EntraLoginRequest(BaseModel):
    entra_id_token: str


class DevTokenRequest(BaseModel):
    email: str
    roles: list[UserRole] = [UserRole.REQUIREMENT_TEAM]


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"


@router.post("/login", response_model=TokenResponse)
def login(payload: EntraLoginRequest, db: Session = Depends(get_db)):
    try:
        claims = validate_entra_id_token(payload.entra_id_token)
    except jwt.InvalidTokenError as exc:
        raise HTTPException(status_code=401, detail=f"Invalid Entra ID token: {exc}") from exc

    email = claims.get("preferred_username") or claims.get("email")
    if not email:
        raise HTTPException(status_code=401, detail="Entra ID token missing email/preferred_username claim")

    user = get_or_create_user(
        db,
        email=email,
        display_name=claims.get("name", email),
        entra_object_id=claims["oid"],
    )
    return TokenResponse(access_token=issue_app_jwt(user))


@router.post("/dev-token", response_model=TokenResponse)
def dev_token(payload: DevTokenRequest, db: Session = Depends(get_db)):
    if settings.environment != "development":
        raise HTTPException(status_code=404, detail="Not found")  # hide entirely outside dev
    return TokenResponse(access_token=issue_dev_token(db, email=payload.email, roles=payload.roles))
