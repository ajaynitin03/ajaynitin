from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from app.core.enums import FulfillmentStatus, SourceType, UserRole
from app.db.session import get_db
from app.repositories.requirement_repository import get_by_rjs, list_requirements
from app.schemas.requirement import RequirementCreateRequest, RequirementOut, RequirementUpdateRequest, StatusChangeRequest
from app.services.audit_service import record_audit
from app.services.fulfillment_service import (
    ForbiddenTransitionError,
    InvalidTransitionError,
    get_or_create_fulfillment_record,
    transition_status,
)
from app.services.requirement_service import NormalizedRequirementInput, ingest_requirement
from app.api.deps import CurrentUser, get_current_user

router = APIRouter(prefix="/requirements", tags=["requirements"])


@router.get("", response_model=list[RequirementOut])
def list_requirements_endpoint(
    status: str | None = Query(default=None),
    skill: str | None = Query(default=None),
    location: str | None = Query(default=None),
    limit: int = Query(default=50, le=200),
    offset: int = Query(default=0, ge=0),
    db: Session = Depends(get_db),
    _user: CurrentUser = Depends(get_current_user),
) -> list[RequirementOut]:
    rows = list_requirements(db, status=status, skill=skill, location=location, limit=limit, offset=offset)
    return [RequirementOut.model_validate(r) for r in rows]


@router.post("", response_model=RequirementOut, status_code=201)
def create_requirement_endpoint(
    payload: RequirementCreateRequest,
    db: Session = Depends(get_db),
    user: CurrentUser = Depends(get_current_user),
) -> RequirementOut:
    data = NormalizedRequirementInput(
        source_type=SourceType.MANUAL,
        source_identifier=f"manual:{user.email}:{payload.authoritative_id or 'new'}:{id(payload)}",
        authoritative_id=payload.authoritative_id,
        account_portfolio=payload.account_portfolio,
        country=payload.country,
        location=payload.location,
        skill_category=payload.skill_category,
        skill=payload.skill,
        role=payload.role,
        billing_type=payload.billing_type,
        ce_mandatory=payload.ce_mandatory,
        requirement_type=payload.requirement_type,
        quantity=payload.quantity,
        portfolio_team=payload.portfolio_team,
        remarks=payload.remarks,
    )
    requirement = ingest_requirement(db, data, actor=user.email)
    return RequirementOut.model_validate(requirement)


@router.get("/{rjs}", response_model=RequirementOut)
def get_requirement_endpoint(
    rjs: str, db: Session = Depends(get_db), _user: CurrentUser = Depends(get_current_user)
) -> RequirementOut:
    requirement = get_by_rjs(db, rjs)
    if requirement is None:
        raise HTTPException(status_code=404, detail=f"No requirement found for RJS '{rjs}'")
    return RequirementOut.model_validate(requirement)


@router.patch("/{rjs}", response_model=RequirementOut)
def update_requirement_endpoint(
    rjs: str,
    payload: RequirementUpdateRequest,
    db: Session = Depends(get_db),
    user: CurrentUser = Depends(get_current_user),
) -> RequirementOut:
    requirement = get_by_rjs(db, rjs)
    if requirement is None:
        raise HTTPException(status_code=404, detail=f"No requirement found for RJS '{rjs}'")

    updates = payload.model_dump(exclude_unset=True)
    for field, new_value in updates.items():
        old_value = getattr(requirement, field)
        if old_value != new_value:
            record_audit(
                db,
                action="requirement_updated",
                entity="requirement",
                entity_id=str(requirement.id),
                rjs=requirement.rjs,
                actor=user.email,
                field=field,
                old_value=str(old_value) if old_value is not None else None,
                new_value=str(new_value) if new_value is not None else None,
                source="api",
            )
            setattr(requirement, field, new_value)

    db.commit()
    db.refresh(requirement)
    return RequirementOut.model_validate(requirement)


@router.post("/{rjs}/status")
def change_status_endpoint(
    rjs: str,
    payload: StatusChangeRequest,
    db: Session = Depends(get_db),
    user: CurrentUser = Depends(get_current_user),
):
    requirement = get_by_rjs(db, rjs)
    if requirement is None:
        raise HTTPException(status_code=404, detail=f"No requirement found for RJS '{rjs}'")

    try:
        to_status = FulfillmentStatus(payload.status)
    except ValueError:
        raise HTTPException(status_code=422, detail=f"Invalid status '{payload.status}'")

    record = get_or_create_fulfillment_record(db, requirement)
    try:
        transition_status(
            db,
            record,
            to_status,
            actor=user.email,
            actor_roles=user.roles,
            reason=payload.reason,
            rjs=requirement.rjs,
        )
    except ForbiddenTransitionError as exc:
        raise HTTPException(status_code=403, detail=str(exc))
    except InvalidTransitionError as exc:
        raise HTTPException(status_code=422, detail=str(exc))

    db.commit()
    return {"rjs": requirement.rjs, "status": record.status}


@router.post("/{rjs}/recheck-duplicates")
def recheck_duplicates_endpoint(
    rjs: str, db: Session = Depends(get_db), user: CurrentUser = Depends(get_current_user)
):
    """Enqueue an on-demand duplicate-detection re-run against the current requirement table
    state (e.g. after several new requirements have come in since this one was created).
    """
    requirement = get_by_rjs(db, rjs)
    if requirement is None:
        raise HTTPException(status_code=404, detail=f"No requirement found for RJS '{rjs}'")

    from app.core.enums import JobType
    from app.models.job import Job

    job = Job(
        type=JobType.RUN_DUPLICATE_DETECTION,
        payload={"requirement_id": str(requirement.id)},
        correlation_id=f"recheck-dup-{requirement.rjs}",
    )
    db.add(job)
    db.commit()
    return {"job_id": str(job.id), "rjs": requirement.rjs}


@router.post("/{rjs}/rematch")
def rematch_endpoint(rjs: str, db: Session = Depends(get_db), user: CurrentUser = Depends(get_current_user)):
    """Enqueue an on-demand resource-matching re-run (e.g. after new resources were synced
    from the Resource Tracker). Existing ResourceMatch rows for this requirement are left in
    place -- the new run adds fresh ranked rows rather than deleting history.
    """
    requirement = get_by_rjs(db, rjs)
    if requirement is None:
        raise HTTPException(status_code=404, detail=f"No requirement found for RJS '{rjs}'")

    from app.core.enums import JobType
    from app.models.job import Job

    job = Job(
        type=JobType.RUN_RESOURCE_MATCHING,
        payload={"requirement_id": str(requirement.id)},
        correlation_id=f"rematch-{requirement.rjs}",
    )
    db.add(job)
    db.commit()
    return {"job_id": str(job.id), "rjs": requirement.rjs}
