"""Graph webhook endpoints. These are public (Graph calls them directly) but validated via
the clientState/validationToken handshake Graph requires, and they do nothing beyond a fast
DB write + job enqueue (spec section 18 -- no LLM work inline).

clientState verification: every subscription this app creates (app/integrations/graph/client.py)
is stamped with settings.graph_webhook_client_state -- the SAME setting is read here, so
there is exactly one source of truth for that value, not one hardcoded literal at creation
time and a second hardcoded literal at validation time.
"""
from fastapi import APIRouter, Query, Request, Response
from sqlalchemy.orm import Session
from fastapi import Depends

from app.core.config import get_settings
from app.core.enums import SourceType
from app.db.session import get_db
from app.services.webhook_ingestion_service import ingest_webhook_notification

router = APIRouter(prefix="/graph", tags=["graph"])


async def _handle_notification(request: Request, db: Session, source_type: SourceType, validation_token: str | None):
    # Graph subscription validation handshake: echo the token back as plain text.
    if validation_token is not None:
        return Response(content=validation_token, media_type="text/plain")

    expected_client_state = get_settings().graph_webhook_client_state
    body = await request.json()
    for notification in body.get("value", []):
        if notification.get("clientState") != expected_client_state:
            continue  # reject notifications that don't carry our subscription's clientState
        resource_data = notification.get("resourceData", {})
        identifier = resource_data.get("id") or notification.get("subscriptionId")
        if identifier:
            ingest_webhook_notification(
                db, source_type=source_type, source_identifier=str(identifier), raw_payload=notification
            )
    return Response(status_code=202)


@router.post("/webhook/outlook")
async def outlook_webhook(
    request: Request,
    validationToken: str | None = Query(default=None),
    db: Session = Depends(get_db),
):
    return await _handle_notification(request, db, SourceType.OUTLOOK, validationToken)


@router.post("/webhook/teams")
async def teams_webhook(
    request: Request,
    validationToken: str | None = Query(default=None),
    db: Session = Depends(get_db),
):
    return await _handle_notification(request, db, SourceType.TEAMS, validationToken)
