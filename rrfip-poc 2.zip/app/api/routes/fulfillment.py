from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.models.audit import AuditLog
from app.models.fulfillment import FulfillmentRecord
from app.repositories.requirement_repository import get_by_rjs
from app.schemas.fulfillment import AuditLogOut, FulfillmentOut
from app.api.deps import CurrentUser, get_current_user

router = APIRouter(tags=["fulfillment"])


@router.get("/fulfillment", response_model=list[FulfillmentOut])
def list_fulfillment(
    status: str | None = Query(default=None),
    limit: int = Query(default=50, le=200),
    offset: int = Query(default=0, ge=0),
    db: Session = Depends(get_db),
    _user: CurrentUser = Depends(get_current_user),
):
    stmt = select(FulfillmentRecord)
    if status:
        stmt = stmt.where(FulfillmentRecord.status == status)
    stmt = stmt.order_by(FulfillmentRecord.updated_at.desc()).limit(limit).offset(offset)
    rows = db.execute(stmt).scalars().all()
    return [FulfillmentOut.model_validate(r) for r in rows]


@router.get("/fulfillment/{rjs}", response_model=FulfillmentOut)
def get_fulfillment(rjs: str, db: Session = Depends(get_db), _user: CurrentUser = Depends(get_current_user)):
    requirement = get_by_rjs(db, rjs)
    if requirement is None:
        raise HTTPException(status_code=404, detail=f"No requirement found for RJS '{rjs}'")
    record = db.execute(
        select(FulfillmentRecord).where(FulfillmentRecord.requirement_id == requirement.id)
    ).scalar_one_or_none()
    if record is None:
        raise HTTPException(status_code=404, detail="No fulfillment record for this requirement")
    return FulfillmentOut.model_validate(record)


@router.get("/audit/{rjs}", response_model=list[AuditLogOut])
def get_audit_trail(rjs: str, db: Session = Depends(get_db), _user: CurrentUser = Depends(get_current_user)):
    rows = db.execute(
        select(AuditLog).where(AuditLog.rjs == rjs).order_by(AuditLog.created_at)
    ).scalars().all()
    return [AuditLogOut.model_validate(r) for r in rows]
