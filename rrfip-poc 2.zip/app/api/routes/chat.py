from fastapi import APIRouter, Depends
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.ai.chat_query import answer_chat_query
from app.api.deps import CurrentUser, get_current_user
from app.db.session import get_db

router = APIRouter(tags=["chat"])


class ChatQueryRequest(BaseModel):
    question: str


@router.post("/chat/query")
def chat_query(
    payload: ChatQueryRequest, db: Session = Depends(get_db), _user: CurrentUser = Depends(get_current_user)
):
    return answer_chat_query(db, payload.question)
