from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.api.deps import CurrentUser, get_current_user
from app.core.enums import FulfillmentStatus, ReviewStatus, UserRole
from app.db.session import get_db
from app.models.ai import HumanReview, ResourceMatch
from app.models.fulfillment import FulfillmentRecord
from app.models.requirement import Requirement
from app.models.resource import Resource
from app.services.audit_service import record_audit

router = APIRouter(tags=["resources-reviews-analytics"])


@router.get("/resources")
def list_resources(
    location: str | None = None,
    portfolio: str | None = None,
    available_only: bool = False,
    db: Session = Depends(get_db),
    _user: CurrentUser = Depends(get_current_user),
):
    stmt = select(Resource)
    if location:
        stmt = stmt.where(Resource.location == location)
    if portfolio:
        stmt = stmt.where(Resource.portfolio == portfolio)
    if available_only:
        stmt = stmt.where(Resource.is_available.is_(True))
    rows = db.execute(stmt.limit(200)).scalars().all()
    return [
        {"id": str(r.id), "employee_id": r.employee_id, "location": r.location, "portfolio": r.portfolio,
         "grade": r.grade, "is_available": r.is_available, "detailed_status": r.detailed_status}
        for r in rows
    ]


@router.get("/resources/{resource_id}")
def get_resource(resource_id: str, db: Session = Depends(get_db), _user: CurrentUser = Depends(get_current_user)):
    resource = db.get(Resource, resource_id)
    if resource is None:
        raise HTTPException(status_code=404, detail="Resource not found")
    return {
        "id": str(resource.id), "employee_id": resource.employee_id, "name": resource.name,
        "location": resource.location, "portfolio": resource.portfolio, "grade": resource.grade,
        "is_available": resource.is_available, "skills": [s.skill for s in resource.skills],
    }


@router.get("/requirements/{rjs}/matches")
def get_requirement_matches(rjs: str, db: Session = Depends(get_db), _user: CurrentUser = Depends(get_current_user)):
    requirement = db.execute(select(Requirement).where(Requirement.rjs == rjs)).scalar_one_or_none()
    if requirement is None:
        raise HTTPException(status_code=404, detail=f"No requirement found for RJS '{rjs}'")
    matches = db.execute(
        select(ResourceMatch).where(ResourceMatch.requirement_id == requirement.id).order_by(ResourceMatch.rank)
    ).scalars().all()
    return [{"resource_id": str(m.resource_id), "score": float(m.score), "rank": m.rank, "reasons": m.reasons} for m in matches]


@router.get("/reviews")
def list_reviews(status: str = "PENDING", db: Session = Depends(get_db), _user: CurrentUser = Depends(get_current_user)):
    stmt = select(HumanReview).where(HumanReview.status == status).order_by(HumanReview.created_at)
    rows = db.execute(stmt).scalars().all()
    return [
        {"id": str(r.id), "reason": r.reason, "status": r.status, "duplicate_verdict": r.duplicate_verdict,
         "context": r.context, "requirement_id": str(r.requirement_id) if r.requirement_id else None}
        for r in rows
    ]


@router.post("/reviews/{review_id}/approve")
def approve_review(
    review_id: str, db: Session = Depends(get_db), user: CurrentUser = Depends(get_current_user)
):
    user.require_role(UserRole.DELIVERY_MANAGER, UserRole.ADMIN, UserRole.REQUIREMENT_TEAM)
    review = db.get(HumanReview, review_id)
    if review is None:
        raise HTTPException(status_code=404, detail="Review not found")
    review.status = ReviewStatus.APPROVED
    review.decided_by = user.email
    record_audit(db, action="review_approved", entity="human_review", entity_id=review_id, actor=user.email)
    db.commit()
    return {"id": review_id, "status": review.status}


@router.post("/reviews/{review_id}/reject")
def reject_review(
    review_id: str, db: Session = Depends(get_db), user: CurrentUser = Depends(get_current_user)
):
    user.require_role(UserRole.DELIVERY_MANAGER, UserRole.ADMIN, UserRole.REQUIREMENT_TEAM)
    review = db.get(HumanReview, review_id)
    if review is None:
        raise HTTPException(status_code=404, detail="Review not found")
    review.status = ReviewStatus.REJECTED
    review.decided_by = user.email
    record_audit(db, action="review_rejected", entity="human_review", entity_id=review_id, actor=user.email)
    db.commit()
    return {"id": review_id, "status": review.status}


@router.get("/analytics/summary")
def analytics_summary(db: Session = Depends(get_db), _user: CurrentUser = Depends(get_current_user)):
    rows = db.execute(
        select(FulfillmentRecord.status, func.count()).group_by(FulfillmentRecord.status)
    ).all()
    counts = {status: count for status, count in rows}
    total = sum(counts.values())
    closed = counts.get(FulfillmentStatus.CLOSED, 0)
    return {
        "total": total,
        "open": counts.get(FulfillmentStatus.OPEN, 0),
        "identified": counts.get(FulfillmentStatus.IDENTIFIED, 0),
        "hold": counts.get(FulfillmentStatus.HOLD, 0),
        "closed": closed,
        "closure_pct": round(closed / total * 100, 1) if total else 0.0,
    }


@router.get("/analytics/status")
def analytics_status(db: Session = Depends(get_db), _user: CurrentUser = Depends(get_current_user)):
    rows = db.execute(
        select(FulfillmentRecord.status, func.count()).group_by(FulfillmentRecord.status)
    ).all()
    return {status: count for status, count in rows}


@router.get("/analytics/skills")
def analytics_skills(db: Session = Depends(get_db), _user: CurrentUser = Depends(get_current_user)):
    rows = db.execute(
        select(Requirement.skill, func.count()).group_by(Requirement.skill).order_by(func.count().desc()).limit(20)
    ).all()
    return [{"skill": skill, "demand": count} for skill, count in rows if skill]


@router.get("/analytics/aging")
def analytics_aging(db: Session = Depends(get_db), _user: CurrentUser = Depends(get_current_user)):
    rows = db.execute(
        select(Requirement.rjs, Requirement.created_at)
        .join(FulfillmentRecord)
        .where(FulfillmentRecord.status != FulfillmentStatus.CLOSED)
        .order_by(Requirement.created_at)
        .limit(100)
    ).all()
    return [{"rjs": rjs, "opened_at": created_at} for rjs, created_at in rows]
