"""Admin-triggered Graph subscription management. Creating a subscription is an operational
action (it registers a webhook against a specific mailbox/channel and starts a billable-ish
Graph resource), so it's explicit and role-gated -- never auto-created on app startup.
"""
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.api.deps import CurrentUser, get_current_user
from app.core.enums import UserRole
from app.db.session import get_db
from app.integrations.graph.client import GraphClient
from app.models.graph_subscription import GraphSubscription
from app.services.graph_subscription_service import (
    create_and_track_outlook_subscription,
    create_and_track_teams_subscription,
)

router = APIRouter(prefix="/graph/subscriptions", tags=["graph"])


class OutlookSubscriptionRequest(BaseModel):
    mailbox_id: str
    notification_url: str


class TeamsSubscriptionRequest(BaseModel):
    team_id: str
    channel_id: str
    notification_url: str


@router.get("")
def list_subscriptions(db: Session = Depends(get_db), _user: CurrentUser = Depends(get_current_user)):
    rows = db.execute(select(GraphSubscription)).scalars().all()
    return [
        {
            "id": str(r.id), "subscription_id": r.subscription_id, "resource_type": r.resource_type,
            "resource": r.resource, "expires_at": r.expires_at, "last_renewed_at": r.last_renewed_at,
            "is_active": r.is_active,
        }
        for r in rows
    ]


@router.post("/outlook")
def create_outlook_subscription(
    payload: OutlookSubscriptionRequest, db: Session = Depends(get_db), user: CurrentUser = Depends(get_current_user)
):
    user.require_role(UserRole.ADMIN)
    try:
        record = create_and_track_outlook_subscription(
            db, GraphClient(), mailbox_id=payload.mailbox_id, notification_url=payload.notification_url
        )
    except Exception as exc:  # noqa: BLE001 - surface Graph/config errors as a clean 502, not a 500 traceback
        raise HTTPException(status_code=502, detail=f"Failed to create Outlook subscription: {exc}") from exc
    return {"id": str(record.id), "subscription_id": record.subscription_id, "expires_at": record.expires_at}


@router.post("/teams")
def create_teams_subscription(
    payload: TeamsSubscriptionRequest, db: Session = Depends(get_db), user: CurrentUser = Depends(get_current_user)
):
    user.require_role(UserRole.ADMIN)
    try:
        record = create_and_track_teams_subscription(
            db, GraphClient(), team_id=payload.team_id, channel_id=payload.channel_id,
            notification_url=payload.notification_url,
        )
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(status_code=502, detail=f"Failed to create Teams subscription: {exc}") from exc
    return {"id": str(record.id), "subscription_id": record.subscription_id, "expires_at": record.expires_at}
