from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.api.deps import CurrentUser, get_current_user
from app.core.enums import JobType, UserRole
from app.db.session import get_db
from app.models.ingestion import ExcelSyncState
from app.models.job import Job

router = APIRouter(tags=["sync"])

TRIGGERABLE_WORKBOOKS = {
    "requirement": JobType.REQUIREMENT_EXCEL_SYNC,
    "resource": JobType.RESOURCE_EXCEL_SYNC,
}


@router.get("/sync/status")
def sync_status(db: Session = Depends(get_db), _user: CurrentUser = Depends(get_current_user)):
    rows = db.execute(select(ExcelSyncState)).scalars().all()
    return [
        {
            "workbook_name": r.workbook_name,
            "item_id": r.item_id,
            "last_modified_by": r.last_modified_by,
            "last_modified_at": r.last_modified_at,
            "last_synced_at": r.last_synced_at,
            "sync_status": r.sync_status,
        }
        for r in rows
    ]


@router.post("/sync/trigger/{workbook}")
def trigger_sync(
    workbook: str, db: Session = Depends(get_db), user: CurrentUser = Depends(get_current_user)
):
    """Enqueue an on-demand sync job for 'requirement' or 'resource'. Admin/Requirement Team
    only -- this is an operational action, not a read.
    """
    user.require_role(UserRole.ADMIN, UserRole.REQUIREMENT_TEAM)
    job_type = TRIGGERABLE_WORKBOOKS.get(workbook)
    if job_type is None:
        raise HTTPException(status_code=404, detail=f"Unknown workbook '{workbook}'. Use 'requirement' or 'resource'.")

    job = Job(type=job_type, payload={}, correlation_id=f"manual-trigger-{workbook}")
    db.add(job)
    db.commit()
    return {"job_id": str(job.id), "type": job_type.value, "status": job.status}
