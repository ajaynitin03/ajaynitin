"""Auth dependency. Validates a bearer JWT (issued after Entra ID / MSAL login exchange) and
loads the user's roles for server-side authorization (spec section 32: enforced in backend,
never trusted from the client).
"""
from dataclasses import dataclass

import jwt
from fastapi import Depends, HTTPException
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.core.enums import UserRole
from app.db.session import get_db

settings = get_settings()
bearer_scheme = HTTPBearer(auto_error=True)


@dataclass
class CurrentUser:
    email: str
    roles: set[UserRole]

    def require_role(self, *allowed: UserRole) -> None:
        if not self.roles & set(allowed):
            raise HTTPException(status_code=403, detail="Insufficient role for this action.")


def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(bearer_scheme),
    db: Session = Depends(get_db),
) -> CurrentUser:
    try:
        claims = jwt.decode(credentials.credentials, settings.jwt_secret_key, algorithms=[settings.jwt_algorithm])
    except jwt.InvalidTokenError as exc:
        raise HTTPException(status_code=401, detail="Invalid or expired token") from exc

    email = claims.get("email")
    if not email:
        raise HTTPException(status_code=401, detail="Token missing email claim")

    role_values = claims.get("roles", [])
    roles = {UserRole(r) for r in role_values if r in UserRole._value2member_map_}
    return CurrentUser(email=email, roles=roles)
