from app.integrations.mapping import map_resource_tracker_row
from app.services.resource_ingestion_service import ingest_resource


def test_new_resource_is_created_with_skills(db_session):
    row = {"Emp ID": "1001", "Name": "A. Kumar", "Skill": "Java, AWS", "Detailed Status": "drop(plan shared)"}
    mapped = map_resource_tracker_row(row)
    resource = ingest_resource(db_session, mapped)

    assert resource.employee_id == "1001"
    assert {s.skill for s in resource.skills} == {"Java", "AWS"}
    assert resource.is_available is True


def test_existing_resource_is_updated_not_duplicated(db_session):
    row_v1 = {"Emp ID": "1002", "Name": "B. Rao", "Skill": "Python", "Detailed Status": "drop(plan shared)"}
    ingest_resource(db_session, map_resource_tracker_row(row_v1))

    row_v2 = {"Emp ID": "1002", "Name": "B. Rao", "Skill": "Python, Django", "Detailed Status": "Allocated"}
    updated = ingest_resource(db_session, map_resource_tracker_row(row_v2))

    assert updated.is_available is False
    assert {s.skill for s in updated.skills} == {"Python", "Django"}

    from sqlalchemy import select
    from app.models.resource import Resource
    all_resources = db_session.execute(select(Resource).where(Resource.employee_id == "1002")).scalars().all()
    assert len(all_resources) == 1
