"""Tests for app/workers/runner.py.

SCOPE NOTE (same pattern as test_rjs_service.py): these exercise the REAL claim_next_job()
and process_job() functions, unmocked, against the SQLite fixture -- which routes through
_claim_next_job_sqlite_fallback (see runner.py's module docstring). This verifies the
claim/status-transition/retry state machine correctly, but does NOT verify true concurrent-
worker safety, which depends on PostgreSQL's FOR UPDATE SKIP LOCKED and is an EXTERNAL
BLOCKER without a live PostgreSQL connection (see docs/setup.md for how to point tests at one).
"""
from app.core.enums import JobStatus, JobType
from app.models.job import Job
from app.workers.runner import claim_next_job, process_job


def test_claim_next_job_returns_none_when_queue_empty(db_session):
    assert claim_next_job(db_session) is None


def test_claim_next_job_picks_up_pending_job(db_session):
    job = Job(type=JobType.NORMALIZE_SOURCE_EVENT, payload={})
    db_session.add(job)
    db_session.commit()

    claimed = claim_next_job(db_session)
    assert claimed is not None
    assert claimed.id == job.id
    assert claimed.status == JobStatus.RUNNING
    assert claimed.attempts == 1
    assert claimed.started_at is not None


def test_claim_next_job_respects_priority_order(db_session):
    low_priority = Job(type=JobType.NORMALIZE_SOURCE_EVENT, payload={}, priority=200)
    high_priority = Job(type=JobType.NORMALIZE_SOURCE_EVENT, payload={}, priority=10)
    db_session.add_all([low_priority, high_priority])
    db_session.commit()

    claimed = claim_next_job(db_session)
    assert claimed.id == high_priority.id  # lower number = higher priority, per Job model docstring


def test_claim_next_job_does_not_pick_up_completed_or_running_jobs(db_session):
    completed = Job(type=JobType.NORMALIZE_SOURCE_EVENT, payload={}, status=JobStatus.COMPLETED)
    running = Job(type=JobType.NORMALIZE_SOURCE_EVENT, payload={}, status=JobStatus.RUNNING)
    db_session.add_all([completed, running])
    db_session.commit()

    assert claim_next_job(db_session) is None


def test_claim_next_job_picks_up_retry_status_jobs(db_session):
    retry_job = Job(type=JobType.NORMALIZE_SOURCE_EVENT, payload={}, status=JobStatus.RETRY, attempts=2)
    db_session.add(retry_job)
    db_session.commit()

    claimed = claim_next_job(db_session)
    assert claimed is not None
    assert claimed.id == retry_job.id
    assert claimed.attempts == 3  # incremented on claim


def test_process_job_marks_completed_on_success(db_session):
    job = Job(type=JobType.RUN_DUPLICATE_DETECTION, payload={"requirement_id": "does-not-matter"})
    db_session.add(job)
    db_session.commit()
    claim_next_job(db_session)

    # Monkeypatch the specific handler this job type maps to, rather than faking the
    # claim/retry mechanics -- process_job's OWN logic is what's under test here.
    from app.workers import handlers as handlers_module

    original = handlers_module.JOB_HANDLERS[JobType.RUN_DUPLICATE_DETECTION]
    handlers_module.JOB_HANDLERS[JobType.RUN_DUPLICATE_DETECTION] = lambda db, payload: None
    try:
        process_job(db_session, job)
    finally:
        handlers_module.JOB_HANDLERS[JobType.RUN_DUPLICATE_DETECTION] = original

    assert job.status == JobStatus.COMPLETED
    assert job.completed_at is not None
    assert job.last_error is None


def test_process_job_retries_on_handler_exception_below_max_attempts(db_session):
    from app.workers import handlers as handlers_module

    job = Job(type=JobType.RUN_DUPLICATE_DETECTION, payload={}, max_attempts=5)
    db_session.add(job)
    db_session.commit()
    claim_next_job(db_session)  # attempts becomes 1

    def failing_handler(db, payload):
        raise ValueError("simulated transient failure")

    original = handlers_module.JOB_HANDLERS[JobType.RUN_DUPLICATE_DETECTION]
    handlers_module.JOB_HANDLERS[JobType.RUN_DUPLICATE_DETECTION] = failing_handler
    try:
        process_job(db_session, job)
    finally:
        handlers_module.JOB_HANDLERS[JobType.RUN_DUPLICATE_DETECTION] = original

    assert job.status == JobStatus.RETRY
    assert "simulated transient failure" in job.last_error


def test_process_job_marks_failed_when_max_attempts_exhausted(db_session):
    from app.workers import handlers as handlers_module

    job = Job(type=JobType.RUN_DUPLICATE_DETECTION, payload={}, max_attempts=1)
    db_session.add(job)
    db_session.commit()
    claim_next_job(db_session)  # attempts becomes 1, equal to max_attempts

    def failing_handler(db, payload):
        raise ValueError("permanent failure")

    original = handlers_module.JOB_HANDLERS[JobType.RUN_DUPLICATE_DETECTION]
    handlers_module.JOB_HANDLERS[JobType.RUN_DUPLICATE_DETECTION] = failing_handler
    try:
        process_job(db_session, job)
    finally:
        handlers_module.JOB_HANDLERS[JobType.RUN_DUPLICATE_DETECTION] = original

    assert job.status == JobStatus.FAILED


def test_process_job_fails_cleanly_for_unregistered_job_type(db_session):
    """An unknown job type must fail cleanly and be logged (audit spec section 22), not
    raise an unhandled exception that could crash the worker loop.
    """
    job = Job(type="SOME_FUTURE_JOB_TYPE_NOT_YET_REGISTERED", payload={})
    db_session.add(job)
    db_session.commit()
    claim_next_job(db_session)

    process_job(db_session, job)

    assert job.status == JobStatus.FAILED
    assert "No handler registered" in job.last_error


def test_process_job_rolls_back_partial_work_on_failure(db_session):
    """If a handler raises after making some DB changes, those changes must be rolled back
    -- process_job explicitly calls db.rollback() before recording the failure, so a failed
    job never leaves partial writes committed.
    """
    from sqlalchemy import select

    from app.models.audit import AuditLog
    from app.workers import handlers as handlers_module

    job = Job(type=JobType.RUN_DUPLICATE_DETECTION, payload={}, max_attempts=5)
    db_session.add(job)
    db_session.commit()
    claim_next_job(db_session)

    def partially_failing_handler(db, payload):
        db.add(AuditLog(action="should_be_rolled_back", entity="test", actor="test"))
        db.flush()
        raise ValueError("failure after partial write")

    original = handlers_module.JOB_HANDLERS[JobType.RUN_DUPLICATE_DETECTION]
    handlers_module.JOB_HANDLERS[JobType.RUN_DUPLICATE_DETECTION] = partially_failing_handler
    try:
        process_job(db_session, job)
    finally:
        handlers_module.JOB_HANDLERS[JobType.RUN_DUPLICATE_DETECTION] = original

    leftover = db_session.execute(
        select(AuditLog).where(AuditLog.action == "should_be_rolled_back")
    ).scalars().all()
    assert leftover == [], "Partial write from a failed handler was not rolled back"
