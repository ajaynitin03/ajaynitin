import pytest

from app.core.enums import FulfillmentStatus, UserRole
from app.models.requirement import Requirement
from app.services.fulfillment_service import (
    ForbiddenTransitionError,
    InvalidTransitionError,
    get_or_create_fulfillment_record,
    transition_status,
)


def _make_requirement(db_session, rjs: str) -> Requirement:
    req = Requirement(rjs=rjs, quantity=1)
    db_session.add(req)
    db_session.flush()
    return req


def test_open_to_identified_is_allowed(db_session, sample_rjs):
    req = _make_requirement(db_session, sample_rjs)
    record = get_or_create_fulfillment_record(db_session, req)
    assert record.status == FulfillmentStatus.OPEN

    transition_status(
        db_session, record, FulfillmentStatus.IDENTIFIED,
        actor="dm@example.com", actor_roles={UserRole.DELIVERY_MANAGER}, rjs=req.rjs,
    )
    assert record.status == FulfillmentStatus.IDENTIFIED
    assert record.events[-1].from_status == FulfillmentStatus.OPEN
    assert record.events[-1].to_status == FulfillmentStatus.IDENTIFIED


def test_open_to_closed_directly_is_rejected(db_session, sample_rjs):
    req = _make_requirement(db_session, sample_rjs)
    record = get_or_create_fulfillment_record(db_session, req)

    with pytest.raises(InvalidTransitionError):
        transition_status(
            db_session, record, FulfillmentStatus.CLOSED,
            actor="dm@example.com", actor_roles={UserRole.DELIVERY_MANAGER}, rjs=req.rjs,
        )


def test_normal_user_cannot_reopen_closed(db_session, sample_rjs):
    req = _make_requirement(db_session, sample_rjs)
    record = get_or_create_fulfillment_record(db_session, req)
    record.status = FulfillmentStatus.CLOSED

    with pytest.raises(ForbiddenTransitionError):
        transition_status(
            db_session, record, FulfillmentStatus.OPEN,
            actor="dp@example.com", actor_roles={UserRole.DELIVERY_PARTNER}, rjs=req.rjs,
        )


def test_admin_can_reopen_closed(db_session, sample_rjs):
    req = _make_requirement(db_session, sample_rjs)
    record = get_or_create_fulfillment_record(db_session, req)
    record.status = FulfillmentStatus.CLOSED

    transition_status(
        db_session, record, FulfillmentStatus.OPEN,
        actor="admin@example.com", actor_roles={UserRole.ADMIN}, rjs=req.rjs,
    )
    assert record.status == FulfillmentStatus.OPEN


def test_same_status_transition_is_a_noop(db_session, sample_rjs):
    req = _make_requirement(db_session, sample_rjs)
    record = get_or_create_fulfillment_record(db_session, req)
    events_before = len(record.events)

    transition_status(
        db_session, record, FulfillmentStatus.OPEN,
        actor="dm@example.com", actor_roles={UserRole.DELIVERY_MANAGER}, rjs=req.rjs,
    )
    assert len(record.events) == events_before
