"""Tests for app/services/webhook_ingestion_service.py -- the idempotency guarantee Graph
webhook redelivery depends on (spec section 13: 'avoid duplicate source event').
"""
from sqlalchemy import select

from app.core.enums import JobType, SourceType
from app.models.ingestion import SourceEvent
from app.models.job import Job
from app.services.webhook_ingestion_service import ingest_webhook_notification


def test_first_notification_creates_source_event_and_job(db_session):
    created = ingest_webhook_notification(
        db_session, source_type=SourceType.OUTLOOK, source_identifier="msg-1", raw_payload={"subject": "test"}
    )
    assert created is True

    events = db_session.execute(select(SourceEvent)).scalars().all()
    assert len(events) == 1
    assert events[0].source_identifier == "msg-1"

    jobs = db_session.execute(select(Job).where(Job.type == JobType.NORMALIZE_SOURCE_EVENT)).scalars().all()
    assert len(jobs) == 1
    assert jobs[0].correlation_id == "msg-1"


def test_redelivered_notification_is_a_safe_noop(db_session):
    """Graph is explicitly allowed to redeliver the same notification -- a second delivery
    of the identical (source_type, source_identifier) must not create a second SourceEvent
    or a second job.
    """
    first = ingest_webhook_notification(
        db_session, source_type=SourceType.OUTLOOK, source_identifier="msg-2", raw_payload={"subject": "v1"}
    )
    second = ingest_webhook_notification(
        db_session, source_type=SourceType.OUTLOOK, source_identifier="msg-2", raw_payload={"subject": "v1-redelivered"}
    )

    assert first is True
    assert second is False

    events = db_session.execute(
        select(SourceEvent).where(SourceEvent.source_identifier == "msg-2")
    ).scalars().all()
    assert len(events) == 1

    jobs = db_session.execute(
        select(Job).where(Job.correlation_id == "msg-2")
    ).scalars().all()
    assert len(jobs) == 1


def test_same_identifier_different_source_type_is_not_a_collision(db_session):
    """(source_type, source_identifier) is a COMPOSITE key -- the same identifier string
    from Outlook and Teams must not be treated as the same event.
    """
    outlook_result = ingest_webhook_notification(
        db_session, source_type=SourceType.OUTLOOK, source_identifier="shared-id-123", raw_payload={}
    )
    teams_result = ingest_webhook_notification(
        db_session, source_type=SourceType.TEAMS, source_identifier="shared-id-123", raw_payload={}
    )
    assert outlook_result is True
    assert teams_result is True

    events = db_session.execute(
        select(SourceEvent).where(SourceEvent.source_identifier == "shared-id-123")
    ).scalars().all()
    assert len(events) == 2


def test_teams_and_outlook_notifications_both_ingest_independently(db_session):
    ingest_webhook_notification(db_session, source_type=SourceType.TEAMS, source_identifier="t-1", raw_payload={})
    ingest_webhook_notification(db_session, source_type=SourceType.OUTLOOK, source_identifier="o-1", raw_payload={})

    all_events = db_session.execute(select(SourceEvent)).scalars().all()
    assert {e.source_identifier for e in all_events} == {"t-1", "o-1"}
