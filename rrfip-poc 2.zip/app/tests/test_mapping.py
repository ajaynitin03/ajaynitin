from app.integrations.mapping import map_requirement_tracker_row, map_resource_tracker_row


def test_requirement_mapping_prefers_requirement_id_over_request_id():
    row = {
        "Request Id": "5023843",
        "Requirement Id": "10660280",
        "Account/Portfolio": "Life IT",
        "Skill": "Java Full Stack",
        "Status": "Closed",
    }
    result = map_requirement_tracker_row(row, row_key="excel-row-1")
    assert result.authoritative_id == "10660280"
    assert result.account_portfolio == "Life IT"
    assert result.skill == "Java Full Stack"
    assert result.extra == {"Status": "Closed"}


def test_requirement_mapping_falls_back_to_request_id():
    row = {"Request Id": "5023843", "Account/Portfolio": "Banking"}
    result = map_requirement_tracker_row(row, row_key="excel-row-2")
    assert result.authoritative_id == "5023843"


def test_requirement_mapping_no_id_present():
    row = {"Account/Portfolio": "Banking"}
    result = map_requirement_tracker_row(row, row_key="excel-row-3")
    assert result.authoritative_id is None


def test_resource_mapping_splits_skills_and_flags_unavailable():
    row = {
        "Emp ID": "3282132",
        "Name": "Ms. S Nooray salma",
        "Skill": "Java, Spring Boot, AWS",
        "Detailed Status": "Allocated",
    }
    result = map_resource_tracker_row(row)
    assert result["skills"] == ["Java", "Spring Boot", "AWS"]
    assert result["is_available"] is False


def test_resource_mapping_available_when_status_is_open():
    row = {"Emp ID": "999", "Skill": "Python", "Detailed Status": "drop(Allocation plan shared)"}
    result = map_resource_tracker_row(row)
    assert result["is_available"] is True
