import jwt

from app.core.config import get_settings
from app.core.enums import UserRole
from app.services.auth_service import get_or_create_user, issue_app_jwt, issue_dev_token

settings = get_settings()


def test_dev_token_round_trips_with_expected_claims(db_session):
    token = issue_dev_token(db_session, email="dm@example.com", roles=[UserRole.DELIVERY_MANAGER])

    claims = jwt.decode(token, settings.jwt_secret_key, algorithms=[settings.jwt_algorithm])
    assert claims["email"] == "dm@example.com"
    assert "DELIVERY_MANAGER" in claims["roles"]


def test_first_login_creates_user_with_default_role(db_session):
    user = get_or_create_user(
        db_session, email="new.user@example.com", display_name="New User", entra_object_id="oid-123"
    )
    assert user.email == "new.user@example.com"
    assert user.has_role(UserRole.REQUIREMENT_TEAM)


def test_second_login_with_same_oid_reuses_user(db_session):
    first = get_or_create_user(db_session, email="a@example.com", display_name="A", entra_object_id="oid-999")
    second = get_or_create_user(db_session, email="a@example.com", display_name="A", entra_object_id="oid-999")
    assert first.id == second.id


def test_issue_app_jwt_includes_all_assigned_roles(db_session):
    user = get_or_create_user(db_session, email="multi@example.com", display_name="Multi", entra_object_id="oid-77")
    token = issue_app_jwt(user)
    claims = jwt.decode(token, settings.jwt_secret_key, algorithms=[settings.jwt_algorithm])
    assert claims["roles"] == ["REQUIREMENT_TEAM"]
