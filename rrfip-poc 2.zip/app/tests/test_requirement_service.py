import re

from app.core.enums import SourceType
from app.services.requirement_service import NormalizedRequirementInput, ingest_requirement


def test_authoritative_id_is_preserved_as_rjs(db_session):
    data = NormalizedRequirementInput(
        source_type=SourceType.REQUIREMENT_EXCEL,
        source_identifier="excel-row-1",
        authoritative_id="10660280",
    )
    requirement = ingest_requirement(db_session, data)
    assert requirement.rjs == "10660280"


def test_missing_authoritative_id_generates_rjs(db_session):
    """Exercises the REAL, unmocked generate_rjs() -- not a mock standing in for it. This
    only proves the SQLite-fallback branch works correctly; the PostgreSQL SEQUENCE branch
    is covered separately in test_rjs_service.py's dialect-gating tests and needs a real
    PostgreSQL connection to fully verify (see that file's module docstring).
    """
    data = NormalizedRequirementInput(
        source_type=SourceType.OUTLOOK,
        source_identifier="outlook-msg-1",
        authoritative_id=None,
    )
    requirement = ingest_requirement(db_session, data)
    assert re.fullmatch(r"RJS-\d{6}", requirement.rjs)


def test_duplicate_source_event_does_not_create_second_requirement(db_session):
    data = NormalizedRequirementInput(
        source_type=SourceType.TEAMS,
        source_identifier="teams-msg-42",
        authoritative_id="REQ-999",
    )
    first = ingest_requirement(db_session, data)
    second = ingest_requirement(db_session, data)  # same source event replayed
    assert first.id == second.id
    assert len(second.sources) == 1  # not duplicated


def test_multiple_sources_attach_to_one_rjs(db_session):
    base = NormalizedRequirementInput(
        source_type=SourceType.REQUIREMENT_EXCEL,
        source_identifier="excel-row-99",
        authoritative_id="REQ-777",
    )
    outlook = NormalizedRequirementInput(
        source_type=SourceType.OUTLOOK,
        source_identifier="outlook-msg-99",
        authoritative_id="REQ-777",
    )
    first = ingest_requirement(db_session, base)
    second = ingest_requirement(db_session, outlook)
    assert first.rjs == second.rjs == "REQ-777"
    assert len(second.sources) == 2
