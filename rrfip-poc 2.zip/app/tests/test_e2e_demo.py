"""P0 end-to-end acceptance demo (spec section 30/39/43).

This is the deterministic local demo: submits "Need 2 Python developers in Chennai with 4+
years experience" through the REAL application services (no HTTP layer, no Graph, no live
LLM -- a mock LLMProvider stands in per the delivery-mode instruction's "P0 local demo may
use a deterministic/mock LLM provider").

Run with: pytest app/tests/test_e2e_demo.py -v

This file could NOT be executed inside the development sandbox (no network access to install
SQLAlchemy/FastAPI/pytest) -- see the completion report for what that means for confidence
level. It is written to run correctly the moment `pip install -r requirements.txt` succeeds
in a real environment with Python 3.12.10.
"""
from unittest.mock import patch

from app.ai.llm_provider import LLMResponse
from app.core.enums import DuplicateVerdict, FulfillmentStatus, SourceType, UserRole
from app.models.requirement import Requirement, RequirementSource
from app.services.duplicate_detection_service import detect_duplicate_for_fields
from app.services.requirement_service import NormalizedRequirementInput, ingest_requirement
from app.services.resource_matching_service import rank_resource_matches
from app.services.fulfillment_service import get_or_create_fulfillment_record, transition_status


class FakeLLMProvider:
    """Deterministic stand-in LLM provider. Returns a fixed, correctly-shaped extraction for
    the demo's known input text -- exercises the REAL Pydantic validation in
    app/ai/schemas.py::ExtractedRequirement, just not a real network call to Anthropic.
    """

    def complete(self, *, system, user_message, max_tokens=1000, tools=None):
        import json

        extraction = {
            "requirement_type": "New",
            "skills": ["Python"],
            "experience_years": 4,
            "location": "Chennai",
            "quantity": 2,
            "project": None,
            "portfolio": "Digital",
            "business_unit": None,
            "requester": None,
            "priority": None,
            "start_date": None,
            "target_date": None,
            "remarks": None,
            "confidence": 0.92,
        }
        return LLMResponse(text=json.dumps(extraction), tool_use=None, model="fake-model-v1", raw={})


def test_p0_demo_single_requirement_end_to_end(db_session):
    """STEP 1-9 of the acceptance scenario, minus the frontend display (a separate,
    non-Python concern -- see the completion report for how this API-level result maps to
    the Fulfillment Tracker table columns).
    """
    demo_text = "Need 2 Python developers in Chennai with 4+ years experience."

    with patch("app.ai.llm_provider.get_llm_provider", return_value=FakeLLMProvider()):
        from app.ai.requirement_intelligence import extract_requirement_from_text

        extracted, run_meta = extract_requirement_from_text(demo_text)

    assert extracted.confidence >= 0.5, "Demo extraction must be high-confidence (not routed to review)"
    assert extracted.skills == ["Python"]
    assert extracted.location == "Chennai"
    assert extracted.quantity == 2

    verdict, match, score = detect_duplicate_for_fields(
        db_session, account_portfolio=extracted.portfolio, location=extracted.location,
        skill=", ".join(extracted.skills),
    )
    assert verdict == DuplicateVerdict.NOT_DUPLICATE
    assert match is None

    normalized = NormalizedRequirementInput(
        source_type=SourceType.TEAMS,
        source_identifier="demo-source-1",
        authoritative_id=None,
        skill=", ".join(extracted.skills),
        location=extracted.location,
        account_portfolio=extracted.portfolio,
        requirement_type=extracted.requirement_type,
        quantity=extracted.quantity,
        raw_payload={"body": {"content": demo_text}},
    )
    requirement = ingest_requirement(db_session, normalized, actor="demo")

    assert requirement.rjs.startswith("RJS-")
    assert requirement.skill == "Python"
    assert requirement.location == "Chennai"
    assert requirement.quantity == 2

    matches = rank_resource_matches(db_session, requirement)
    assert matches == []

    record = get_or_create_fulfillment_record(db_session, requirement)
    assert record.status == FulfillmentStatus.OPEN

    from sqlalchemy import select

    from app.models.audit import AuditLog

    audit_entries = db_session.execute(
        select(AuditLog).where(AuditLog.rjs == requirement.rjs)
    ).scalars().all()
    assert len(audit_entries) >= 1
    assert any(e.action == "requirement_created" for e in audit_entries)


def test_p0_demo_resubmitting_same_source_produces_no_duplicate(db_session):
    """Submit the SAME source event twice. Expected: ONE requirement, ONE RJS, NO duplicate."""
    demo_text = "Need 2 Python developers in Chennai with 4+ years experience."
    normalized = NormalizedRequirementInput(
        source_type=SourceType.TEAMS,
        source_identifier="demo-source-repeat",
        authoritative_id=None,
        skill="Python",
        location="Chennai",
        account_portfolio="Digital",
        quantity=2,
        raw_payload={"body": {"content": demo_text}},
    )

    first = ingest_requirement(db_session, normalized, actor="demo")
    second = ingest_requirement(db_session, normalized, actor="demo")

    assert first.id == second.id
    assert first.rjs == second.rjs

    from sqlalchemy import select

    all_requirements_with_this_rjs = db_session.execute(
        select(Requirement).where(Requirement.rjs == first.rjs)
    ).scalars().all()
    assert len(all_requirements_with_this_rjs) == 1

    all_sources = db_session.execute(
        select(RequirementSource).where(RequirementSource.requirement_id == first.id)
    ).scalars().all()
    assert len(all_sources) == 1


def test_p0_demo_similar_requirement_from_different_source_flags_duplicate(db_session):
    """A near-identical requirement worded differently from a DIFFERENT source must be
    flagged DUPLICATE or PROBABLE_DUPLICATE/NEEDS_REVIEW -- never silently create a second RJS.
    """
    first_normalized = NormalizedRequirementInput(
        source_type=SourceType.TEAMS,
        source_identifier="demo-source-A",
        authoritative_id=None,
        skill="Python",
        location="Chennai",
        account_portfolio="Digital",
        role="Non Lead",
        quantity=2,
    )
    first = ingest_requirement(db_session, first_normalized, actor="demo")

    verdict, match, score = detect_duplicate_for_fields(
        db_session, account_portfolio="Digital", location="Chennai", skill="Python", role="Non Lead",
    )

    assert verdict in (DuplicateVerdict.DUPLICATE, DuplicateVerdict.PROBABLE_DUPLICATE, DuplicateVerdict.NEEDS_REVIEW)
    assert match is not None
    assert match.rjs == first.rjs


def test_p0_demo_full_status_transition_lifecycle(db_session):
    """OPEN -> IDENTIFIED -> HOLD -> CLOSED, plus the CLOSED role gate."""
    requirement = Requirement(rjs="RJS-DEMO-LIFECYCLE", quantity=1)
    db_session.add(requirement)
    db_session.flush()
    record = get_or_create_fulfillment_record(db_session, requirement)
    assert record.status == FulfillmentStatus.OPEN

    transition_status(
        db_session, record, FulfillmentStatus.IDENTIFIED,
        actor="dm@example.com", actor_roles={UserRole.DELIVERY_MANAGER}, rjs=requirement.rjs,
    )
    assert record.status == FulfillmentStatus.IDENTIFIED

    transition_status(
        db_session, record, FulfillmentStatus.HOLD,
        actor="dm@example.com", actor_roles={UserRole.DELIVERY_MANAGER}, rjs=requirement.rjs,
    )
    assert record.status == FulfillmentStatus.HOLD

    transition_status(
        db_session, record, FulfillmentStatus.CLOSED,
        actor="dm@example.com", actor_roles={UserRole.DELIVERY_MANAGER}, rjs=requirement.rjs,
    )
    assert record.status == FulfillmentStatus.CLOSED

    from app.services.fulfillment_service import ForbiddenTransitionError

    raised = False
    try:
        transition_status(
            db_session, record, FulfillmentStatus.OPEN,
            actor="dp@example.com", actor_roles={UserRole.DELIVERY_PARTNER}, rjs=requirement.rjs,
        )
    except ForbiddenTransitionError:
        raised = True
    assert raised, "Expected ForbiddenTransitionError for non-elevated CLOSED reopen"

    assert len(record.events) == 3
    statuses_reached = [e.to_status for e in record.events]
    assert statuses_reached == [FulfillmentStatus.IDENTIFIED, FulfillmentStatus.HOLD, FulfillmentStatus.CLOSED]
