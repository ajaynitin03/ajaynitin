from app.core.enums import DuplicateVerdict
from app.models.requirement import Requirement
from app.models.resource import Resource, ResourceSkill
from app.services.duplicate_detection_service import detect_duplicate
from app.services.resource_matching_service import rank_resource_matches, score_resource


def test_no_candidates_means_not_duplicate(db_session):
    req = Requirement(rjs="RJS-1", account_portfolio="Life IT", location="Chennai", skill="Java")
    db_session.add(req)
    db_session.flush()

    verdict, match, score = detect_duplicate(db_session, req)
    assert verdict == DuplicateVerdict.NOT_DUPLICATE
    assert match is None


def test_near_identical_requirement_is_flagged_duplicate(db_session):
    existing = Requirement(rjs="RJS-1", account_portfolio="Life IT", location="Chennai", skill="Java Springboot", role="Lead")
    new = Requirement(rjs="RJS-2", account_portfolio="Life IT", location="Chennai", skill="Java Springboot", role="Lead")
    db_session.add_all([existing, new])
    db_session.flush()

    verdict, match, score = detect_duplicate(db_session, new)
    assert verdict == DuplicateVerdict.DUPLICATE
    assert match.rjs == "RJS-1"
    assert score >= 0.92


def test_somewhat_similar_requirement_needs_review(db_session):
    existing = Requirement(rjs="RJS-1", account_portfolio="Life IT", location="Chennai", skill="Java Springboot Microservices", role="Lead")
    new = Requirement(rjs="RJS-2", account_portfolio="Life IT", location="Chennai", skill="Python Django", role="Non Lead")
    db_session.add_all([existing, new])
    db_session.flush()

    verdict, match, score = detect_duplicate(db_session, new)
    assert verdict in (DuplicateVerdict.NOT_DUPLICATE, DuplicateVerdict.PROBABLE_DUPLICATE)


def test_resource_scoring_rewards_skill_location_portfolio_match(db_session):
    req = Requirement(rjs="RJS-1", account_portfolio="Life IT", location="Chennai", skill="Java, AWS")
    resource = Resource(employee_id="E1", location="Chennai", portfolio="Life IT", is_available=True)
    db_session.add_all([req, resource])
    db_session.flush()
    db_session.add(ResourceSkill(resource_id=resource.id, skill="Java"))
    db_session.add(ResourceSkill(resource_id=resource.id, skill="AWS"))
    db_session.flush()
    db_session.refresh(resource)

    score, reasons = score_resource(req, resource)
    assert score > 0.8
    assert reasons["skill_score"] == 1.0
    assert reasons["location_score"] == 1.0


def test_unavailable_resource_is_excluded_from_ranking(db_session):
    req = Requirement(rjs="RJS-1", location="Chennai", skill="Java")
    available = Resource(employee_id="E1", location="Chennai", is_available=True)
    unavailable = Resource(employee_id="E2", location="Chennai", is_available=False)
    db_session.add_all([req, available, unavailable])
    db_session.flush()
    db_session.add(ResourceSkill(resource_id=available.id, skill="Java"))
    db_session.add(ResourceSkill(resource_id=unavailable.id, skill="Java"))
    db_session.flush()

    ranked = rank_resource_matches(db_session, req)
    resource_ids = {item["resource"].id for item in ranked}
    assert available.id in resource_ids
    assert unavailable.id not in resource_ids
