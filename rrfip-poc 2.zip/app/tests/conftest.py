"""Shared test fixtures.

Uses a file-based SQLite DB for fast, dependency-free unit tests of ORM/service logic.
JSONB/UUID Postgres types degrade gracefully under SQLite for functional testing; full
integration tests (Alembic migrations, real PostgreSQL SEQUENCE concurrency) should run
against real PostgreSQL -- see docs/setup.md and app/tests/test_rjs_service.py's module
docstring for exactly what is and isn't covered by the SQLite path.
"""
import uuid

import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.db.session import Base


@pytest.fixture()
def db_session(tmp_path):
    db_path = tmp_path / "test.db"
    engine = create_engine(f"sqlite:///{db_path}")

    import app.models  # noqa: F401 register all models

    Base.metadata.create_all(engine)
    session_local = sessionmaker(bind=engine)
    session = session_local()
    try:
        yield session
    finally:
        session.close()


@pytest.fixture()
def sample_rjs():
    return f"RJS-TEST-{uuid.uuid4().hex[:8]}"
